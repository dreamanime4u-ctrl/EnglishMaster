import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { GoogleGenAI } from '@google/genai';

const execFileAsync = promisify(execFile);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProd = process.env.NODE_ENV === 'production';

function resolvePort(): number {
  const portFlagIndex = process.argv.indexOf('--port');
  if (portFlagIndex !== -1 && process.argv[portFlagIndex + 1]) {
    const cliPort = Number(process.argv[portFlagIndex + 1]);
    if (!Number.isNaN(cliPort) && cliPort > 0) return cliPort;
  }
  const envPort = Number(process.env.PORT);
  const nginxPort = Number(process.env.NGINX_PORT);
  if (!isProd || (nginxPort && envPort === nginxPort)) {
    return Number(process.env.DEFAULT_APP_PORT) || 3000;
  }
  return envPort || 3000;
}

const PORT = resolvePort();
const PUBLIC_AUDIO_DIR = path.resolve(__dirname, 'public', 'audio');
const CACHE_DIR = path.resolve(__dirname, '.tts-cache');

for (const dir of [PUBLIC_AUDIO_DIR, CACHE_DIR]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

const ttsCache = new Map<string, string>();
let liteQuotaExhausted = false;
let flagshipQuotaExhausted = false;

const ALL_FRUITS = [
  'Apple',
  'Banana',
  'Orange',
  'Grapes',
  'Strawberry',
  'Watermelon',
  'Pineapple',
  'Mango',
  'Pear',
  'Peach',
  'Cherry',
  'Lemon',
  'Coconut',
  'Kiwi',
  'Blueberry',
  'Blackberry',
];

const ALL_NUMBERS = [
  'One',
  'Two',
  'Three',
  'Four',
  'Five',
  'Six',
  'Seven',
  'Eight',
  'Nine',
  'Ten',
];

const ALL_LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

const ALL_ANIMALS = [
  'Lion',
  'Elephant',
  'Giraffe',
  'Monkey',
  'Tiger',
  'Zebra',
  'Bear',
  'Rabbit',
  'Cat',
  'Dog',
  'Cow',
  'Sheep',
  'Horse',
  'Duck',
  'Frog',
  'Panda',
  'Fox',
  'Koala',
  'Penguin',
  'Turtle',
];

const ALL_COLORS = [
  'Red',
  'Blue',
  'Yellow',
  'Green',
  'Orange',
  'Purple',
  'Pink',
  'Brown',
  'Black',
  'White',
  'Gray',
  'Gold',
];

const ALL_BODY_PARTS = [
  'Head',
  'Hair',
  'Eyes',
  'Nose',
  'Mouth',
  'Ears',
  'Hand',
  'Fingers',
  'Arm',
  'Leg',
  'Foot',
  'Teeth',
];

interface BatchWordItem {
  key: string;
  speakText: string;
  isLetter?: boolean;
}

const ALL_ITEMS: BatchWordItem[] = [
  ...ALL_FRUITS.map((w) => ({ key: toSafeKey(w), speakText: w })),
  ...ALL_NUMBERS.map((w) => ({ key: toSafeKey(w), speakText: w })),
  ...ALL_LETTERS.map((l) => ({
    key: `letter_${l.toLowerCase()}`,
    speakText: `${l}.`,
    isLetter: true,
  })),
  ...ALL_ANIMALS.map((w) => ({ key: toSafeKey(w), speakText: w })),
  ...ALL_COLORS.map((w) => ({ key: toSafeKey(w), speakText: w })),
  ...ALL_BODY_PARTS.map((w) => ({ key: toSafeKey(w), speakText: w })),
];

function toSafeKey(word: string): string {
  return word.toLowerCase().replace(/[^a-z0-9_-]/g, '_');
}

function getCachedWordBase64(word: string): string | null {
  const safeKey = toSafeKey(word);
  const mem = ttsCache.get(safeKey);
  if (mem) return mem;

  for (const dir of [PUBLIC_AUDIO_DIR, CACHE_DIR]) {
    const filePath = path.join(dir, `${safeKey}.wav`);
    if (fs.existsSync(filePath)) {
      const b64 = fs.readFileSync(filePath).toString('base64');
      ttsCache.set(safeKey, b64);
      return b64;
    }
  }
  return null;
}

async function generateSingleWordWithModel(
  word: string,
  model: 'gemini-3.8-flash-tts' | 'gemini-3.8-flash-lite-tts'
): Promise<string | null> {
  const response = await getAiClient().models.generateContent({
    model,
    contents: [
      {
        role: 'user',
        parts: [
          {
            text: word,
            speechMetadata: {
              style:
                'Warm, cheerful, gentle female kindergarten English teacher pronouncing this single word brightly, naturally, and crystal clearly for young children',
            },
          },
        ],
      },
    ],
    config: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data ?? null;
}

async function detectSpeechSegments(
  wavPath: string,
  silenceMinDuration: number,
  noiseDb = -38
): Promise<{ segments: Array<{ start: number; end: number }>; totalDuration: number }> {
  const { stderr } = await execFileAsync('ffmpeg', [
    '-i',
    wavPath,
    '-af',
    `silencedetect=noise=${noiseDb}dB:d=${silenceMinDuration.toFixed(2)}`,
    '-f',
    'null',
    '-',
  ]);

  const durMatch = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
  const totalDuration = durMatch
    ? Number(durMatch[1]) * 3600 + Number(durMatch[2]) * 60 + Number(durMatch[3])
    : 10;

  const silences: Array<{ start: number; end: number }> = [];
  let pendingStart: number | null = null;
  for (const line of stderr.split('\n')) {
    const startMatch = line.match(/silence_start:\s*([\d.]+)/);
    if (startMatch) {
      pendingStart = Number(startMatch[1]);
    }
    const endMatch = line.match(/silence_end:\s*([\d.]+)/);
    if (endMatch) {
      silences.push({
        start: pendingStart ?? 0,
        end: Number(endMatch[1]),
      });
      pendingStart = null;
    }
  }
  if (pendingStart !== null) {
    silences.push({ start: pendingStart, end: totalDuration });
  }

  const segments: Array<{ start: number; end: number }> = [];
  let cursor = 0;
  for (const s of silences) {
    if (s.start - cursor >= 0.14) {
      segments.push({ start: cursor, end: s.start });
    }
    cursor = Math.max(cursor, s.end);
  }
  if (totalDuration - cursor >= 0.14) {
    segments.push({ start: cursor, end: totalDuration });
  }

  return { segments, totalDuration };
}

async function generateAndSplitBatch(items: BatchWordItem[]): Promise<number> {
  if (!process.env.GEMINI_API_KEY || items.length === 0) {
    return 0;
  }

  const isLetterBatch = items.every((item) => item.isLetter);
  const promptText = items.map((item) => item.speakText).join(' ... ... ');
  const styleInstruction = isLetterBatch
    ? "Warm, cheerful female preschool English teacher clearly reciting each individual English alphabet letter name one by one (pronouncing 'A' as Ay, 'B' as Bee, 'C' as Cee, 'I' as Eye, 'Z' as Zee), leaving a clear 1.5-second silent pause between every letter"
    : 'Warm, cheerful female preschool English teacher pronouncing each single English word brightly and crystal clearly for young children, leaving a clear 1.5-second silent pause between every word';

  const modelsToTry: Array<'gemini-3.8-flash-tts' | 'gemini-3.8-flash-lite-tts'> = [];
  if (!flagshipQuotaExhausted) modelsToTry.push('gemini-3.8-flash-tts');
  if (!liteQuotaExhausted) modelsToTry.push('gemini-3.8-flash-lite-tts');
  if (modelsToTry.length === 0) return 0;

  let base64Audio: string | undefined;
  let lastBatchErr: unknown = null;
  for (const model of modelsToTry) {
    try {
      const response = await getAiClient().models.generateContent({
        model,
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: promptText,
                speechMetadata: {
                  style: styleInstruction,
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });
      base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) break;
    } catch (err) {
      lastBatchErr = err;
      const msg = err instanceof Error ? err.message : '';
      if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
        if (model === 'gemini-3.8-flash-tts') flagshipQuotaExhausted = true;
        else liteQuotaExhausted = true;
      } else {
        throw err;
      }
    }
  }

  if (!base64Audio) {
    if (lastBatchErr) throw lastBatchErr;
    return 0;
  }

  const tempWav = path.join('/tmp', `batch_${Date.now()}.wav`);
  fs.writeFileSync(tempWav, Buffer.from(base64Audio, 'base64'));

  try {
    let { segments: speechSegments, totalDuration } = await detectSpeechSegments(tempWav, 0.4, -38);

    if (speechSegments.length < items.length) {
      const retry = await detectSpeechSegments(tempWav, 0.25, -36);
      if (retry.segments.length >= speechSegments.length) {
        speechSegments = retry.segments;
        totalDuration = retry.totalDuration;
      }
    }

    while (speechSegments.length > items.length) {
      let minGap = Infinity;
      let minIdx = 0;
      for (let i = 0; i < speechSegments.length - 1; i++) {
        const gap = speechSegments[i + 1].start - speechSegments[i].end;
        if (gap < minGap) {
          minGap = gap;
          minIdx = i;
        }
      }
      speechSegments.splice(minIdx, 2, {
        start: speechSegments[minIdx].start,
        end: speechSegments[minIdx + 1].end,
      });
    }

    if (speechSegments.length !== items.length) {
      return 0;
    }

    let saved = 0;
    for (let i = 0; i < items.length; i++) {
      const seg = speechSegments[i];
      const start = Math.max(0, seg.start - 0.05);
      const end = Math.min(totalDuration, seg.end + 0.08);
      const dur = Math.max(0.15, end - start);
      const safeKey = items[i].key;
      const outPath = path.join(PUBLIC_AUDIO_DIR, `${safeKey}.wav`);

      await execFileAsync('ffmpeg', [
        '-y',
        '-ss',
        start.toFixed(3),
        '-t',
        dur.toFixed(3),
        '-i',
        tempWav,
        '-af',
        `afade=t=in:st=0:d=0.015,afade=t=out:st=${Math.max(0.05, dur - 0.025).toFixed(3)}:d=0.025`,
        outPath,
      ]);

      const { stderr: volErr } = await execFileAsync('ffmpeg', [
        '-i',
        outPath,
        '-af',
        'volumedetect',
        '-f',
        'null',
        '-',
      ]);
      const maxVolMatch = volErr.match(/max_volume:\s*([-0-9.]+)\s*dB/);
      const maxVol = maxVolMatch ? Number(maxVolMatch[1]) : -91;
      if (maxVol < -35) {
        if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
        continue;
      }

      const b64 = fs.readFileSync(outPath).toString('base64');
      ttsCache.set(safeKey, b64);
      saved++;
    }
    return saved;
  } finally {
    if (fs.existsSync(tempWav)) {
      fs.unlinkSync(tempWav);
    }
  }
}

const app = express();
app.use(express.json());
app.use('/audio', express.static(PUBLIC_AUDIO_DIR));
app.use('/audio', (_req: Request, res: Response) => {
  res.status(404).end();
});

app.post('/api/tts/preload-all', async (_req: Request, res: Response) => {
  const missing = ALL_ITEMS.filter((item) => !getCachedWordBase64(item.key));
  if (missing.length === 0) {
    res.json({ cached: ALL_ITEMS.length, generated: 0 });
    return;
  }

  const missingWords = missing.filter((item) => !item.isLetter);
  const missingLetters = missing.filter((item) => Boolean(item.isLetter));
  let generated = 0;
  try {
    for (let i = 0; i < missingWords.length; i += 5) {
      const batch = missingWords.slice(i, i + 5);
      const count = await generateAndSplitBatch(batch);
      generated += count;
    }
    for (let i = 0; i < missingLetters.length; i += 4) {
      const batch = missingLetters.slice(i, i + 4);
      const count = await generateAndSplitBatch(batch);
      generated += count;
    }
    res.json({
      cached: ALL_ITEMS.filter((item) => Boolean(getCachedWordBase64(item.key))).length,
      generated,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Batch TTS failed.';
    if (message.includes('429') || message.includes('RESOURCE_EXHAUSTED')) {
      res.status(429).json({ error: message, generated });
      return;
    }
    res.status(500).json({ error: message, generated });
  }
});

app.post('/api/tts', async (req: Request, res: Response) => {
  const rawWord = typeof req.body?.word === 'string' ? req.body.word.trim() : '';
  const rawAudioKey =
    typeof req.body?.audioKey === 'string' ? req.body.audioKey.trim() : '';

  if (!rawWord || rawWord.length > 60) {
    res.status(400).json({ error: 'Invalid word parameter.' });
    return;
  }

  const safeKey = rawAudioKey ? toSafeKey(rawAudioKey) : toSafeKey(rawWord);
  const cached = getCachedWordBase64(safeKey);
  if (cached) {
    res.json({ audioBase64: cached, mimeType: 'audio/wav' });
    return;
  }

  if (!process.env.GEMINI_API_KEY) {
    res.status(503).json({ error: 'GEMINI_API_KEY is not configured.' });
    return;
  }

  const modelsToTry: Array<'gemini-3.8-flash-tts' | 'gemini-3.8-flash-lite-tts'> = [];
  if (!flagshipQuotaExhausted) modelsToTry.push('gemini-3.8-flash-tts');
  if (!liteQuotaExhausted) modelsToTry.push('gemini-3.8-flash-lite-tts');

  if (modelsToTry.length === 0) {
    res.status(429).json({ error: 'TTS quota temporarily exhausted.' });
    return;
  }

  let lastError = 'TTS generation failed.';
  for (const model of modelsToTry) {
    try {
      const base64Audio = await generateSingleWordWithModel(rawWord, model);
      if (base64Audio) {
        ttsCache.set(safeKey, base64Audio);
        try {
          fs.writeFileSync(
            path.join(PUBLIC_AUDIO_DIR, `${safeKey}.wav`),
            Buffer.from(base64Audio, 'base64')
          );
        } catch {
          // Ignore disk write errors
        }
        res.json({ audioBase64: base64Audio, mimeType: 'audio/wav' });
        return;
      }
    } catch (err) {
      lastError = err instanceof Error ? err.message : lastError;
      if (lastError.includes('429') || lastError.includes('RESOURCE_EXHAUSTED')) {
        if (model === 'gemini-3.8-flash-tts') flagshipQuotaExhausted = true;
        else liteQuotaExhausted = true;
      }
    }
  }

  res.status(flagshipQuotaExhausted && liteQuotaExhausted ? 429 : 500).json({
    error: lastError,
  });
});

async function startServer() {
  if (!isProd) {
    let viteMiddlewares:
      | ((req: Request, res: Response, next: express.NextFunction) => void)
      | null = null;

    const viteReady = import('vite')
      .then(({ createServer: createViteServer }) =>
        createViteServer({
          server: { middlewareMode: true },
          appType: 'spa',
        })
      )
      .then((vite) => {
        viteMiddlewares = vite.middlewares;
        return vite;
      })
      .catch((err) => {
        console.error('Failed to initialize Vite dev middleware:', err);
        throw err;
      });

    app.use((req, res, next) => {
      if (viteMiddlewares) {
        viteMiddlewares(req, res, next);
        return;
      }
      viteReady
        .then((vite) => {
          vite.middlewares(req, res, next);
        })
        .catch(next);
    });
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EnglishMaster server running on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
