import React from 'react';
import { LetterWord } from '../data/letters';

interface LetterVisualProps {
  item: LetterWord;
  mode?: 'pair' | 'lowerOnly' | 'badge';
}

export const LetterVisual: React.FC<LetterVisualProps> = ({
  item,
  mode = 'pair',
}) => {
  const gradId = `letter-grad-${item.upper}-${mode}`;

  if (mode === 'badge') {
    return (
      <svg
        viewBox="0 0 110 92"
        className="w-[56px] h-[46px] sm:w-[64px] sm:h-[54px] select-none drop-shadow-[0_3px_5px_rgba(12,60,130,0.2)]"
        aria-hidden="true"
      >
        <text
          x="36"
          y="68"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize="60"
          fill="#2DD4BF"
          stroke="#0F766E"
          strokeWidth="6"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          A
        </text>
        <text
          x="78"
          y="70"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize="54"
          fill="#FF82C4"
          stroke="#831843"
          strokeWidth="6"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          B
        </text>
      </svg>
    );
  }

  const displayText = mode === 'lowerOnly' ? item.lower : `${item.upper} ${item.lower}`;

  return (
    <div className="flex items-center justify-center bg-white px-2 select-none">
      <svg
        viewBox={mode === 'lowerOnly' ? '0 0 140 124' : '0 0 210 124'}
        className={
          mode === 'lowerOnly'
            ? 'w-[132px] sm:w-[138px] h-[112px] sm:h-[120px] drop-shadow-[0_5px_9px_rgba(16,65,140,0.22)]'
            : 'w-[170px] sm:w-[192px] h-[110px] sm:h-[120px] drop-shadow-[0_5px_9px_rgba(16,65,140,0.22)]'
        }
        role="img"
        aria-label={mode === 'lowerOnly' ? `Lowercase letter ${item.lower}` : `Letter ${item.upper}`}
      >
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={item.fillTop} />
            <stop offset="100%" stopColor={item.fillBottom} />
          </linearGradient>
        </defs>

        <text
          x={mode === 'lowerOnly' ? '70' : '105'}
          y="98"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize={mode === 'lowerOnly' ? '102' : '94'}
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="15"
          strokeLinejoin="round"
        >
          {displayText}
        </text>

        <text
          x={mode === 'lowerOnly' ? '70' : '105'}
          y="98"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize={mode === 'lowerOnly' ? '102' : '94'}
          fill={`url(#${gradId})`}
          stroke={item.stroke}
          strokeWidth="7.5"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          {displayText}
        </text>
      </svg>
    </div>
  );
};
