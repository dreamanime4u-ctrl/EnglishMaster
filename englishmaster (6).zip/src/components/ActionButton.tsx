import React from 'react';

export type ButtonColor = 'blue' | 'green' | 'orange' | 'purple' | 'pink' | 'teal' | 'indigo';

interface ActionButtonProps {
  label: string;
  color?: ButtonColor;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  onClick: () => void;
  className?: string;
}

const COLOR_CLASSES: Record<ButtonColor, string> = {
  blue: 'bg-[linear-gradient(180deg,#4BBFFF_0%,#1D85F0_55%,#0E62CE_100%)] shadow-[0_4px_0_#0A469B,0_7px_14px_rgba(14,72,150,0.3)]',
  purple: 'bg-[linear-gradient(180deg,#CE78FF_0%,#963BF0_55%,#741FD1_100%)] shadow-[0_4px_0_#4F1299,0_7px_14px_rgba(92,24,168,0.3)]',
  green: 'bg-[linear-gradient(180deg,#9DF542_0%,#42C815_55%,#249E07_100%)] shadow-[0_4px_0_#176E02,0_7px_14px_rgba(30,130,8,0.3)]',
  orange: 'bg-[linear-gradient(180deg,#FFE055_0%,#FFA412_55%,#EA7B00_100%)] shadow-[0_4px_0_#B55A00,0_7px_14px_rgba(195,95,0,0.3)]',
  pink: 'bg-[linear-gradient(180deg,#FF8CC3_0%,#EE4291_55%,#C7206F_100%)] shadow-[0_4px_0_#8F124C,0_7px_14px_rgba(160,25,90,0.3)]',
  teal: 'bg-[linear-gradient(180deg,#49E8D6_0%,#12B8A6_55%,#0A887B_100%)] shadow-[0_4px_0_#065F56,0_7px_14px_rgba(10,120,110,0.3)]',
  indigo: 'bg-[linear-gradient(180deg,#818CF8_0%,#4F46E5_55%,#3730A3_100%)] shadow-[0_4px_0_#1E1B4B,0_7px_14px_rgba(55,48,163,0.3)]',
};

export const ActionButton: React.FC<ActionButtonProps> = ({
  label,
  color = 'blue',
  icon,
  iconPosition = 'left',
  onClick,
  className = '',
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative w-full min-h-[42px] px-3.5 py-1.5 rounded-full border-[2px] border-white/90 text-white font-display font-semibold text-[15px] tracking-wide transition-transform duration-100 active:translate-y-[2px] cursor-pointer flex items-center justify-center gap-2 select-none overflow-hidden focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-white/80 ${COLOR_CLASSES[color]} ${className}`}
    >
      <span
        className="pointer-events-none absolute inset-x-3 top-[3px] h-[40%] rounded-full bg-white/30"
        aria-hidden="true"
      />
      {icon && iconPosition === 'left' && (
        <span className="relative z-10 flex items-center justify-center shrink-0 drop-shadow-[0_1px_1px_rgba(0,0,0,0.28)]">
          {icon}
        </span>
      )}
      <span className="relative z-10 whitespace-nowrap shrink-0 drop-shadow-[0_1px_2px_rgba(0,0,0,0.32)]">
        {label}
      </span>
      {icon && iconPosition === 'right' && (
        <span className="relative z-10 flex items-center justify-center shrink-0 drop-shadow-[0_1px_1px_rgba(0,0,0,0.28)]">
          {icon}
        </span>
      )}
    </button>
  );
};
