import React from 'react';
import { NumberWord } from '../data/numbers';

interface NumberMascotProps {
  item: NumberWord;
  showCountStars?: boolean;
  size?: 'sm' | 'lg';
}

export const NumberMascot: React.FC<NumberMascotProps> = ({
  item,
  size = 'lg',
}) => {
  const gradId = `num-grad-${item.value}-${size}`;
  const isTen = item.value === 10;

  if (size === 'sm') {
    return (
      <svg
        viewBox="0 0 130 92"
        className="w-[68px] h-[46px] sm:w-[76px] sm:h-[54px] select-none drop-shadow-[0_3px_5px_rgba(12,60,130,0.2)]"
        aria-hidden="true"
      >
        <text
          x="26"
          y="68"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize="56"
          fill="#FF5252"
          stroke="#8F1111"
          strokeWidth="6"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          1
        </text>
        <text
          x="65"
          y="62"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize="60"
          fill="#FFB81C"
          stroke="#92400E"
          strokeWidth="6"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          2
        </text>
        <text
          x="104"
          y="68"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize="56"
          fill="#22A7FF"
          stroke="#0C3E8A"
          strokeWidth="6"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          3
        </text>
      </svg>
    );
  }

  return (
    <div className="flex items-center justify-center bg-white px-2 select-none">
      <svg
        viewBox="0 0 160 124"
        className="w-[158px] h-[126px] drop-shadow-[0_5px_9px_rgba(16,65,140,0.22)]"
        role="img"
        aria-label={`Number ${item.value}`}
      >
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={item.fillTop} />
            <stop offset="100%" stopColor={item.fillBottom} />
          </linearGradient>
        </defs>

        {/* Clean white sticker halo */}
        <text
          x="80"
          y="102"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize={isTen ? '98' : '114'}
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="15"
          strokeLinejoin="round"
        >
          {item.value}
        </text>

        {/* Bold, crisp, child-friendly numeral */}
        <text
          x="80"
          y="102"
          textAnchor="middle"
          fontFamily="Fredoka, Nunito, sans-serif"
          fontWeight="700"
          fontSize={isTen ? '98' : '114'}
          fill={`url(#${gradId})`}
          stroke={item.stroke}
          strokeWidth="7.5"
          paintOrder="stroke fill"
          strokeLinejoin="round"
        >
          {item.value}
        </text>
      </svg>
    </div>
  );
};
