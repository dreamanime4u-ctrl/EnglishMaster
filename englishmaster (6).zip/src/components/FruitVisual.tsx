import React, { useState } from 'react';

interface FruitVisualProps {
  imagePath?: string;
  alt?: string;
  label?: string;
  children?: React.ReactNode;
}

export const FruitVisual: React.FC<FruitVisualProps> = ({
  imagePath,
  alt = '',
  label = '',
  children,
}) => {
  const [failed, setFailed] = useState(false);

  return (
    <div className="relative w-full h-[136px] sm:h-[146px] flex items-center justify-center my-0.5 bg-white">
      {/* Left yellow cartoon burst rays */}
      <svg
        viewBox="0 0 60 80"
        className="w-8 h-11 text-[#FFE033] drop-shadow-[0_2px_4px_rgba(235,165,0,0.3)] shrink-0 -mr-1 select-none"
        aria-hidden="true"
      >
        <path
          d="M46 26 L14 14 C10 12 8 18 12 22 L42 33 C47 35 50 28 46 26 Z"
          fill="currentColor"
        />
        <path
          d="M44 48 L12 52 C7 53 7 60 13 60 L45 55 C50 54 49 47 44 48 Z"
          fill="currentColor"
        />
      </svg>

      <div className="relative flex flex-col items-center justify-center h-full px-1.5">
        {children ? (
          <div className="flex items-center justify-center mx-auto">{children}</div>
        ) : failed || !imagePath ? (
          <div className="w-32 h-32 mx-auto rounded-3xl bg-[linear-gradient(135deg,#FFF4D6,#FFE0A3)] border-2 border-[#FFD27D] flex flex-col items-center justify-center p-3 text-center shadow-sm">
            <span className="font-display font-bold text-xl text-[#123B82]">
              {label}
            </span>
          </div>
        ) : (
          <div className="relative flex items-center justify-center bg-white mx-auto">
            <img
              src={imagePath}
              alt={alt}
              referrerPolicy="no-referrer"
              onError={() => setFailed(true)}
              className="mx-auto max-h-[128px] sm:max-h-[138px] w-auto object-contain select-none mix-blend-multiply"
            />
          </div>
        )}
        <div
          className="w-32 h-3 -mt-1.5 rounded-full bg-[#B9D8F2]/70 blur-[3px]"
          aria-hidden="true"
        />
      </div>

      {/* Right yellow cartoon burst rays */}
      <svg
        viewBox="0 0 60 80"
        className="w-10 h-14 text-[#FFE033] drop-shadow-[0_2px_4px_rgba(235,165,0,0.3)] shrink-0 -ml-2 select-none"
        aria-hidden="true"
      >
        <path
          d="M14 26 L46 14 C50 12 52 18 48 22 L18 33 C13 35 10 28 14 26 Z"
          fill="currentColor"
        />
        <path
          d="M16 48 L48 52 C53 53 53 60 47 60 L15 55 C10 54 11 47 16 48 Z"
          fill="currentColor"
        />
      </svg>
    </div>
  );
};
