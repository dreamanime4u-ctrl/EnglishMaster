import React from 'react';

export const StarMascot: React.FC = () => {
  return (
    <svg
      viewBox="0 0 120 120"
      className="w-[62px] h-[62px] sm:w-[66px] sm:h-[66px] shrink-0 drop-shadow-[0_4px_6px_rgba(18,75,140,0.35)] select-none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="starBodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFF066" />
          <stop offset="55%" stopColor="#FFD21F" />
          <stop offset="100%" stopColor="#FFA200" />
        </linearGradient>
        <linearGradient id="starThumbGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFE955" />
          <stop offset="100%" stopColor="#FF9E00" />
        </linearGradient>
      </defs>

      {/* Main rounded cartoon star */}
      <path
        d="M62 8 C66 8 69 11 73 22 L78 36 L93 37 C104 38 108 42 108 46 C108 50 104 54 96 61 L85 71 L89 86 C91 96 89 101 85 103 C81 105 76 102 68 96 L56 87 L43 96 C35 102 30 104 26 101 C22 98 22 93 24 84 L28 70 L17 60 C10 53 7 49 8 44 C9 40 14 37 25 36 L40 35 L46 21 C50 11 54 8 62 8 Z"
        fill="url(#starBodyGrad)"
        stroke="#E67E00"
        strokeWidth="3.5"
        strokeLinejoin="round"
      />

      {/* Glossy forehead highlight */}
      <ellipse
        cx="58"
        cy="26"
        rx="10"
        ry="4.5"
        fill="#FFFFFF"
        opacity="0.55"
        transform="rotate(-12 58 26)"
      />

      {/* Eyebrows */}
      <path
        d="M41 44 Q46 40 51 43"
        fill="none"
        stroke="#5A2D00"
        strokeWidth="2.8"
        strokeLinecap="round"
      />
      <path
        d="M66 43 Q71 40 76 44"
        fill="none"
        stroke="#5A2D00"
        strokeWidth="2.8"
        strokeLinecap="round"
      />

      {/* Big sparkling eyes */}
      <ellipse cx="47" cy="54" rx="6.2" ry="7.2" fill="#1C2A4A" />
      <ellipse cx="70" cy="54" rx="6.2" ry="7.2" fill="#1C2A4A" />
      <circle cx="44.8" cy="51.5" r="2.4" fill="#FFFFFF" />
      <circle cx="67.8" cy="51.5" r="2.4" fill="#FFFFFF" />
      <circle cx="48.5" cy="56.5" r="1.1" fill="#FFFFFF" />
      <circle cx="71.5" cy="56.5" r="1.1" fill="#FFFFFF" />

      {/* Rosy cheeks */}
      <ellipse cx="36.5" cy="63" rx="5.2" ry="3.2" fill="#FF7B6B" opacity="0.65" />
      <ellipse cx="80.5" cy="63" rx="5.2" ry="3.2" fill="#FF7B6B" opacity="0.65" />

      {/* Happy open smile */}
      <path
        d="M49 64 Q58.5 67 68 64 Q67 77 58.5 77 Q50 77 49 64 Z"
        fill="#7A1C1C"
        stroke="#5A2D00"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path
        d="M52.5 72.5 Q58.5 69.5 64.5 72.5 Q62 76.2 58.5 76.2 Q55 76.2 52.5 72.5 Z"
        fill="#FF6B81"
      />

      {/* Cute thumbs-up hand on bottom-left */}
      <g transform="translate(3, 56)">
        <path
          d="M15 20 C15 11 19 6 22 6 C25 6 26 10 25 18 L31 18 C34 18 36 20 36 23 C36 25 35 26 34 27 C36 28 36 31 34 33 C35 34 34 37 32 38 C32 40 30 42 26 42 L15 42 C11 42 8 38 8 32 C8 25 11 20 15 20 Z"
          fill="url(#starThumbGrad)"
          stroke="#D46B00"
          strokeWidth="2.8"
          strokeLinejoin="round"
        />
        <line x1="25" y1="24" x2="32" y2="24" stroke="#D46B00" strokeWidth="1.8" strokeLinecap="round" />
        <line x1="25" y1="30" x2="32" y2="30" stroke="#D46B00" strokeWidth="1.8" strokeLinecap="round" />
        <line x1="25" y1="36" x2="31" y2="36" stroke="#D46B00" strokeWidth="1.8" strokeLinecap="round" />
      </g>
    </svg>
  );
};
