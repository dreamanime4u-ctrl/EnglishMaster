import React from 'react';
import { ColorWord } from '../data/colors';

interface ColorVisualProps {
  item: ColorWord;
  mode?: 'swatch' | 'badge';
}

export const ColorVisual: React.FC<ColorVisualProps> = ({
  item,
  mode = 'swatch',
}) => {
  const gradId = `color-grad-${item.english.toLowerCase()}-${mode}`;

  if (mode === 'badge') {
    return (
      <svg
        viewBox="0 0 96 76"
        className="w-[54px] h-[44px] sm:w-[60px] sm:h-[48px] select-none drop-shadow-[0_3px_5px_rgba(12,60,130,0.2)]"
        aria-hidden="true"
      >
        <circle cx="30" cy="44" r="18" fill="#EF4444" stroke="#991B1B" strokeWidth="3.5" />
        <ellipse cx="24" cy="36" rx="5.5" ry="3.2" fill="#FFFFFF" opacity="0.5" transform="rotate(-25 24 36)" />
        <circle cx="64" cy="44" r="18" fill="#22A7FF" stroke="#0C3E8A" strokeWidth="3.5" />
        <ellipse cx="58" cy="36" rx="5.5" ry="3.2" fill="#FFFFFF" opacity="0.5" transform="rotate(-25 58 36)" />
        <circle cx="47" cy="24" r="18" fill="#FFD426" stroke="#92400E" strokeWidth="3.5" />
        <ellipse cx="41" cy="16" rx="5.5" ry="3.2" fill="#FFFFFF" opacity="0.55" transform="rotate(-25 41 16)" />
      </svg>
    );
  }

  return (
    <div className="flex items-center justify-center bg-white px-2 select-none">
      <svg
        viewBox="0 0 180 140"
        className="w-[152px] sm:w-[168px] h-[120px] sm:h-[128px] drop-shadow-[0_6px_10px_rgba(16,65,140,0.22)]"
        role="img"
        aria-label={`${item.english} color splash`}
      >
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={item.fillTop} />
            <stop offset="100%" stopColor={item.fillBottom} />
          </linearGradient>
        </defs>

        {/* Outer white sticker halo */}
        <path
          d="M90 14 C112 14 128 28 134 45 C150 48 158 63 151 77 C146 87 137 92 132 98 C135 113 121 126 105 123 C97 121 92 117 86 119 C77 125 60 124 55 111 C52 104 54 96 47 93 C33 88 26 72 34 59 C39 51 47 47 50 40 C55 24 71 14 90 14 Z"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="14"
          strokeLinejoin="round"
        />

        {/* Small floating paint droplets with white halo */}
        <circle cx="24" cy="40" r="9" fill="#FFFFFF" />
        <circle cx="157" cy="42" r="8" fill="#FFFFFF" />
        <circle cx="148" cy="112" r="9" fill="#FFFFFF" />
        <circle cx="32" cy="108" r="8" fill="#FFFFFF" />

        {/* Main vibrant paint splash body */}
        <path
          d="M90 14 C112 14 128 28 134 45 C150 48 158 63 151 77 C146 87 137 92 132 98 C135 113 121 126 105 123 C97 121 92 117 86 119 C77 125 60 124 55 111 C52 104 54 96 47 93 C33 88 26 72 34 59 C39 51 47 47 50 40 C55 24 71 14 90 14 Z"
          fill={`url(#${gradId})`}
          stroke={item.stroke}
          strokeWidth="4.5"
          strokeLinejoin="round"
        />

        {/* Glossy highlights */}
        <ellipse
          cx="73"
          cy="44"
          rx="18"
          ry="9"
          fill={item.shineColor}
          opacity="0.72"
          transform="rotate(-24 73 44)"
        />
        <ellipse
          cx="58"
          cy="61"
          rx="7"
          ry="4.2"
          fill="#FFFFFF"
          opacity="0.6"
          transform="rotate(-18 58 61)"
        />

        {/* Satellite droplets */}
        <circle cx="24" cy="40" r="6" fill={`url(#${gradId})`} stroke={item.stroke} strokeWidth="3" />
        <circle cx="157" cy="42" r="5.2" fill={`url(#${gradId})`} stroke={item.stroke} strokeWidth="2.8" />
        <circle cx="148" cy="112" r="6" fill={`url(#${gradId})`} stroke={item.stroke} strokeWidth="3" />
        <circle cx="32" cy="108" r="5" fill={`url(#${gradId})`} stroke={item.stroke} strokeWidth="2.8" />
      </svg>
    </div>
  );
};
