import React from 'react';
import { Trophy } from 'lucide-react';
import { StarMascot } from './StarMascot';

interface AppHeaderProps {
  badgeText: string;
  progressWidthClass: string;
  onLogoClick?: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  badgeText,
  progressWidthClass,
  onLogoClick,
}) => {
  return (
    <header className="w-full px-3 flex flex-col items-center">
      <div className="w-full flex items-center justify-between gap-1.5">
        <div className="relative flex items-center flex-1 min-w-0">
          <div className="-mr-4 z-20 shrink-0 -rotate-6">
            <StarMascot />
          </div>

          <button
            type="button"
            onClick={onLogoClick}
            className="relative flex-1 min-w-0 pl-5 pr-3 py-1.5 rounded-[22px] border-[2.5px] border-white/90 bg-[linear-gradient(180deg,#48BEFF_0%,#1C86EE_60%,#0F66CF_100%)] shadow-[0_4px_0_#0A4A9E,0_6px_12px_rgba(12,72,148,0.32)] flex flex-col items-center justify-center text-center cursor-pointer overflow-hidden focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-white/80"
          >
            <span
              className="pointer-events-none absolute inset-x-3 top-1 h-[38%] rounded-full bg-white/25"
              aria-hidden="true"
            />
            <span className="relative z-10 font-display font-bold text-[19px] sm:text-[21px] leading-none text-white tracking-tight drop-shadow-[0_2px_2px_rgba(9,54,120,0.65)] whitespace-nowrap">
              EnglishMaster
            </span>
            <span className="relative z-10 flex items-center justify-center gap-1.5 mt-0.5 font-display font-bold text-[16px] sm:text-[18px] leading-none text-[#FFE63B] drop-shadow-[0_2px_2px_rgba(10,55,120,0.8)]">
              <span className="text-[11px] text-[#FFE63B]" aria-hidden="true">★</span>
              <span>Kids</span>
              <span className="text-[11px] text-[#FFE63B]" aria-hidden="true">★</span>
            </span>
          </button>

          <span
            className="ml-1 text-[17px] leading-none text-[#FFE135] drop-shadow-[0_2px_3px_rgba(180,105,0,0.45)] select-none shrink-0"
            aria-hidden="true"
          >
            ★
          </span>
        </div>

        <div className="relative shrink-0 px-3 py-1.5 rounded-full border-[2.5px] border-[#FFF5B8] bg-[linear-gradient(180deg,#FFE659_0%,#FFAC0E_100%)] shadow-[0_3px_0_#C97800,0_5px_10px_rgba(140,80,0,0.28)] flex items-center gap-1 overflow-hidden">
          <span
            className="pointer-events-none absolute inset-x-2 top-[2px] h-[38%] rounded-full bg-white/35"
            aria-hidden="true"
          />
          <Trophy className="relative z-10 w-4 h-4 text-[#7A3E00] fill-[#FFD028] shrink-0" aria-hidden="true" />
          <span className="relative z-10 font-display font-bold text-[15px] leading-none text-[#2B1B00] tabular-nums whitespace-nowrap">
            {badgeText}
          </span>
        </div>
      </div>

      <div className="w-[64%] h-[14px] mt-1.5 p-[2px] rounded-full bg-white/90 border-[1.5px] border-[#76C8FF] shadow-[0_2px_6px_rgba(14,76,145,0.2)] overflow-hidden">
        <div
          className={`relative h-full rounded-full bg-[linear-gradient(180deg,#A6FA4B_0%,#42C812_100%)] shadow-[inset_0_-2px_0_rgba(20,120,0,0.3)] transition-all duration-300 ${progressWidthClass}`}
        >
          <span
            className="pointer-events-none absolute inset-x-1.5 top-[1px] h-[40%] rounded-full bg-white/45"
            aria-hidden="true"
          />
        </div>
      </div>
    </header>
  );
};
