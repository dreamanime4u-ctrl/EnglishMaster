/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BarChart3,
  CheckCircle2,
  Home,
  Mic,
  Play,
  RotateCcw,
  Star,
  Target,
  Trophy,
  Volume2,
} from 'lucide-react';
import { ActionButton, ButtonColor } from './components/ActionButton';
import { AppHeader } from './components/AppHeader';
import { ColorVisual } from './components/ColorVisual';
import { FruitVisual } from './components/FruitVisual';
import { LetterVisual } from './components/LetterVisual';
import { NumberMascot } from './components/NumberMascot';
import meadowPortrait from './assets/images/kids_meadow_portrait_1794779093300.jpg';
import { ANIMALS, AnimalWord } from './data/animals';
import { BODY_PARTS, BodyPartWord } from './data/bodyParts';
import { COLORS, ColorWord } from './data/colors';
import { FRUITS, FruitWord, shuffleArray } from './data/fruits';
import { LETTERS, LetterWord } from './data/letters';
import { NUMBERS, NumberWord } from './data/numbers';
import { playKidSound, speakWord, stopCurrentSpeech, warmUpVoices } from './utils/speech';
import {
  incrementCompletedAnimalLessons,
  incrementCompletedBodyLessons,
  incrementCompletedColorLessons,
  incrementCompletedLessons,
  incrementCompletedLetterLessons,
  incrementCompletedNumberLessons,
  LearningProgress,
  loadProgress,
  updateBestAnimalQuizScore,
  updateBestBodyQuizScore,
  updateBestColorQuizScore,
  updateBestLetterQuizScore,
  updateBestNumberQuizScore,
  updateBestQuizScore,
} from './utils/storage';

type Screen =
  | 'home'
  | 'category'
  | 'lesson'
  | 'lessonComplete'
  | 'numbersLesson'
  | 'numbersComplete'
  | 'lettersLesson'
  | 'lettersComplete'
  | 'animalsLesson'
  | 'animalsComplete'
  | 'colorsLesson'
  | 'colorsComplete'
  | 'bodyLesson'
  | 'bodyComplete'
  | 'quiz'
  | 'numbersQuiz'
  | 'lettersQuiz'
  | 'animalsQuiz'
  | 'colorsQuiz'
  | 'bodyQuiz'
  | 'quizResult'
  | 'progress';

interface QuizQuestion {
  correct: FruitWord;
  options: FruitWord[];
}

interface NumberQuizQuestion {
  correct: NumberWord;
  options: NumberWord[];
}

interface LetterQuizQuestion {
  correct: LetterWord;
  options: LetterWord[];
}

interface AnimalQuizQuestion {
  correct: AnimalWord;
  options: AnimalWord[];
}

interface ColorQuizQuestion {
  correct: ColorWord;
  options: ColorWord[];
}

interface BodyQuizQuestion {
  correct: BodyPartWord;
  options: BodyPartWord[];
}

const OPTION_COLORS: ButtonColor[] = ['blue', 'green', 'orange', 'purple'];

const LESSON_PROGRESS_WIDTHS = [
  'w-[6.25%]',
  'w-[12.5%]',
  'w-[18.75%]',
  'w-[25%]',
  'w-[31.25%]',
  'w-[37.5%]',
  'w-[43.75%]',
  'w-[50%]',
  'w-[56.25%]',
  'w-[62.5%]',
  'w-[68.75%]',
  'w-[75%]',
  'w-[81.25%]',
  'w-[87.5%]',
  'w-[93.75%]',
  'w-full',
];

const QUIZ_PROGRESS_WIDTHS = ['w-1/5', 'w-2/5', 'w-3/5', 'w-4/5', 'w-full'];

const NUMBER_PROGRESS_WIDTHS = [
  'w-[10%]',
  'w-[20%]',
  'w-[30%]',
  'w-[40%]',
  'w-[50%]',
  'w-[60%]',
  'w-[70%]',
  'w-[80%]',
  'w-[90%]',
  'w-full',
];

const LETTER_PROGRESS_WIDTHS = [
  'w-[4%]',
  'w-[8%]',
  'w-[12%]',
  'w-[15%]',
  'w-[19%]',
  'w-[23%]',
  'w-[27%]',
  'w-[31%]',
  'w-[35%]',
  'w-[38%]',
  'w-[42%]',
  'w-[46%]',
  'w-[50%]',
  'w-[54%]',
  'w-[58%]',
  'w-[62%]',
  'w-[65%]',
  'w-[69%]',
  'w-[73%]',
  'w-[77%]',
  'w-[81%]',
  'w-[85%]',
  'w-[88%]',
  'w-[92%]',
  'w-[96%]',
  'w-full',
];

const ANIMAL_PROGRESS_WIDTHS = [
  'w-[5%]',
  'w-[10%]',
  'w-[15%]',
  'w-[20%]',
  'w-[25%]',
  'w-[30%]',
  'w-[35%]',
  'w-[40%]',
  'w-[45%]',
  'w-[50%]',
  'w-[55%]',
  'w-[60%]',
  'w-[65%]',
  'w-[70%]',
  'w-[75%]',
  'w-[80%]',
  'w-[85%]',
  'w-[90%]',
  'w-[95%]',
  'w-full',
];

const COLOR_PROGRESS_WIDTHS = [
  'w-[8%]',
  'w-[17%]',
  'w-[25%]',
  'w-[33%]',
  'w-[42%]',
  'w-[50%]',
  'w-[58%]',
  'w-[67%]',
  'w-[75%]',
  'w-[83%]',
  'w-[92%]',
  'w-full',
];

const BODY_PROGRESS_WIDTHS = COLOR_PROGRESS_WIDTHS;

type LearningCategory = 'fruits' | 'numbers' | 'letters' | 'animals' | 'colors' | 'body';

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [activeCategory, setActiveCategory] = useState<LearningCategory>('fruits');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [numberIndex, setNumberIndex] = useState<number>(0);
  const [letterIndex, setLetterIndex] = useState<number>(0);
  const [animalIndex, setAnimalIndex] = useState<number>(0);
  const [colorIndex, setColorIndex] = useState<number>(0);
  const [bodyIndex, setBodyIndex] = useState<number>(0);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [numberQuizQuestions, setNumberQuizQuestions] = useState<NumberQuizQuestion[]>([]);
  const [letterQuizQuestions, setLetterQuizQuestions] = useState<LetterQuizQuestion[]>([]);
  const [animalQuizQuestions, setAnimalQuizQuestions] = useState<AnimalQuizQuestion[]>([]);
  const [colorQuizQuestions, setColorQuizQuestions] = useState<ColorQuizQuestion[]>([]);
  const [bodyQuizQuestions, setBodyQuizQuestions] = useState<BodyQuizQuestion[]>([]);
  const [quizMode, setQuizMode] = useState<LearningCategory>('fruits');
  const [quizIndex, setQuizIndex] = useState<number>(0);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [progress, setProgress] = useState<LearningProgress>(() => loadProgress());
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [bgFailed, setBgFailed] = useState<boolean>(false);
  const toastTimerRef = useRef<number | null>(null);
  const isPopNavRef = useRef<boolean>(false);

  const showToast = useCallback((message: string) => {
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    setToastMessage(message);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMessage(null);
      toastTimerRef.current = null;
    }, 2000);
  }, []);

  useEffect(() => {
    warmUpVoices();
    if (typeof window !== 'undefined') {
      try {
        window.history.replaceState({ screen: 'home', activeCategory: 'fruits' }, '');
      } catch {
        // Ignore restricted history state contexts
      }
    }

    const handleVisibilityChange = () => {
      if (document.hidden) {
        stopCurrentSpeech();
      }
    };

    const handlePopState = (event: PopStateEvent) => {
      stopCurrentSpeech();
      isPopNavRef.current = true;
      const nextScreen = (event.state?.screen as Screen | undefined) ?? 'home';
      const nextCategory = (event.state?.activeCategory as LearningCategory | undefined) ?? 'fruits';
      setActiveCategory(nextCategory);
      setScreen(nextScreen);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('popstate', handlePopState);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('popstate', handlePopState);
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
      stopCurrentSpeech();
    };
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (isPopNavRef.current) {
      isPopNavRef.current = false;
      return;
    }
    try {
      const currentStateScreen = window.history.state?.screen as Screen | undefined;
      if (screen === 'home') {
        if (currentStateScreen && currentStateScreen !== 'home') {
          window.history.replaceState({ screen: 'home', activeCategory }, '');
        }
      } else if (currentStateScreen !== screen) {
        window.history.pushState({ screen, activeCategory }, '');
      }
    } catch {
      // Ignore restricted history contexts
    }
  }, [screen, activeCategory]);

  const handleSpeak = useCallback(
    (word: string, slow = false, audioKey?: string) => {
      void speakWord(word, () => showToast('Speech is not ready yet.'), { slow, audioKey });
    },
    [showToast]
  );

  const goHome = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    setScreen('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const openCategory = useCallback((category: LearningCategory) => {
    stopCurrentSpeech();
    playKidSound('tap');
    setActiveCategory(category);
    setScreen('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startFruitsLesson = useCallback(() => {
    setActiveCategory('fruits');
    setCurrentIndex(0);
    setScreen('lesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    handleSpeak(FRUITS[0].english);
  }, [handleSpeak]);

  const startNumbersLesson = useCallback(() => {
    setActiveCategory('numbers');
    setNumberIndex(0);
    setScreen('numbersLesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    handleSpeak(NUMBERS[0].english);
  }, [handleSpeak]);

  const startLettersLesson = useCallback(() => {
    setActiveCategory('letters');
    setLetterIndex(0);
    setScreen('lettersLesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    handleSpeak(LETTERS[0].upper, false, LETTERS[0].audioKey);
  }, [handleSpeak]);

  const startAnimalsLesson = useCallback(() => {
    setActiveCategory('animals');
    setAnimalIndex(0);
    setScreen('animalsLesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    handleSpeak(ANIMALS[0].english);
  }, [handleSpeak]);

  const startColorsLesson = useCallback(() => {
    setActiveCategory('colors');
    setColorIndex(0);
    setScreen('colorsLesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    handleSpeak(COLORS[0].english);
  }, [handleSpeak]);

  const startBodyLesson = useCallback(() => {
    setActiveCategory('body');
    setBodyIndex(0);
    setScreen('bodyLesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    handleSpeak(BODY_PARTS[0].english);
  }, [handleSpeak]);

  const finishLesson = useCallback(() => {
    playKidSound('celebrate');
    const updated = incrementCompletedLessons();
    setProgress(updated);
    setScreen('lessonComplete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const finishNumbersLesson = useCallback(() => {
    playKidSound('celebrate');
    const updated = incrementCompletedNumberLessons();
    setProgress(updated);
    setScreen('numbersComplete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const finishLettersLesson = useCallback(() => {
    playKidSound('celebrate');
    const updated = incrementCompletedLetterLessons();
    setProgress(updated);
    setScreen('lettersComplete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const finishAnimalsLesson = useCallback(() => {
    playKidSound('celebrate');
    const updated = incrementCompletedAnimalLessons();
    setProgress(updated);
    setScreen('animalsComplete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const finishColorsLesson = useCallback(() => {
    playKidSound('celebrate');
    const updated = incrementCompletedColorLessons();
    setProgress(updated);
    setScreen('colorsComplete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const finishBodyLesson = useCallback(() => {
    playKidSound('celebrate');
    const updated = incrementCompletedBodyLessons();
    setProgress(updated);
    setScreen('bodyComplete');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startFruitQuiz = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    const selected = shuffleArray(FRUITS).slice(0, 5);
    const questions: QuizQuestion[] = selected.map((correct) => {
      const distractors = shuffleArray(
        FRUITS.filter((item) => item.english !== correct.english)
      ).slice(0, 3);
      return {
        correct,
        options: shuffleArray([correct, ...distractors]),
      };
    });
    setActiveCategory('fruits');
    setQuizMode('fruits');
    setQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setScreen('quiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startNumbersQuiz = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    const selected = shuffleArray(NUMBERS).slice(0, 5);
    const questions: NumberQuizQuestion[] = selected.map((correct) => {
      const distractors = shuffleArray(
        NUMBERS.filter((item) => item.value !== correct.value)
      ).slice(0, 3);
      return {
        correct,
        options: shuffleArray([correct, ...distractors]),
      };
    });
    setActiveCategory('numbers');
    setQuizMode('numbers');
    setNumberQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setScreen('numbersQuiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startLettersQuiz = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    const selected = shuffleArray(LETTERS).slice(0, 5);
    const questions: LetterQuizQuestion[] = selected.map((correct) => {
      const distractors = shuffleArray(
        LETTERS.filter((item) => item.upper !== correct.upper)
      ).slice(0, 3);
      return {
        correct,
        options: shuffleArray([correct, ...distractors]),
      };
    });
    setActiveCategory('letters');
    setQuizMode('letters');
    setLetterQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setScreen('lettersQuiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startAnimalsQuiz = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    const selected = shuffleArray(ANIMALS).slice(0, 5);
    const questions: AnimalQuizQuestion[] = selected.map((correct) => {
      const distractors = shuffleArray(
        ANIMALS.filter((item) => item.english !== correct.english)
      ).slice(0, 3);
      return {
        correct,
        options: shuffleArray([correct, ...distractors]),
      };
    });
    setActiveCategory('animals');
    setQuizMode('animals');
    setAnimalQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setScreen('animalsQuiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startColorsQuiz = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    const selected = shuffleArray(COLORS).slice(0, 5);
    const questions: ColorQuizQuestion[] = selected.map((correct) => {
      const distractors = shuffleArray(
        COLORS.filter((item) => item.english !== correct.english)
      ).slice(0, 3);
      return {
        correct,
        options: shuffleArray([correct, ...distractors]),
      };
    });
    setActiveCategory('colors');
    setQuizMode('colors');
    setColorQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setScreen('colorsQuiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const startBodyQuiz = useCallback(() => {
    stopCurrentSpeech();
    playKidSound('tap');
    const selected = shuffleArray(BODY_PARTS).slice(0, 5);
    const questions: BodyQuizQuestion[] = selected.map((correct) => {
      const distractors = shuffleArray(
        BODY_PARTS.filter((item) => item.english !== correct.english)
      ).slice(0, 3);
      return {
        correct,
        options: shuffleArray([correct, ...distractors]),
      };
    });
    setActiveCategory('body');
    setQuizMode('body');
    setBodyQuizQuestions(questions);
    setQuizIndex(0);
    setQuizScore(0);
    setScreen('bodyQuiz');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handlePreviousFruit = () => {
    if (currentIndex > 0) {
      const nextIdx = currentIndex - 1;
      setCurrentIndex(nextIdx);
      handleSpeak(FRUITS[nextIdx].english);
    } else {
      playKidSound('tryAgain');
      showToast('This is the first fruit!');
    }
  };

  const handleNextFruit = () => {
    if (currentIndex < FRUITS.length - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      handleSpeak(FRUITS[nextIdx].english);
    } else {
      finishLesson();
    }
  };

  const handlePreviousNumber = () => {
    if (numberIndex > 0) {
      const nextIdx = numberIndex - 1;
      setNumberIndex(nextIdx);
      handleSpeak(NUMBERS[nextIdx].english);
    } else {
      playKidSound('tryAgain');
      showToast('This is the first number!');
    }
  };

  const handleNextNumber = () => {
    if (numberIndex < NUMBERS.length - 1) {
      const nextIdx = numberIndex + 1;
      setNumberIndex(nextIdx);
      handleSpeak(NUMBERS[nextIdx].english);
    } else {
      finishNumbersLesson();
    }
  };

  const handlePreviousLetter = () => {
    if (letterIndex > 0) {
      const nextIdx = letterIndex - 1;
      setLetterIndex(nextIdx);
      handleSpeak(LETTERS[nextIdx].upper, false, LETTERS[nextIdx].audioKey);
    } else {
      playKidSound('tryAgain');
      showToast('This is the first letter!');
    }
  };

  const handleNextLetter = () => {
    if (letterIndex < LETTERS.length - 1) {
      const nextIdx = letterIndex + 1;
      setLetterIndex(nextIdx);
      handleSpeak(LETTERS[nextIdx].upper, false, LETTERS[nextIdx].audioKey);
    } else {
      finishLettersLesson();
    }
  };

  const handlePreviousAnimal = () => {
    if (animalIndex > 0) {
      const nextIdx = animalIndex - 1;
      setAnimalIndex(nextIdx);
      handleSpeak(ANIMALS[nextIdx].english);
    } else {
      playKidSound('tryAgain');
      showToast('This is the first animal!');
    }
  };

  const handleNextAnimal = () => {
    if (animalIndex < ANIMALS.length - 1) {
      const nextIdx = animalIndex + 1;
      setAnimalIndex(nextIdx);
      handleSpeak(ANIMALS[nextIdx].english);
    } else {
      finishAnimalsLesson();
    }
  };

  const handlePreviousColor = () => {
    if (colorIndex > 0) {
      const nextIdx = colorIndex - 1;
      setColorIndex(nextIdx);
      handleSpeak(COLORS[nextIdx].english);
    } else {
      playKidSound('tryAgain');
      showToast('This is the first color!');
    }
  };

  const handleNextColor = () => {
    if (colorIndex < COLORS.length - 1) {
      const nextIdx = colorIndex + 1;
      setColorIndex(nextIdx);
      handleSpeak(COLORS[nextIdx].english);
    } else {
      finishColorsLesson();
    }
  };

  const handlePreviousBodyPart = () => {
    if (bodyIndex > 0) {
      const nextIdx = bodyIndex - 1;
      setBodyIndex(nextIdx);
      handleSpeak(BODY_PARTS[nextIdx].english);
    } else {
      playKidSound('tryAgain');
      showToast('This is the first body part!');
    }
  };

  const handleNextBodyPart = () => {
    if (bodyIndex < BODY_PARTS.length - 1) {
      const nextIdx = bodyIndex + 1;
      setBodyIndex(nextIdx);
      handleSpeak(BODY_PARTS[nextIdx].english);
    } else {
      finishBodyLesson();
    }
  };

  const handleAnswerOption = (selectedOption: FruitWord) => {
    const currentQuestion = quizQuestions[quizIndex];
    if (!currentQuestion) return;

    stopCurrentSpeech();
    const isCorrect = selectedOption.english === currentQuestion.correct.english;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;

    if (isCorrect) {
      playKidSound('quizCorrect');
      setQuizScore(nextScore);
      showToast('Great job! ⭐');
    } else {
      playKidSound('quizWrong');
      showToast('Oops! Try next one!');
    }

    const nextIndex = quizIndex + 1;
    if (nextIndex >= quizQuestions.length) {
      const updated = updateBestQuizScore(nextScore);
      setProgress(updated);
      setQuizIndex(nextIndex);
      setScreen('quizResult');
      if (nextScore >= 3) {
        window.setTimeout(() => playKidSound('celebrate'), 480);
      }
    } else {
      setQuizIndex(nextIndex);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNumberAnswerOption = (selectedOption: NumberWord) => {
    const currentNumQuestion = numberQuizQuestions[quizIndex];
    if (!currentNumQuestion) return;

    stopCurrentSpeech();
    const isCorrect = selectedOption.value === currentNumQuestion.correct.value;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;

    if (isCorrect) {
      playKidSound('quizCorrect');
      setQuizScore(nextScore);
      showToast('Great job! ⭐');
    } else {
      playKidSound('quizWrong');
      showToast('Oops! Try next one!');
    }

    const nextIndex = quizIndex + 1;
    if (nextIndex >= numberQuizQuestions.length) {
      const updated = updateBestNumberQuizScore(nextScore);
      setProgress(updated);
      setQuizIndex(nextIndex);
      setScreen('quizResult');
      if (nextScore >= 3) {
        window.setTimeout(() => playKidSound('celebrate'), 480);
      }
    } else {
      setQuizIndex(nextIndex);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLetterAnswerOption = (selectedOption: LetterWord) => {
    const currentLetQuestion = letterQuizQuestions[quizIndex];
    if (!currentLetQuestion) return;

    stopCurrentSpeech();
    const isCorrect = selectedOption.upper === currentLetQuestion.correct.upper;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;

    if (isCorrect) {
      playKidSound('quizCorrect');
      setQuizScore(nextScore);
      showToast('Great job! ⭐');
    } else {
      playKidSound('quizWrong');
      showToast('Oops! Try next one!');
    }

    const nextIndex = quizIndex + 1;
    if (nextIndex >= letterQuizQuestions.length) {
      const updated = updateBestLetterQuizScore(nextScore);
      setProgress(updated);
      setQuizIndex(nextIndex);
      setScreen('quizResult');
      if (nextScore >= 3) {
        window.setTimeout(() => playKidSound('celebrate'), 480);
      }
    } else {
      setQuizIndex(nextIndex);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAnimalAnswerOption = (selectedOption: AnimalWord) => {
    const currentAnimalQuestion = animalQuizQuestions[quizIndex];
    if (!currentAnimalQuestion) return;

    stopCurrentSpeech();
    const isCorrect = selectedOption.english === currentAnimalQuestion.correct.english;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;

    if (isCorrect) {
      playKidSound('quizCorrect');
      setQuizScore(nextScore);
      showToast('Great job! ⭐');
    } else {
      playKidSound('quizWrong');
      showToast('Oops! Try next one!');
    }

    const nextIndex = quizIndex + 1;
    if (nextIndex >= animalQuizQuestions.length) {
      const updated = updateBestAnimalQuizScore(nextScore);
      setProgress(updated);
      setQuizIndex(nextIndex);
      setScreen('quizResult');
      if (nextScore >= 3) {
        window.setTimeout(() => playKidSound('celebrate'), 480);
      }
    } else {
      setQuizIndex(nextIndex);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleColorAnswerOption = (selectedOption: ColorWord) => {
    const currentColorQuestion = colorQuizQuestions[quizIndex];
    if (!currentColorQuestion) return;

    stopCurrentSpeech();
    const isCorrect = selectedOption.english === currentColorQuestion.correct.english;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;

    if (isCorrect) {
      playKidSound('quizCorrect');
      setQuizScore(nextScore);
      showToast('Great job! ⭐');
    } else {
      playKidSound('quizWrong');
      showToast('Oops! Try next one!');
    }

    const nextIndex = quizIndex + 1;
    if (nextIndex >= colorQuizQuestions.length) {
      const updated = updateBestColorQuizScore(nextScore);
      setProgress(updated);
      setQuizIndex(nextIndex);
      setScreen('quizResult');
      if (nextScore >= 3) {
        window.setTimeout(() => playKidSound('celebrate'), 480);
      }
    } else {
      setQuizIndex(nextIndex);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBodyAnswerOption = (selectedOption: BodyPartWord) => {
    const currentBodyQuestion = bodyQuizQuestions[quizIndex];
    if (!currentBodyQuestion) return;

    stopCurrentSpeech();
    const isCorrect = selectedOption.english === currentBodyQuestion.correct.english;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;

    if (isCorrect) {
      playKidSound('quizCorrect');
      setQuizScore(nextScore);
      showToast('Great job! ⭐');
    } else {
      playKidSound('quizWrong');
      showToast('Oops! Try next one!');
    }

    const nextIndex = quizIndex + 1;
    if (nextIndex >= bodyQuizQuestions.length) {
      const updated = updateBestBodyQuizScore(nextScore);
      setProgress(updated);
      setQuizIndex(nextIndex);
      setScreen('quizResult');
      if (nextScore >= 3) {
        window.setTimeout(() => playKidSound('celebrate'), 480);
      }
    } else {
      setQuizIndex(nextIndex);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentFruit = FRUITS[currentIndex];
  const currentNumber = NUMBERS[numberIndex];
  const currentLetter = LETTERS[letterIndex];
  const currentAnimal = ANIMALS[animalIndex];
  const currentColor = COLORS[colorIndex];
  const currentBodyPart = BODY_PARTS[bodyIndex];
  const currentQuestion = quizQuestions[quizIndex];
  const currentNumberQuestion = numberQuizQuestions[quizIndex];
  const currentLetterQuestion = letterQuizQuestions[quizIndex];
  const currentAnimalQuestion = animalQuizQuestions[quizIndex];
  const currentColorQuestion = colorQuizQuestions[quizIndex];
  const currentBodyQuestion = bodyQuizQuestions[quizIndex];
  const lessonPercent = Math.round(((currentIndex + 1) / FRUITS.length) * 100);
  const numberLessonPercent = Math.round(((numberIndex + 1) / NUMBERS.length) * 100);
  const letterLessonPercent = Math.round(((letterIndex + 1) / LETTERS.length) * 100);
  const animalLessonPercent = Math.round(((animalIndex + 1) / ANIMALS.length) * 100);
  const colorLessonPercent = Math.round(((colorIndex + 1) / COLORS.length) * 100);
  const bodyLessonPercent = Math.round(((bodyIndex + 1) / BODY_PARTS.length) * 100);
  const activeQuizLength =
    quizMode === 'numbers'
      ? numberQuizQuestions.length || 5
      : quizMode === 'letters'
        ? letterQuizQuestions.length || 5
        : quizMode === 'animals'
          ? animalQuizQuestions.length || 5
          : quizMode === 'colors'
            ? colorQuizQuestions.length || 5
            : quizMode === 'body'
              ? bodyQuizQuestions.length || 5
              : quizQuestions.length || 5;
  const activeBestQuizScore =
    quizMode === 'numbers'
      ? progress.bestNumberQuizScore
      : quizMode === 'letters'
        ? progress.bestLetterQuizScore
        : quizMode === 'animals'
          ? progress.bestAnimalQuizScore
          : quizMode === 'colors'
            ? progress.bestColorQuizScore
            : quizMode === 'body'
              ? progress.bestBodyQuizScore
              : progress.bestQuizScore;

  const quizResultMessage =
    quizScore === 5
      ? 'Perfect score! Amazing!'
      : quizScore >= 3
        ? 'Well done! Keep learning!'
        : 'Good try! Practice makes progress!';

  const activeCategoryBestScore =
    activeCategory === 'numbers'
      ? progress.bestNumberQuizScore
      : activeCategory === 'letters'
        ? progress.bestLetterQuizScore
        : activeCategory === 'animals'
          ? progress.bestAnimalQuizScore
          : activeCategory === 'colors'
            ? progress.bestColorQuizScore
            : activeCategory === 'body'
              ? progress.bestBodyQuizScore
              : progress.bestQuizScore;

  const getHeaderBadgeText = (): string => {
    switch (screen) {
      case 'category':
        return `${activeCategoryBestScore} / 5`;
      case 'lesson':
        return `${currentIndex + 1} / ${FRUITS.length}`;
      case 'lessonComplete':
        return `${FRUITS.length} / ${FRUITS.length}`;
      case 'numbersLesson':
        return `${numberIndex + 1} / ${NUMBERS.length}`;
      case 'numbersComplete':
        return `${NUMBERS.length} / ${NUMBERS.length}`;
      case 'lettersLesson':
        return `${letterIndex + 1} / ${LETTERS.length}`;
      case 'lettersComplete':
        return `${LETTERS.length} / ${LETTERS.length}`;
      case 'animalsLesson':
        return `${animalIndex + 1} / ${ANIMALS.length}`;
      case 'animalsComplete':
        return `${ANIMALS.length} / ${ANIMALS.length}`;
      case 'colorsLesson':
        return `${colorIndex + 1} / ${COLORS.length}`;
      case 'colorsComplete':
        return `${COLORS.length} / ${COLORS.length}`;
      case 'bodyLesson':
        return `${bodyIndex + 1} / ${BODY_PARTS.length}`;
      case 'bodyComplete':
        return `${BODY_PARTS.length} / ${BODY_PARTS.length}`;
      case 'quiz':
        return `${quizIndex + 1} / ${quizQuestions.length}`;
      case 'numbersQuiz':
        return `${quizIndex + 1} / ${numberQuizQuestions.length}`;
      case 'lettersQuiz':
        return `${quizIndex + 1} / ${letterQuizQuestions.length}`;
      case 'animalsQuiz':
        return `${quizIndex + 1} / ${animalQuizQuestions.length}`;
      case 'colorsQuiz':
        return `${quizIndex + 1} / ${colorQuizQuestions.length}`;
      case 'bodyQuiz':
        return `${quizIndex + 1} / ${bodyQuizQuestions.length}`;
      case 'quizResult':
        return `${quizScore} / ${activeQuizLength}`;
      case 'home':
      case 'progress':
        return `${Math.max(
          progress.bestQuizScore,
          progress.bestNumberQuizScore,
          progress.bestLetterQuizScore,
          progress.bestAnimalQuizScore,
          progress.bestColorQuizScore,
          progress.bestBodyQuizScore
        )} / 5`;
    }
  };

  const getProgressWidthClass = (): string => {
    switch (screen) {
      case 'category':
        return activeCategoryBestScore > 0
          ? QUIZ_PROGRESS_WIDTHS[Math.min(4, activeCategoryBestScore - 1)]
          : 'w-[12%]';
      case 'lesson':
        return LESSON_PROGRESS_WIDTHS[currentIndex] ?? 'w-full';
      case 'lessonComplete':
      case 'numbersComplete':
      case 'lettersComplete':
      case 'animalsComplete':
      case 'colorsComplete':
      case 'bodyComplete':
        return 'w-full';
      case 'numbersLesson':
        return NUMBER_PROGRESS_WIDTHS[numberIndex] ?? 'w-full';
      case 'lettersLesson':
        return LETTER_PROGRESS_WIDTHS[letterIndex] ?? 'w-full';
      case 'animalsLesson':
        return ANIMAL_PROGRESS_WIDTHS[animalIndex] ?? 'w-full';
      case 'colorsLesson':
        return COLOR_PROGRESS_WIDTHS[colorIndex] ?? 'w-full';
      case 'bodyLesson':
        return BODY_PROGRESS_WIDTHS[bodyIndex] ?? 'w-full';
      case 'quiz':
      case 'numbersQuiz':
      case 'lettersQuiz':
      case 'animalsQuiz':
      case 'colorsQuiz':
      case 'bodyQuiz':
        return QUIZ_PROGRESS_WIDTHS[quizIndex] ?? 'w-1/5';
      case 'quizResult':
        return QUIZ_PROGRESS_WIDTHS[Math.max(0, quizScore - 1)] ?? 'w-[12%]';
      case 'home':
      case 'progress': {
        const best = Math.max(
          progress.bestQuizScore,
          progress.bestNumberQuizScore,
          progress.bestLetterQuizScore,
          progress.bestAnimalQuizScore,
          progress.bestColorQuizScore,
          progress.bestBodyQuizScore
        );
        return best > 0 ? QUIZ_PROGRESS_WIDTHS[Math.min(4, best - 1)] : 'w-[12%]';
      }
    }
  };

  const getCategoryPill = (): { icon: React.ReactNode; title: string } => {
    switch (screen) {
      case 'home':
        return {
          icon: (
            <img
              src={FRUITS[0].imagePath}
              alt=""
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
            />
          ),
          title: 'English Kids',
        };
      case 'category':
        if (activeCategory === 'numbers') {
          return {
            icon: (
              <span
                className="w-6 h-6 rounded-full bg-white flex items-center justify-center font-display font-bold text-[10px] tracking-tight text-[#1374E8] leading-none drop-shadow-sm"
                aria-hidden="true"
              >
                123
              </span>
            ),
            title: 'Numbers',
          };
        }
        if (activeCategory === 'letters') {
          return {
            icon: (
              <span
                className="w-6 h-6 rounded-full bg-white flex items-center justify-center font-display font-bold text-[11px] text-[#0D9488] leading-none drop-shadow-sm"
                aria-hidden="true"
              >
                AB
              </span>
            ),
            title: 'Letters',
          };
        }
        if (activeCategory === 'animals') {
          return {
            icon: (
              <img
                src={ANIMALS[0].imagePath}
                alt=""
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
              />
            ),
            title: 'Animals',
          };
        }
        if (activeCategory === 'colors') {
          return {
            icon: (
              <span
                className="w-6 h-6 rounded-full bg-white flex items-center justify-center drop-shadow-sm"
                aria-hidden="true"
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4">
                  <circle cx="8" cy="14" r="4.5" fill="#EF4444" />
                  <circle cx="16" cy="14" r="4.5" fill="#22A7FF" />
                  <circle cx="12" cy="8" r="4.5" fill="#FFD426" />
                </svg>
              </span>
            ),
            title: 'Colors',
          };
        }
        if (activeCategory === 'body') {
          return {
            icon: (
              <img
                src={BODY_PARTS[6].imagePath}
                alt=""
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
              />
            ),
            title: 'Body Parts',
          };
        }
        return {
          icon: (
            <img
              src={FRUITS[4].imagePath}
              alt=""
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
            />
          ),
          title: 'Fruits',
        };
      case 'lesson':
        return {
          icon: (
            <img
              src={FRUITS[4].imagePath}
              alt=""
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
            />
          ),
          title: 'Fruits',
        };
      case 'numbersLesson':
        return {
          icon: (
            <span
              className="w-6 h-6 rounded-full bg-white flex items-center justify-center font-display font-bold text-[10px] tracking-tight text-[#1374E8] leading-none drop-shadow-sm"
              aria-hidden="true"
            >
              123
            </span>
          ),
          title: 'Numbers',
        };
      case 'lettersLesson':
        return {
          icon: (
            <span
              className="w-6 h-6 rounded-full bg-white flex items-center justify-center font-display font-bold text-[11px] text-[#0D9488] leading-none drop-shadow-sm"
              aria-hidden="true"
            >
              AB
            </span>
          ),
          title: 'Letters',
        };
      case 'animalsLesson':
        return {
          icon: (
            <img
              src={ANIMALS[0].imagePath}
              alt=""
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
            />
          ),
          title: 'Animals',
        };
      case 'colorsLesson':
        return {
          icon: (
            <span
              className="w-6 h-6 rounded-full bg-white flex items-center justify-center drop-shadow-sm"
              aria-hidden="true"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4">
                <circle cx="8" cy="14" r="4.5" fill="#EF4444" />
                <circle cx="16" cy="14" r="4.5" fill="#22A7FF" />
                <circle cx="12" cy="8" r="4.5" fill="#FFD426" />
              </svg>
            </span>
          ),
          title: 'Colors',
        };
      case 'bodyLesson':
        return {
          icon: (
            <img
              src={BODY_PARTS[6].imagePath}
              alt=""
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-contain bg-white p-0.5 drop-shadow-sm"
            />
          ),
          title: 'Body Parts',
        };
      case 'lessonComplete':
      case 'numbersComplete':
      case 'lettersComplete':
      case 'animalsComplete':
      case 'colorsComplete':
      case 'bodyComplete':
        return {
          icon: <Trophy className="w-6 h-6 text-[#FFE23B] fill-[#FFE23B]" aria-hidden="true" />,
          title: 'Great Job!',
        };
      case 'quiz':
        return {
          icon: <Target className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'Fruit Quiz',
        };
      case 'numbersQuiz':
        return {
          icon: <Target className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'Number Quiz',
        };
      case 'lettersQuiz':
        return {
          icon: <Target className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'Letter Quiz',
        };
      case 'animalsQuiz':
        return {
          icon: <Target className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'Animal Quiz',
        };
      case 'colorsQuiz':
        return {
          icon: <Target className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'Color Quiz',
        };
      case 'bodyQuiz':
        return {
          icon: <Target className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'Body Quiz',
        };
      case 'quizResult':
        return {
          icon: <Trophy className="w-6 h-6 text-[#FFE23B] fill-[#FFE23B]" aria-hidden="true" />,
          title: 'Quiz Result',
        };
      case 'progress':
        return {
          icon: <BarChart3 className="w-6 h-6 text-[#FFE23B]" aria-hidden="true" />,
          title: 'My Progress',
        };
    }
  };

  const categoryPill = getCategoryPill();

  return (
    <div className="min-h-[100dvh] w-full bg-[linear-gradient(180deg,#7DD3FC_0%,#BAE6FD_55%,#A7E97F_100%)] flex items-center justify-center sm:p-4 overflow-x-hidden">
      <div className="relative w-full sm:max-w-[430px] min-h-[100dvh] sm:min-h-0 sm:h-[min(94dvh,840px)] sm:rounded-[36px] sm:border-[4px] sm:border-white/85 sm:shadow-[0_24px_60px_rgba(12,72,145,0.3)] bg-[linear-gradient(180deg,#52C7FF_0%,#9BE5FF_58%,#6FD636_100%)] overflow-y-auto overflow-x-hidden flex flex-col items-center">
        {!bgFailed && (
          <img
            src={meadowPortrait}
            alt=""
            aria-hidden="true"
            referrerPolicy="no-referrer"
            onError={() => setBgFailed(true)}
            className="absolute inset-0 w-full h-full object-cover object-center pointer-events-none select-none"
          />
        )}

        <main className="relative z-10 w-full flex-1 px-1 pt-[max(14px,env(safe-area-inset-top))] pb-[max(12px,env(safe-area-inset-bottom))] flex flex-col items-center justify-center">
          <div className="w-full flex flex-col items-center">
            <AppHeader
              badgeText={getHeaderBadgeText()}
              progressWidthClass={getProgressWidthClass()}
              onLogoClick={goHome}
            />

            <section className="relative w-[82%] max-w-[348px] mx-auto mt-4 px-4 pt-6 pb-3 rounded-[30px] border-[3.5px] border-[#26A7FF] ring-[3px] ring-white/85 bg-white shadow-[0_14px_28px_rgba(12,72,145,0.28)] flex flex-col items-center">
          {/* Floating category pill overlapping top border */}
          <div className="absolute -top-[19px] left-1/2 -translate-x-1/2 px-5 py-1 rounded-full border-[2.5px] border-white bg-[linear-gradient(180deg,#4BBFFF_0%,#1374E8_100%)] shadow-[0_3px_0_#0A469B,0_5px_10px_rgba(12,72,145,0.28)] flex items-center gap-1.5 whitespace-nowrap">
            <span
              className="pointer-events-none absolute inset-x-3 top-[2px] h-[38%] rounded-full bg-white/30"
              aria-hidden="true"
            />
            <span className="relative z-10 flex items-center justify-center shrink-0">
              {categoryPill.icon}
            </span>
            <span className="relative z-10 font-display font-bold text-[19px] leading-none text-white drop-shadow-[0_1px_2px_rgba(8,48,110,0.5)]">
              {categoryPill.title}
            </span>
          </div>

          {screen === 'home' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight">
                Hello, Little Learner!
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>
                  {progress.completedLessons +
                    progress.completedNumberLessons +
                    progress.completedLetterLessons +
                    progress.completedAnimalLessons +
                    progress.completedColorLessons +
                    progress.completedBodyLessons}{' '}
                  lessons completed
                </span>
              </div>

              <FruitVisual>
                <div className="flex flex-col items-center justify-center gap-0.5 px-1 bg-white">
                  <div className="flex items-center justify-center gap-2">
                    <img
                      src={FRUITS[0].imagePath}
                      alt="Cartoon apple"
                      referrerPolicy="no-referrer"
                      className="w-[42px] h-[46px] sm:w-[46px] sm:h-[50px] object-contain -rotate-6 select-none mix-blend-multiply"
                    />
                    <img
                      src={ANIMALS[0].imagePath}
                      alt="Cartoon lion"
                      referrerPolicy="no-referrer"
                      className="w-[44px] h-[46px] sm:w-[48px] sm:h-[50px] object-contain select-none mix-blend-multiply"
                    />
                    <img
                      src={BODY_PARTS[6].imagePath}
                      alt="Cartoon hand"
                      referrerPolicy="no-referrer"
                      className="w-[42px] h-[46px] sm:w-[46px] sm:h-[50px] object-contain rotate-6 select-none mix-blend-multiply"
                    />
                  </div>
                  <div className="flex items-center justify-center gap-1.5">
                    <LetterVisual item={LETTERS[0]} mode="badge" />
                    <NumberMascot item={NUMBERS[2]} showCountStars={false} size="sm" />
                    <ColorVisual item={COLORS[0]} mode="badge" />
                  </div>
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[25px] leading-none text-[#123B82] mt-0.5 mb-1.5">
                Play &amp; Learn!
              </h1>

              <div className="w-full mb-2 px-2.5 py-1 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[11.5px] sm:text-[12px]">
                  Fruits, Numbers, Letters, Animals, Colors &amp; Body!
                </span>
              </div>

              <div className="w-full flex flex-col gap-1.5">
                <div className="w-full grid grid-cols-2 gap-1.5">
                  <ActionButton
                    label="Fruits"
                    color="green"
                    className="text-[14px] px-2 gap-1.5 min-h-[38px]"
                    icon={<Play className="w-4 h-4 fill-white" />}
                    onClick={() => openCategory('fruits')}
                  />
                  <ActionButton
                    label="Numbers"
                    color="blue"
                    className="text-[14px] px-2 gap-1.5 min-h-[38px]"
                    icon={<Play className="w-4 h-4 fill-white" />}
                    onClick={() => openCategory('numbers')}
                  />
                  <ActionButton
                    label="Letters"
                    color="teal"
                    className="text-[14px] px-2 gap-1.5 min-h-[38px]"
                    icon={<Play className="w-4 h-4 fill-white" />}
                    onClick={() => openCategory('letters')}
                  />
                  <ActionButton
                    label="Animals"
                    color="orange"
                    className="text-[14px] px-2 gap-1.5 min-h-[38px]"
                    icon={<Play className="w-4 h-4 fill-white" />}
                    onClick={() => openCategory('animals')}
                  />
                  <ActionButton
                    label="Colors"
                    color="pink"
                    className="text-[14px] px-2 gap-1.5 min-h-[38px]"
                    icon={<Play className="w-4 h-4 fill-white" />}
                    onClick={() => openCategory('colors')}
                  />
                  <ActionButton
                    label="Body Parts"
                    color="indigo"
                    className="text-[13.5px] sm:text-[14px] px-2 gap-1.5 min-h-[38px]"
                    icon={<Play className="w-4 h-4 fill-white" />}
                    onClick={() => openCategory('body')}
                  />
                </div>
                <ActionButton
                  label="My Progress"
                  color="purple"
                  className="text-[14px] px-2 gap-1.5 min-h-[38px]"
                  icon={<BarChart3 className="w-4 h-4" />}
                  onClick={() => {
                    playKidSound('tap');
                    setScreen('progress');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              </div>
            </div>
          )}

          {screen === 'category' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[17px] text-[#133C82] leading-tight">
                {activeCategory === 'numbers'
                  ? `Count from 1 to ${NUMBERS.length}`
                  : activeCategory === 'letters'
                    ? `${LETTERS.length} Alphabet Letters`
                    : activeCategory === 'animals'
                      ? `${ANIMALS.length} Fun Animal Words`
                      : activeCategory === 'colors'
                        ? `${COLORS.length} Fun Color Words`
                        : activeCategory === 'body'
                          ? `${BODY_PARTS.length} Fun Body Words`
                          : `${FRUITS.length} Fun Fruit Words`}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[15px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Best Quiz: {activeCategoryBestScore} / 5</span>
              </div>

              {activeCategory === 'fruits' && (
                <FruitVisual
                  imagePath={FRUITS[0].imagePath}
                  alt="Fruits category"
                  label="Fruits"
                />
              )}
              {activeCategory === 'numbers' && (
                <FruitVisual>
                  <NumberMascot item={NUMBERS[2]} showCountStars={false} />
                </FruitVisual>
              )}
              {activeCategory === 'letters' && (
                <FruitVisual>
                  <LetterVisual item={LETTERS[0]} mode="pair" />
                </FruitVisual>
              )}
              {activeCategory === 'animals' && (
                <FruitVisual
                  imagePath={ANIMALS[0].imagePath}
                  alt="Animals category"
                  label="Animals"
                />
              )}
              {activeCategory === 'colors' && (
                <FruitVisual>
                  <ColorVisual item={COLORS[0]} />
                </FruitVisual>
              )}
              {activeCategory === 'body' && (
                <FruitVisual
                  imagePath={BODY_PARTS[6].imagePath}
                  alt="Body parts category"
                  label="Body Parts"
                />
              )}

              <h1 className="font-display font-bold text-[32px] leading-none text-[#123B82] mt-0.5 mb-2">
                {activeCategory === 'numbers'
                  ? 'Numbers 1–10'
                  : activeCategory === 'letters'
                    ? 'Letters A–Z'
                    : activeCategory === 'animals'
                      ? 'Animals'
                      : activeCategory === 'colors'
                        ? 'Colors'
                        : activeCategory === 'body'
                          ? 'Body Parts'
                          : 'Fruits'}
              </h1>

              <div className="w-full mb-3 px-4 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Choose Lesson or Quiz!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Start Lesson"
                  color="green"
                  icon={<Play className="w-5 h-5 fill-white" />}
                  onClick={
                    activeCategory === 'numbers'
                      ? startNumbersLesson
                      : activeCategory === 'letters'
                        ? startLettersLesson
                        : activeCategory === 'animals'
                          ? startAnimalsLesson
                          : activeCategory === 'colors'
                            ? startColorsLesson
                            : activeCategory === 'body'
                              ? startBodyLesson
                              : startFruitsLesson
                  }
                />
                <ActionButton
                  label={
                    activeCategory === 'numbers'
                      ? 'Numbers Quiz'
                      : activeCategory === 'letters'
                        ? 'Letters Quiz'
                        : activeCategory === 'animals'
                          ? 'Animals Quiz'
                          : activeCategory === 'colors'
                            ? 'Colors Quiz'
                            : activeCategory === 'body'
                              ? 'Body Quiz'
                              : 'Fruits Quiz'
                  }
                  color="orange"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={
                    activeCategory === 'numbers'
                      ? startNumbersQuiz
                      : activeCategory === 'letters'
                        ? startLettersQuiz
                        : activeCategory === 'animals'
                          ? startAnimalsQuiz
                          : activeCategory === 'colors'
                            ? startColorsQuiz
                            : activeCategory === 'body'
                              ? startBodyQuiz
                              : startFruitQuiz
                  }
                />
              </div>
            </div>
          )}

          {screen === 'lesson' && currentFruit && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight tabular-nums">
                Word {currentIndex + 1} of {FRUITS.length}
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>{lessonPercent}% completed</span>
              </div>

              <FruitVisual
                key={currentFruit.english}
                imagePath={currentFruit.imagePath}
                alt={currentFruit.english}
                label={currentFruit.english}
              />

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-0.5 mb-2">
                {currentFruit.english}
              </h1>

              <div className="w-full mb-2 px-3.5 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Listen and repeat!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2">

                <ActionButton
                  label="Listen Again"
                  color="purple"
                  icon={<Mic className="w-4 h-4" />}
                  onClick={() => handleSpeak(currentFruit.english, true)}
                />

                <div className="w-full grid grid-cols-2 gap-2">
                  <ActionButton
                    label="Previous"
                    color="blue"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M17.5 9.5 L10 16 L17.5 22.5 L17.5 18.5 L23 18.5 L23 13.5 L17.5 13.5 Z"
                          fill="#1574E8"
                          stroke="#1574E8"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="left"
                    onClick={handlePreviousFruit}
                  />
                  <ActionButton
                    label={currentIndex === FRUITS.length - 1 ? 'Finish' : 'Next'}
                    color="green"
                    className="text-[17px]"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M14.5 9.5 L22 16 L14.5 22.5 L14.5 18.5 L9 18.5 L9 13.5 L14.5 13.5 Z"
                          fill="#2DA80E"
                          stroke="#2DA80E"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="right"
                    onClick={handleNextFruit}
                  />
                </div>

                <ActionButton
                  label="Fruits Quiz"
                  color="orange"
                  icon={<Trophy className="w-4 h-4" />}
                  onClick={startFruitQuiz}
                />
              </div>
            </div>
          )}

          {screen === 'lessonComplete' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                Lesson Completed!
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>100% completed</span>
              </div>

              <FruitVisual>
                <div className="w-36 h-36 rounded-full bg-[linear-gradient(180deg,#E8FFE3_0%,#B7F6AC_100%)] border-[4px] border-[#5BD149] flex items-center justify-center shadow-md">
                  <CheckCircle2 className="w-20 h-20 text-[#25A817]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[36px] leading-none text-[#123B82] mt-1 mb-2.5">
                Amazing Work!
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Trophy className="w-5 h-5 text-[#E68A00] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[18px]">
                  You learned {FRUITS.length} fruits!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Take a Quiz"
                  color="green"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={startFruitQuiz}
                />
                <ActionButton
                  label="Learn Again"
                  color="orange"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={startFruitsLesson}
                />
              </div>
            </div>
          )}

          {screen === 'numbersLesson' && currentNumber && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight tabular-nums">
                Number {numberIndex + 1} of {NUMBERS.length}
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>{numberLessonPercent}% completed</span>
              </div>

              <FruitVisual key={`num-${currentNumber.value}`}>
                <NumberMascot item={currentNumber} showCountStars />
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-0.5 mb-2">
                {currentNumber.english}
              </h1>

              <div className="w-full mb-2 px-3.5 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Listen and repeat!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2">

                <ActionButton
                  label="Listen Again"
                  color="purple"
                  icon={<Mic className="w-4 h-4" />}
                  onClick={() => handleSpeak(currentNumber.english, true)}
                />

                <div className="w-full grid grid-cols-2 gap-2">
                  <ActionButton
                    label="Previous"
                    color="blue"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M17.5 9.5 L10 16 L17.5 22.5 L17.5 18.5 L23 18.5 L23 13.5 L17.5 13.5 Z"
                          fill="#1574E8"
                          stroke="#1574E8"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="left"
                    onClick={handlePreviousNumber}
                  />
                  <ActionButton
                    label={numberIndex === NUMBERS.length - 1 ? 'Finish' : 'Next'}
                    color="green"
                    className="text-[17px]"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M14.5 9.5 L22 16 L14.5 22.5 L14.5 18.5 L9 18.5 L9 13.5 L14.5 13.5 Z"
                          fill="#2DA80E"
                          stroke="#2DA80E"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="right"
                    onClick={handleNextNumber}
                  />
                </div>

                <ActionButton
                  label="Numbers Quiz"
                  color="orange"
                  icon={<Trophy className="w-4 h-4" />}
                  onClick={startNumbersQuiz}
                />
              </div>
            </div>
          )}

          {screen === 'numbersComplete' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                Numbers Completed!
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>100% completed</span>
              </div>

              <FruitVisual>
                <div className="w-36 h-36 rounded-full bg-[linear-gradient(180deg,#E8FFE3_0%,#B7F6AC_100%)] border-[4px] border-[#5BD149] flex items-center justify-center shadow-md">
                  <CheckCircle2 className="w-20 h-20 text-[#25A817]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[36px] leading-none text-[#123B82] mt-1 mb-2.5">
                Amazing Work!
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Trophy className="w-5 h-5 text-[#E68A00] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[18px]">
                  You learned numbers 1–{NUMBERS.length}!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Take Numbers Quiz"
                  color="green"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={startNumbersQuiz}
                />
                <ActionButton
                  label="Learn Again"
                  color="orange"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={startNumbersLesson}
                />
              </div>
            </div>
          )}

          {screen === 'lettersLesson' && currentLetter && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight tabular-nums">
                Letter {letterIndex + 1} of {LETTERS.length}
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>{letterLessonPercent}% completed</span>
              </div>

              <FruitVisual key={`let-${currentLetter.upper}`}>
                <LetterVisual item={currentLetter} mode="pair" />
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-0.5 mb-2">
                Letter {currentLetter.upper}
              </h1>

              <div className="w-full mb-2 px-3.5 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Listen and repeat!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2">
                <ActionButton
                  label="Listen Again"
                  color="purple"
                  icon={<Mic className="w-4 h-4" />}
                  onClick={() => handleSpeak(currentLetter.upper, true, currentLetter.audioKey)}
                />

                <div className="w-full grid grid-cols-2 gap-2">
                  <ActionButton
                    label="Previous"
                    color="blue"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M17.5 9.5 L10 16 L17.5 22.5 L17.5 18.5 L23 18.5 L23 13.5 L17.5 13.5 Z"
                          fill="#1574E8"
                          stroke="#1574E8"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="left"
                    onClick={handlePreviousLetter}
                  />
                  <ActionButton
                    label={letterIndex === LETTERS.length - 1 ? 'Finish' : 'Next'}
                    color="green"
                    className="text-[17px]"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M14.5 9.5 L22 16 L14.5 22.5 L14.5 18.5 L9 18.5 L9 13.5 L14.5 13.5 Z"
                          fill="#2DA80E"
                          stroke="#2DA80E"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="right"
                    onClick={handleNextLetter}
                  />
                </div>

                <ActionButton
                  label="Letters Quiz"
                  color="orange"
                  icon={<Trophy className="w-4 h-4" />}
                  onClick={startLettersQuiz}
                />
              </div>
            </div>
          )}

          {screen === 'lettersComplete' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                Alphabet Completed!
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>100% completed</span>
              </div>

              <FruitVisual>
                <div className="w-32 h-32 rounded-full bg-[linear-gradient(180deg,#E8FFE3_0%,#B7F6AC_100%)] border-[4px] border-[#5BD149] flex items-center justify-center shadow-md">
                  <CheckCircle2 className="w-16 h-16 text-[#25A817]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-1 mb-2">
                Amazing Work!
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Trophy className="w-5 h-5 text-[#E68A00] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  You learned all {LETTERS.length} letters!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Take Letters Quiz"
                  color="green"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={startLettersQuiz}
                />
                <ActionButton
                  label="Learn Again"
                  color="orange"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={startLettersLesson}
                />
              </div>
            </div>
          )}

          {screen === 'animalsLesson' && currentAnimal && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight tabular-nums">
                Animal {animalIndex + 1} of {ANIMALS.length}
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>{animalLessonPercent}% completed</span>
              </div>

              <FruitVisual
                key={currentAnimal.english}
                imagePath={currentAnimal.imagePath}
                alt={currentAnimal.english}
                label={currentAnimal.english}
              />

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-0.5 mb-2">
                {currentAnimal.english}
              </h1>

              <div className="w-full mb-2 px-3.5 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Listen and repeat!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2">
                <ActionButton
                  label="Listen Again"
                  color="purple"
                  icon={<Mic className="w-4 h-4" />}
                  onClick={() => handleSpeak(currentAnimal.english, true)}
                />

                <div className="w-full grid grid-cols-2 gap-2">
                  <ActionButton
                    label="Previous"
                    color="blue"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M17.5 9.5 L10 16 L17.5 22.5 L17.5 18.5 L23 18.5 L23 13.5 L17.5 13.5 Z"
                          fill="#1574E8"
                          stroke="#1574E8"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="left"
                    onClick={handlePreviousAnimal}
                  />
                  <ActionButton
                    label={animalIndex === ANIMALS.length - 1 ? 'Finish' : 'Next'}
                    color="green"
                    className="text-[17px]"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M14.5 9.5 L22 16 L14.5 22.5 L14.5 18.5 L9 18.5 L9 13.5 L14.5 13.5 Z"
                          fill="#2DA80E"
                          stroke="#2DA80E"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="right"
                    onClick={handleNextAnimal}
                  />
                </div>

                <ActionButton
                  label="Animals Quiz"
                  color="orange"
                  icon={<Trophy className="w-4 h-4" />}
                  onClick={startAnimalsQuiz}
                />
              </div>
            </div>
          )}

          {screen === 'animalsComplete' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                Animals Completed!
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>100% completed</span>
              </div>

              <FruitVisual>
                <div className="w-32 h-32 rounded-full bg-[linear-gradient(180deg,#E8FFE3_0%,#B7F6AC_100%)] border-[4px] border-[#5BD149] flex items-center justify-center shadow-md">
                  <CheckCircle2 className="w-16 h-16 text-[#25A817]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-1 mb-2">
                Amazing Work!
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Trophy className="w-5 h-5 text-[#E68A00] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  You learned {ANIMALS.length} animals!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Take Animals Quiz"
                  color="green"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={startAnimalsQuiz}
                />
                <ActionButton
                  label="Learn Again"
                  color="orange"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={startAnimalsLesson}
                />
              </div>
            </div>
          )}

          {screen === 'colorsLesson' && currentColor && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight tabular-nums">
                Color {colorIndex + 1} of {COLORS.length}
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>{colorLessonPercent}% completed</span>
              </div>

              <FruitVisual key={`col-${currentColor.english}`}>
                <ColorVisual item={currentColor} />
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-0.5 mb-2">
                {currentColor.english}
              </h1>

              <div className="w-full mb-2 px-3.5 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Listen and repeat!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2">
                <ActionButton
                  label="Listen Again"
                  color="purple"
                  icon={<Mic className="w-4 h-4" />}
                  onClick={() => handleSpeak(currentColor.english, true)}
                />

                <div className="w-full grid grid-cols-2 gap-2">
                  <ActionButton
                    label="Previous"
                    color="blue"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M17.5 9.5 L10 16 L17.5 22.5 L17.5 18.5 L23 18.5 L23 13.5 L17.5 13.5 Z"
                          fill="#1574E8"
                          stroke="#1574E8"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="left"
                    onClick={handlePreviousColor}
                  />
                  <ActionButton
                    label={colorIndex === COLORS.length - 1 ? 'Finish' : 'Next'}
                    color="green"
                    className="text-[17px]"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M14.5 9.5 L22 16 L14.5 22.5 L14.5 18.5 L9 18.5 L9 13.5 L14.5 13.5 Z"
                          fill="#2DA80E"
                          stroke="#2DA80E"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="right"
                    onClick={handleNextColor}
                  />
                </div>

                <ActionButton
                  label="Colors Quiz"
                  color="orange"
                  icon={<Trophy className="w-4 h-4" />}
                  onClick={startColorsQuiz}
                />
              </div>
            </div>
          )}

          {screen === 'colorsComplete' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                Colors Completed!
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>100% completed</span>
              </div>

              <FruitVisual>
                <div className="w-32 h-32 rounded-full bg-[linear-gradient(180deg,#E8FFE3_0%,#B7F6AC_100%)] border-[4px] border-[#5BD149] flex items-center justify-center shadow-md">
                  <CheckCircle2 className="w-16 h-16 text-[#25A817]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-1 mb-2">
                Amazing Work!
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Trophy className="w-5 h-5 text-[#E68A00] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  You learned {COLORS.length} colors!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Take Colors Quiz"
                  color="green"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={startColorsQuiz}
                />
                <ActionButton
                  label="Learn Again"
                  color="orange"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={startColorsLesson}
                />
              </div>
            </div>
          )}

          {screen === 'bodyLesson' && currentBodyPart && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[15px] text-[#133C82] leading-tight tabular-nums">
                Part {bodyIndex + 1} of {BODY_PARTS.length}
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>{bodyLessonPercent}% completed</span>
              </div>

              <FruitVisual
                key={currentBodyPart.english}
                imagePath={currentBodyPart.imagePath}
                alt={currentBodyPart.english}
                label={currentBodyPart.english}
              />

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-0.5 mb-2">
                {currentBodyPart.english}
              </h1>

              <div className="w-full mb-2 px-3.5 py-1.5 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-1.5 text-[#0E3C8A]">
                <Volume2 className="w-4 h-4 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[15px]">
                  Listen and repeat!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2">
                <ActionButton
                  label="Listen Again"
                  color="purple"
                  icon={<Mic className="w-4 h-4" />}
                  onClick={() => handleSpeak(currentBodyPart.english, true)}
                />

                <div className="w-full grid grid-cols-2 gap-2">
                  <ActionButton
                    label="Previous"
                    color="blue"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M17.5 9.5 L10 16 L17.5 22.5 L17.5 18.5 L23 18.5 L23 13.5 L17.5 13.5 Z"
                          fill="#1574E8"
                          stroke="#1574E8"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="left"
                    onClick={handlePreviousBodyPart}
                  />
                  <ActionButton
                    label={bodyIndex === BODY_PARTS.length - 1 ? 'Finish' : 'Next'}
                    color="green"
                    className="text-[17px]"
                    icon={
                      <svg viewBox="0 0 32 32" className="w-6 h-6" aria-hidden="true">
                        <circle cx="16" cy="16" r="15" fill="#FFFFFF" />
                        <path
                          d="M14.5 9.5 L22 16 L14.5 22.5 L14.5 18.5 L9 18.5 L9 13.5 L14.5 13.5 Z"
                          fill="#2DA80E"
                          stroke="#2DA80E"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                      </svg>
                    }
                    iconPosition="right"
                    onClick={handleNextBodyPart}
                  />
                </div>

                <ActionButton
                  label="Body Quiz"
                  color="orange"
                  icon={<Trophy className="w-4 h-4" />}
                  onClick={startBodyQuiz}
                />
              </div>
            </div>
          )}

          {screen === 'bodyComplete' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                Body Parts Completed!
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>100% completed</span>
              </div>

              <FruitVisual>
                <div className="w-32 h-32 rounded-full bg-[linear-gradient(180deg,#E8FFE3_0%,#B7F6AC_100%)] border-[4px] border-[#5BD149] flex items-center justify-center shadow-md">
                  <CheckCircle2 className="w-16 h-16 text-[#25A817]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[34px] leading-none text-[#123B82] mt-1 mb-2">
                Amazing Work!
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Trophy className="w-5 h-5 text-[#E68A00] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  You learned {BODY_PARTS.length} body parts!
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Take Body Quiz"
                  color="green"
                  icon={<Trophy className="w-5 h-5" />}
                  onClick={startBodyQuiz}
                />
                <ActionButton
                  label="Learn Again"
                  color="orange"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={startBodyLesson}
                />
              </div>
            </div>
          )}

          {screen === 'quiz' && currentQuestion && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight tabular-nums">
                Question {quizIndex + 1} of {quizQuestions.length}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Score: {quizScore} / {quizQuestions.length}</span>
              </div>

              <FruitVisual
                key={`quiz-${quizIndex}-${currentQuestion.correct.english}`}
                imagePath={currentQuestion.correct.imagePath}
                alt="Fruit quiz picture"
                label="?"
              />

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Target className="w-5 h-5 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  Which word matches this picture?
                </span>
              </div>

              <div className="w-full grid grid-cols-2 gap-2">
                {currentQuestion.options.map((option, index) => (
                  <ActionButton
                    key={option.english}
                    label={`${index + 1}. ${option.english}`}
                    color={OPTION_COLORS[index]}
                    className="text-[13px] sm:text-[15px] px-2"
                    onClick={() => handleAnswerOption(option)}
                  />
                ))}
              </div>

              <div className="w-full mt-2.5">
                <ActionButton
                  label="Listen"
                  color="pink"
                  icon={<Volume2 className="w-5 h-5" />}
                  onClick={() => handleSpeak(currentQuestion.correct.english)}
                />
              </div>
            </div>
          )}

          {screen === 'numbersQuiz' && currentNumberQuestion && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight tabular-nums">
                Question {quizIndex + 1} of {numberQuizQuestions.length}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Score: {quizScore} / {numberQuizQuestions.length}</span>
              </div>

              <FruitVisual key={`numquiz-${quizIndex}-${currentNumberQuestion.correct.value}`}>
                <NumberMascot item={currentNumberQuestion.correct} showCountStars />
              </FruitVisual>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Target className="w-5 h-5 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[16px]">
                  Which word matches this number?
                </span>
              </div>

              <div className="w-full grid grid-cols-2 gap-2.5">
                {currentNumberQuestion.options.map((option, index) => (
                  <ActionButton
                    key={option.value}
                    label={option.english}
                    color={OPTION_COLORS[index]}
                    onClick={() => handleNumberAnswerOption(option)}
                  />
                ))}
              </div>

              <div className="w-full mt-2.5">
                <ActionButton
                  label="Listen"
                  color="pink"
                  icon={<Volume2 className="w-5 h-5" />}
                  onClick={() => handleSpeak(currentNumberQuestion.correct.english)}
                />
              </div>
            </div>
          )}

          {screen === 'lettersQuiz' && currentLetterQuestion && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight tabular-nums">
                Question {quizIndex + 1} of {letterQuizQuestions.length}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Score: {quizScore} / {letterQuizQuestions.length}</span>
              </div>

              <FruitVisual key={`letquiz-${quizIndex}-${currentLetterQuestion.correct.upper}`}>
                <LetterVisual item={currentLetterQuestion.correct} mode="lowerOnly" />
              </FruitVisual>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Target className="w-5 h-5 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[16px]">
                  Which capital letter matches?
                </span>
              </div>

              <div className="w-full grid grid-cols-2 gap-2.5">
                {currentLetterQuestion.options.map((option, index) => (
                  <ActionButton
                    key={option.upper}
                    label={option.upper}
                    color={OPTION_COLORS[index]}
                    className="text-[20px]"
                    onClick={() => handleLetterAnswerOption(option)}
                  />
                ))}
              </div>

              <div className="w-full mt-2.5">
                <ActionButton
                  label="Listen"
                  color="pink"
                  icon={<Volume2 className="w-5 h-5" />}
                  onClick={() =>
                    handleSpeak(
                      currentLetterQuestion.correct.upper,
                      false,
                      currentLetterQuestion.correct.audioKey
                    )
                  }
                />
              </div>
            </div>
          )}

          {screen === 'animalsQuiz' && currentAnimalQuestion && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight tabular-nums">
                Question {quizIndex + 1} of {animalQuizQuestions.length}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Score: {quizScore} / {animalQuizQuestions.length}</span>
              </div>

              <FruitVisual
                key={`ani-quiz-${quizIndex}-${currentAnimalQuestion.correct.english}`}
                imagePath={currentAnimalQuestion.correct.imagePath}
                alt="Animal quiz picture"
                label="?"
              />

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Target className="w-5 h-5 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  Which animal matches?
                </span>
              </div>

              <div className="w-full grid grid-cols-2 gap-2">
                {currentAnimalQuestion.options.map((option, index) => (
                  <ActionButton
                    key={option.english}
                    label={`${index + 1}. ${option.english}`}
                    color={OPTION_COLORS[index]}
                    className="text-[13px] sm:text-[15px] px-2"
                    onClick={() => handleAnimalAnswerOption(option)}
                  />
                ))}
              </div>

              <div className="w-full mt-2.5">
                <ActionButton
                  label="Listen"
                  color="pink"
                  icon={<Volume2 className="w-5 h-5" />}
                  onClick={() => handleSpeak(currentAnimalQuestion.correct.english)}
                />
              </div>
            </div>
          )}

          {screen === 'colorsQuiz' && currentColorQuestion && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight tabular-nums">
                Question {quizIndex + 1} of {colorQuizQuestions.length}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Score: {quizScore} / {colorQuizQuestions.length}</span>
              </div>

              <FruitVisual key={`col-quiz-${quizIndex}-${currentColorQuestion.correct.english}`}>
                <ColorVisual item={currentColorQuestion.correct} />
              </FruitVisual>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Target className="w-5 h-5 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  Which color is this?
                </span>
              </div>

              <div className="w-full grid grid-cols-2 gap-2">
                {currentColorQuestion.options.map((option, index) => (
                  <ActionButton
                    key={option.english}
                    label={`${index + 1}. ${option.english}`}
                    color={OPTION_COLORS[index]}
                    className="text-[14px] sm:text-[15px] px-2"
                    onClick={() => handleColorAnswerOption(option)}
                  />
                ))}
              </div>

              <div className="w-full mt-2.5">
                <ActionButton
                  label="Listen"
                  color="pink"
                  icon={<Volume2 className="w-5 h-5" />}
                  onClick={() => handleSpeak(currentColorQuestion.correct.english)}
                />
              </div>
            </div>
          )}

          {screen === 'bodyQuiz' && currentBodyQuestion && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight tabular-nums">
                Question {quizIndex + 1} of {bodyQuizQuestions.length}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Score: {quizScore} / {bodyQuizQuestions.length}</span>
              </div>

              <FruitVisual
                key={`body-quiz-${quizIndex}-${currentBodyQuestion.correct.english}`}
                imagePath={currentBodyQuestion.correct.imagePath}
                alt="Body part quiz picture"
                label="?"
              />

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Target className="w-5 h-5 text-[#1876E8] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  Which body part is this?
                </span>
              </div>

              <div className="w-full grid grid-cols-2 gap-2">
                {currentBodyQuestion.options.map((option, index) => (
                  <ActionButton
                    key={option.english}
                    label={`${index + 1}. ${option.english}`}
                    color={OPTION_COLORS[index]}
                    className="text-[13.5px] sm:text-[15px] px-2"
                    onClick={() => handleBodyAnswerOption(option)}
                  />
                ))}
              </div>

              <div className="w-full mt-2.5">
                <ActionButton
                  label="Listen"
                  color="pink"
                  icon={<Volume2 className="w-5 h-5" />}
                  onClick={() => handleSpeak(currentBodyQuestion.correct.english)}
                />
              </div>
            </div>
          )}

          {screen === 'quizResult' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[19px] text-[#133C82] leading-tight">
                {quizMode === 'numbers'
                  ? 'Numbers Quiz Finished!'
                  : quizMode === 'letters'
                    ? 'Letters Quiz Finished!'
                    : quizMode === 'animals'
                      ? 'Animals Quiz Finished!'
                      : quizMode === 'colors'
                        ? 'Colors Quiz Finished!'
                        : quizMode === 'body'
                          ? 'Body Quiz Finished!'
                          : 'Challenge Finished!'}
              </p>

              <div className="mt-1 flex items-center justify-center gap-1.5 text-[18px] font-extrabold text-[#29A329] tabular-nums">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Best Score: {activeBestQuizScore} / 5</span>
              </div>

              <FruitVisual>
                <div className="w-32 h-32 rounded-full bg-[linear-gradient(180deg,#FFF6D6_0%,#FFE08A_100%)] border-[4px] border-[#FFC947] flex items-center justify-center shadow-md">
                  <Trophy className="w-16 h-16 text-[#E68A00] fill-[#FFD43B]" aria-hidden="true" />
                </div>
              </FruitVisual>

              <h1 className="font-display font-bold text-[44px] leading-none text-[#123B82] mt-1 mb-2.5 tabular-nums">
                {quizScore} / {activeQuizLength}
              </h1>

              <div className="w-full mb-3 px-4 py-2 rounded-full bg-[#CFEFFF] flex items-center justify-center gap-2 text-[#0E3C8A]">
                <Star className="w-5 h-5 text-[#FFC821] fill-[#FFC821] shrink-0" aria-hidden="true" />
                <span className="font-display font-bold text-[17px]">
                  {quizResultMessage}
                </span>
              </div>

              <div className="w-full flex flex-col gap-2.5">
                <ActionButton
                  label="Try Again"
                  color="green"
                  icon={<RotateCcw className="w-5 h-5" />}
                  onClick={
                    quizMode === 'numbers'
                      ? startNumbersQuiz
                      : quizMode === 'letters'
                        ? startLettersQuiz
                        : quizMode === 'animals'
                          ? startAnimalsQuiz
                          : quizMode === 'colors'
                            ? startColorsQuiz
                            : quizMode === 'body'
                              ? startBodyQuiz
                              : startFruitQuiz
                  }
                />
                <ActionButton
                  label="My Progress"
                  color="purple"
                  icon={<BarChart3 className="w-5 h-5" />}
                  onClick={() => {
                    playKidSound('tap');
                    setScreen('progress');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              </div>
            </div>
          )}

          {screen === 'progress' && (
            <div className="w-full flex flex-col items-center text-center">
              <p className="font-display font-bold text-[17px] text-[#133C82] leading-tight">
                Your Statistics
              </p>

              <div className="mt-0.5 flex items-center justify-center gap-1.5 text-[13.5px] font-extrabold text-[#29A329]">
                <Star className="w-4 h-4 text-[#FFC821] fill-[#FFC821] drop-shadow-[0_1px_1px_rgba(180,115,0,0.4)]" aria-hidden="true" />
                <span>Every step makes you better!</span>
              </div>

              <div className="w-full flex flex-col gap-1 my-1.5 tabular-nums">
                <div className="flex items-center justify-between px-3 py-1 rounded-[12px] bg-[#EAF6FF] border-2 border-[#BFE6FF]">
                  <div className="text-left">
                    <div className="font-display font-bold text-[14px] text-[#133C82] leading-none">
                      Fruits ({FRUITS.length})
                    </div>
                    <div className="text-[10.5px] font-extrabold text-[#2B4E84] mt-0.5">
                      Lessons: {progress.completedLessons}
                    </div>
                  </div>
                  <div className="font-display font-bold text-[16px] text-[#1D85F0] leading-none">
                    Best {progress.bestQuizScore}/5
                  </div>
                </div>

                <div className="flex items-center justify-between px-3 py-1 rounded-[12px] bg-[#FFF4E5] border-2 border-[#FFD296]">
                  <div className="text-left">
                    <div className="font-display font-bold text-[14px] text-[#8A4600] leading-none">
                      Numbers 1–10
                    </div>
                    <div className="text-[10.5px] font-extrabold text-[#A35600] mt-0.5">
                      Lessons: {progress.completedNumberLessons}
                    </div>
                  </div>
                  <div className="font-display font-bold text-[16px] text-[#EA7B00] leading-none">
                    Best {progress.bestNumberQuizScore}/5
                  </div>
                </div>

                <div className="flex items-center justify-between px-3 py-1 rounded-[12px] bg-[#E8FCF8] border-2 border-[#99E9DC]">
                  <div className="text-left">
                    <div className="font-display font-bold text-[14px] text-[#0F5E55] leading-none">
                      Letters A–Z
                    </div>
                    <div className="text-[10.5px] font-extrabold text-[#117A6D] mt-0.5">
                      Lessons: {progress.completedLetterLessons}
                    </div>
                  </div>
                  <div className="font-display font-bold text-[16px] text-[#0D9488] leading-none">
                    Best {progress.bestLetterQuizScore}/5
                  </div>
                </div>

                <div className="flex items-center justify-between px-3 py-1 rounded-[12px] bg-[#F4EEFF] border-2 border-[#D8C2FF]">
                  <div className="text-left">
                    <div className="font-display font-bold text-[14px] text-[#5B21B6] leading-none">
                      Animals ({ANIMALS.length})
                    </div>
                    <div className="text-[10.5px] font-extrabold text-[#7C3AED] mt-0.5">
                      Lessons: {progress.completedAnimalLessons}
                    </div>
                  </div>
                  <div className="font-display font-bold text-[16px] text-[#7C3AED] leading-none">
                    Best {progress.bestAnimalQuizScore}/5
                  </div>
                </div>

                <div className="flex items-center justify-between px-3 py-1 rounded-[12px] bg-[#FFF0F7] border-2 border-[#FBCFE8]">
                  <div className="text-left">
                    <div className="font-display font-bold text-[14px] text-[#9D174D] leading-none">
                      Colors ({COLORS.length})
                    </div>
                    <div className="text-[10.5px] font-extrabold text-[#BE185D] mt-0.5">
                      Lessons: {progress.completedColorLessons}
                    </div>
                  </div>
                  <div className="font-display font-bold text-[16px] text-[#DB2777] leading-none">
                    Best {progress.bestColorQuizScore}/5
                  </div>
                </div>

                <div className="flex items-center justify-between px-3 py-1 rounded-[12px] bg-[#EEF2FF] border-2 border-[#C7D2FE]">
                  <div className="text-left">
                    <div className="font-display font-bold text-[14px] text-[#312E81] leading-none">
                      Body Parts ({BODY_PARTS.length})
                    </div>
                    <div className="text-[10.5px] font-extrabold text-[#4338CA] mt-0.5">
                      Lessons: {progress.completedBodyLessons}
                    </div>
                  </div>
                  <div className="font-display font-bold text-[16px] text-[#4F46E5] leading-none">
                    Best {progress.bestBodyQuizScore}/5
                  </div>
                </div>
              </div>

              <div className="w-full grid grid-cols-2 gap-1.5">
                <ActionButton
                  label="Fruits Quiz"
                  color="green"
                  className="text-[13px] px-2 min-h-[34px]"
                  onClick={startFruitQuiz}
                />
                <ActionButton
                  label="Numbers Quiz"
                  color="blue"
                  className="text-[13px] px-2 min-h-[34px]"
                  onClick={startNumbersQuiz}
                />
                <ActionButton
                  label="Letters Quiz"
                  color="teal"
                  className="text-[13px] px-2 min-h-[34px]"
                  onClick={startLettersQuiz}
                />
                <ActionButton
                  label="Animals Quiz"
                  color="orange"
                  className="text-[13px] px-2 min-h-[34px]"
                  onClick={startAnimalsQuiz}
                />
                <ActionButton
                  label="Colors Quiz"
                  color="pink"
                  className="text-[13px] px-2 min-h-[34px]"
                  onClick={startColorsQuiz}
                />
                <ActionButton
                  label="Body Quiz"
                  color="indigo"
                  className="text-[13px] px-2 min-h-[34px]"
                  onClick={startBodyQuiz}
                />
              </div>
            </div>
          )}
            </section>
          </div>

          {screen !== 'home' && (
            <div className="w-[58%] max-w-[235px] mt-2.5 mb-1 shrink-0">
              <ActionButton
                label="Back to Home"
                color="blue"
                icon={<Home className="w-4 h-4" />}
                onClick={goHome}
              />
            </div>
          )}
        </main>
      </div>

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 rounded-full border-2 border-white bg-[#133C82]/95 text-white font-display font-bold text-[16px] shadow-xl pointer-events-none whitespace-nowrap"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
