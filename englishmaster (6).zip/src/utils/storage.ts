const STORAGE_KEY_COMPLETED = 'english_master_fruit_completed';
const STORAGE_KEY_BEST_SCORE = 'english_master_fruit_best_score';
const STORAGE_KEY_NUM_COMPLETED = 'english_master_number_completed';
const STORAGE_KEY_NUM_BEST_SCORE = 'english_master_number_best_score';
const STORAGE_KEY_LET_COMPLETED = 'english_master_letter_completed';
const STORAGE_KEY_LET_BEST_SCORE = 'english_master_letter_best_score';
const STORAGE_KEY_ANIMAL_COMPLETED = 'english_master_animal_completed';
const STORAGE_KEY_ANIMAL_BEST_SCORE = 'english_master_animal_best_score';
const STORAGE_KEY_COLOR_COMPLETED = 'english_master_color_completed';
const STORAGE_KEY_COLOR_BEST_SCORE = 'english_master_color_best_score';
const STORAGE_KEY_BODY_COMPLETED = 'english_master_body_completed';
const STORAGE_KEY_BODY_BEST_SCORE = 'english_master_body_best_score';

export interface LearningProgress {
  completedLessons: number;
  bestQuizScore: number;
  completedNumberLessons: number;
  bestNumberQuizScore: number;
  completedLetterLessons: number;
  bestLetterQuizScore: number;
  completedAnimalLessons: number;
  bestAnimalQuizScore: number;
  completedColorLessons: number;
  bestColorQuizScore: number;
  completedBodyLessons: number;
  bestBodyQuizScore: number;
}

export function loadProgress(): LearningProgress {
  try {
    const completedRaw = window.localStorage.getItem(STORAGE_KEY_COMPLETED);
    const bestRaw = window.localStorage.getItem(STORAGE_KEY_BEST_SCORE);
    const numCompletedRaw = window.localStorage.getItem(STORAGE_KEY_NUM_COMPLETED);
    const numBestRaw = window.localStorage.getItem(STORAGE_KEY_NUM_BEST_SCORE);
    const letCompletedRaw = window.localStorage.getItem(STORAGE_KEY_LET_COMPLETED);
    const letBestRaw = window.localStorage.getItem(STORAGE_KEY_LET_BEST_SCORE);
    const animalCompletedRaw = window.localStorage.getItem(STORAGE_KEY_ANIMAL_COMPLETED);
    const animalBestRaw = window.localStorage.getItem(STORAGE_KEY_ANIMAL_BEST_SCORE);
    const colorCompletedRaw = window.localStorage.getItem(STORAGE_KEY_COLOR_COMPLETED);
    const colorBestRaw = window.localStorage.getItem(STORAGE_KEY_COLOR_BEST_SCORE);
    const bodyCompletedRaw = window.localStorage.getItem(STORAGE_KEY_BODY_COMPLETED);
    const bodyBestRaw = window.localStorage.getItem(STORAGE_KEY_BODY_BEST_SCORE);
    const completedLessons = completedRaw ? Math.max(0, parseInt(completedRaw, 10) || 0) : 0;
    const bestQuizScore = bestRaw ? Math.max(0, parseInt(bestRaw, 10) || 0) : 0;
    const completedNumberLessons = numCompletedRaw
      ? Math.max(0, parseInt(numCompletedRaw, 10) || 0)
      : 0;
    const bestNumberQuizScore = numBestRaw ? Math.max(0, parseInt(numBestRaw, 10) || 0) : 0;
    const completedLetterLessons = letCompletedRaw
      ? Math.max(0, parseInt(letCompletedRaw, 10) || 0)
      : 0;
    const bestLetterQuizScore = letBestRaw ? Math.max(0, parseInt(letBestRaw, 10) || 0) : 0;
    const completedAnimalLessons = animalCompletedRaw
      ? Math.max(0, parseInt(animalCompletedRaw, 10) || 0)
      : 0;
    const bestAnimalQuizScore = animalBestRaw ? Math.max(0, parseInt(animalBestRaw, 10) || 0) : 0;
    const completedColorLessons = colorCompletedRaw
      ? Math.max(0, parseInt(colorCompletedRaw, 10) || 0)
      : 0;
    const bestColorQuizScore = colorBestRaw ? Math.max(0, parseInt(colorBestRaw, 10) || 0) : 0;
    const completedBodyLessons = bodyCompletedRaw
      ? Math.max(0, parseInt(bodyCompletedRaw, 10) || 0)
      : 0;
    const bestBodyQuizScore = bodyBestRaw ? Math.max(0, parseInt(bodyBestRaw, 10) || 0) : 0;
    return {
      completedLessons,
      bestQuizScore,
      completedNumberLessons,
      bestNumberQuizScore,
      completedLetterLessons,
      bestLetterQuizScore,
      completedAnimalLessons,
      bestAnimalQuizScore,
      completedColorLessons,
      bestColorQuizScore,
      completedBodyLessons,
      bestBodyQuizScore,
    };
  } catch {
    return {
      completedLessons: 0,
      bestQuizScore: 0,
      completedNumberLessons: 0,
      bestNumberQuizScore: 0,
      completedLetterLessons: 0,
      bestLetterQuizScore: 0,
      completedAnimalLessons: 0,
      bestAnimalQuizScore: 0,
      completedColorLessons: 0,
      bestColorQuizScore: 0,
      completedBodyLessons: 0,
      bestBodyQuizScore: 0,
    };
  }
}

export function incrementCompletedLessons(): LearningProgress {
  const current = loadProgress();
  const nextCompleted = current.completedLessons + 1;
  try {
    window.localStorage.setItem(STORAGE_KEY_COMPLETED, String(nextCompleted));
  } catch {
    // Ignore storage quota errors in restricted contexts
  }
  return {
    ...current,
    completedLessons: nextCompleted,
  };
}

export function updateBestQuizScore(score: number): LearningProgress {
  const current = loadProgress();
  if (score > current.bestQuizScore) {
    try {
      window.localStorage.setItem(STORAGE_KEY_BEST_SCORE, String(score));
    } catch {
      // Ignore storage quota errors in restricted contexts
    }
    return {
      ...current,
      bestQuizScore: score,
    };
  }
  return current;
}

export function incrementCompletedNumberLessons(): LearningProgress {
  const current = loadProgress();
  const nextCompleted = current.completedNumberLessons + 1;
  try {
    window.localStorage.setItem(STORAGE_KEY_NUM_COMPLETED, String(nextCompleted));
  } catch {
    // Ignore storage quota errors in restricted contexts
  }
  return {
    ...current,
    completedNumberLessons: nextCompleted,
  };
}

export function updateBestNumberQuizScore(score: number): LearningProgress {
  const current = loadProgress();
  if (score > current.bestNumberQuizScore) {
    try {
      window.localStorage.setItem(STORAGE_KEY_NUM_BEST_SCORE, String(score));
    } catch {
      // Ignore storage quota errors in restricted contexts
    }
    return {
      ...current,
      bestNumberQuizScore: score,
    };
  }
  return current;
}

export function incrementCompletedLetterLessons(): LearningProgress {
  const current = loadProgress();
  const nextCompleted = current.completedLetterLessons + 1;
  try {
    window.localStorage.setItem(STORAGE_KEY_LET_COMPLETED, String(nextCompleted));
  } catch {
    // Ignore storage quota errors in restricted contexts
  }
  return {
    ...current,
    completedLetterLessons: nextCompleted,
  };
}

export function updateBestLetterQuizScore(score: number): LearningProgress {
  const current = loadProgress();
  if (score > current.bestLetterQuizScore) {
    try {
      window.localStorage.setItem(STORAGE_KEY_LET_BEST_SCORE, String(score));
    } catch {
      // Ignore storage quota errors in restricted contexts
    }
    return {
      ...current,
      bestLetterQuizScore: score,
    };
  }
  return current;
}

export function incrementCompletedAnimalLessons(): LearningProgress {
  const current = loadProgress();
  const nextCompleted = current.completedAnimalLessons + 1;
  try {
    window.localStorage.setItem(STORAGE_KEY_ANIMAL_COMPLETED, String(nextCompleted));
  } catch {
    // Ignore storage quota errors in restricted contexts
  }
  return {
    ...current,
    completedAnimalLessons: nextCompleted,
  };
}

export function updateBestAnimalQuizScore(score: number): LearningProgress {
  const current = loadProgress();
  if (score > current.bestAnimalQuizScore) {
    try {
      window.localStorage.setItem(STORAGE_KEY_ANIMAL_BEST_SCORE, String(score));
    } catch {
      // Ignore storage quota errors in restricted contexts
    }
    return {
      ...current,
      bestAnimalQuizScore: score,
    };
  }
  return current;
}

export function incrementCompletedColorLessons(): LearningProgress {
  const current = loadProgress();
  const nextCompleted = current.completedColorLessons + 1;
  try {
    window.localStorage.setItem(STORAGE_KEY_COLOR_COMPLETED, String(nextCompleted));
  } catch {
    // Ignore storage quota errors in restricted contexts
  }
  return {
    ...current,
    completedColorLessons: nextCompleted,
  };
}

export function updateBestColorQuizScore(score: number): LearningProgress {
  const current = loadProgress();
  if (score > current.bestColorQuizScore) {
    try {
      window.localStorage.setItem(STORAGE_KEY_COLOR_BEST_SCORE, String(score));
    } catch {
      // Ignore storage quota errors in restricted contexts
    }
    return {
      ...current,
      bestColorQuizScore: score,
    };
  }
  return current;
}

export function incrementCompletedBodyLessons(): LearningProgress {
  const current = loadProgress();
  const nextCompleted = current.completedBodyLessons + 1;
  try {
    window.localStorage.setItem(STORAGE_KEY_BODY_COMPLETED, String(nextCompleted));
  } catch {
    // Ignore storage quota errors in restricted contexts
  }
  return {
    ...current,
    completedBodyLessons: nextCompleted,
  };
}

export function updateBestBodyQuizScore(score: number): LearningProgress {
  const current = loadProgress();
  if (score > current.bestBodyQuizScore) {
    try {
      window.localStorage.setItem(STORAGE_KEY_BODY_BEST_SCORE, String(score));
    } catch {
      // Ignore storage quota errors in restricted contexts
    }
    return {
      ...current,
      bestBodyQuizScore: score,
    };
  }
  return current;
}
