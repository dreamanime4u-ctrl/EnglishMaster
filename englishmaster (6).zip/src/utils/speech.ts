const PREFERRED_VOICE_PATTERNS = [
  /microsoft ana online/i,
  /aria online/i,
  /jenny online/i,
  /ava online/i,
  /emma online/i,
  /google us english/i,
  /google uk english female/i,
  /samantha/i,
  /aria/i,
  /jenny/i,
  /ava/i,
  /allison/i,
  /victoria/i,
  /karen/i,
  /emma/i,
  /libby/i,
  /sonia/i,
  /tessa/i,
  /zira/i,
  /hazel/i,
  /susan/i,
  /serena/i,
  /siri/i,
  /natural/i,
  /online/i,
  /female/i,
];

const AVOID_VOICE_PATTERNS = [
  /zarvox/i,
  /trinoids/i,
  /boing/i,
  /bells/i,
  /bad news/i,
  /good news/i,
  /whisper/i,
  /cellos/i,
  /organ/i,
  /albert/i,
  /fred/i,
  /ralph/i,
  /espeak/i,
  /daniel/i,
  /alex/i,
  /david/i,
  /mark/i,
  /male/i,
];

let cachedVoices: SpeechSynthesisVoice[] = [];
let lockedVoice: SpeechSynthesisVoice | null = null;
let audioCtx: AudioContext | null = null;
let currentAudioElement: HTMLAudioElement | null = null;
let speechSeq = 0;
let neuralTtsDisabled = false;
const clientAudioCache = new Map<string, string>();
const inflightRequests = new Map<string, Promise<string | null>>();

export function warmUpVoices(): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  const load = () => {
    cachedVoices = window.speechSynthesis.getVoices();
    if (cachedVoices.length > 0 && !lockedVoice) {
      lockedVoice = pickKidFriendlyVoice();
    }
  };
  load();
  window.speechSynthesis.addEventListener?.('voiceschanged', load);
}

function pickKidFriendlyVoice(): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return null;
  }
  const voices = cachedVoices.length > 0 ? cachedVoices : window.speechSynthesis.getVoices();
  if (!voices.length) return null;

  const englishVoices = voices.filter((v) => v.lang.toLowerCase().startsWith('en'));
  const pool = englishVoices.length > 0 ? englishVoices : voices;

  let bestVoice: SpeechSynthesisVoice | null = null;
  let bestScore = -Infinity;

  for (const voice of pool) {
    let score = 0;
    const label = `${voice.name} ${voice.voiceURI}`;

    if (voice.lang.toLowerCase() === 'en-us') score += 20;
    else if (voice.lang.toLowerCase() === 'en-gb') score += 12;
    else if (voice.lang.toLowerCase().startsWith('en')) score += 6;

    for (let i = 0; i < PREFERRED_VOICE_PATTERNS.length; i++) {
      if (PREFERRED_VOICE_PATTERNS[i].test(label)) {
        score += 60 - i;
        break;
      }
    }

    for (const bad of AVOID_VOICE_PATTERNS) {
      if (bad.test(label)) {
        score -= 45;
        break;
      }
    }

    if (!voice.localService) score += 12;

    if (score > bestScore) {
      bestScore = score;
      bestVoice = voice;
    }
  }

  return bestVoice;
}

export function stopCurrentSpeech(): void {
  if (currentAudioElement) {
    currentAudioElement.pause();
    currentAudioElement.currentTime = 0;
    currentAudioElement = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

async function fetchWordAudioUrl(word: string, customKey?: string): Promise<string | null> {
  const safeKey = customKey || word.toLowerCase().replace(/[^a-z0-9_-]/g, '_');
  const cached = clientAudioCache.get(safeKey);
  if (cached) return cached;

  const existing = inflightRequests.get(safeKey);
  if (existing) return existing;

  const requestPromise = (async () => {
    try {
      // 1. Check pre-generated studio WAV asset first (instant, zero API quota)
      const staticUrl = `/audio/${safeKey}.wav`;
      const staticHead = await fetch(staticUrl, { method: 'HEAD' });
      const contentType = staticHead.headers.get('content-type') || '';
      if (staticHead.ok && !contentType.includes('text/html')) {
        clientAudioCache.set(safeKey, staticUrl);
        return staticUrl;
      }

      if (neuralTtsDisabled) return null;

      // 2. Otherwise request from /api/tts
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ word, audioKey: customKey }),
      });
      if (response.status === 429) {
        neuralTtsDisabled = true;
        return null;
      }
      if (!response.ok) return null;
      const data = (await response.json()) as { audioBase64?: string; mimeType?: string };
      if (!data.audioBase64) return null;
      const dataUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
      clientAudioCache.set(safeKey, dataUrl);
      return dataUrl;
    } catch {
      return null;
    } finally {
      inflightRequests.delete(safeKey);
    }
  })();

  inflightRequests.set(safeKey, requestPromise);
  return requestPromise;
}

function fallbackBrowserSpeak(
  word: string,
  onUnavailable: () => void,
  slow: boolean
): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onUnavailable();
    return;
  }

  try {
    const synth = window.speechSynthesis;
    synth.cancel();

    const speakNow = () => {
      const utterance = new SpeechSynthesisUtterance(word);
      if (!lockedVoice) {
        lockedVoice = pickKidFriendlyVoice();
      }
      if (lockedVoice) {
        utterance.voice = lockedVoice;
        utterance.lang = lockedVoice.lang;
      } else {
        utterance.lang = 'en-US';
      }
      utterance.pitch = 1.1;
      utterance.rate = slow ? 0.74 : 0.88;
      utterance.volume = 1;
      synth.speak(utterance);
    };

    window.setTimeout(speakNow, 40);
  } catch {
    onUnavailable();
  }
}

export async function speakWord(
  word: string,
  onUnavailable: () => void,
  options?: { slow?: boolean; audioKey?: string }
): Promise<void> {
  const seq = ++speechSeq;
  const slow = Boolean(options?.slow);
  const safeKey = options?.audioKey || word.toLowerCase().replace(/[^a-z0-9_-]/g, '_');
  stopCurrentSpeech();

  const directUrl = clientAudioCache.get(safeKey) || `/audio/${safeKey}.wav`;
  try {
    const audio = new Audio(directUrl);
    audio.preload = 'auto';
    audio.setAttribute('playsinline', 'true');
    try {
      audio.preservesPitch = true;
      audio.playbackRate = slow ? 0.82 : 1.0;
    } catch {
      // Ignore playbackRate/preservesPitch restrictions on older Android WebViews
    }
    currentAudioElement = audio;
    await audio.play();
    if (seq !== speechSeq) {
      audio.pause();
      return;
    }
    clientAudioCache.set(safeKey, directUrl);
    return;
  } catch {
    if (seq !== speechSeq) return;
    if (currentAudioElement) {
      currentAudioElement = null;
    }
  }

  const audioUrl = await fetchWordAudioUrl(word, options?.audioKey);
  if (seq !== speechSeq) return;
  if (audioUrl) {
    try {
      const audio = new Audio(audioUrl);
      audio.preload = 'auto';
      audio.setAttribute('playsinline', 'true');
      try {
        audio.preservesPitch = true;
        audio.playbackRate = slow ? 0.82 : 1.0;
      } catch {
        // Ignore playbackRate/preservesPitch restrictions on older Android WebViews
      }
      currentAudioElement = audio;
      await audio.play();
      return;
    } catch {
      if (seq !== speechSeq) return;
    }
  }

  if (seq === speechSeq) {
    fallbackBrowserSpeak(word, onUnavailable, slow);
  }
}

export type KidSoundKind =
  | 'tap'
  | 'success'
  | 'tryAgain'
  | 'celebrate'
  | 'quizCorrect'
  | 'quizWrong';

export function playKidSound(kind: KidSoundKind): void {
  if (typeof window === 'undefined') return;
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return;

  try {
    if (!audioCtx) {
      audioCtx = new AudioCtx();
    }

    const triggerSound = () => {
      if (!audioCtx) return;
      const ctx = audioCtx;
      const now = ctx.currentTime;

      const playTone = (
        freq: number,
        startOffset: number,
        duration: number,
        gainPeak = 0.14,
        type: OscillatorType = 'triangle',
        endFreq?: number,
        lowpassHz?: number
      ) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, now + startOffset);
        if (endFreq && endFreq !== freq) {
          osc.frequency.exponentialRampToValueAtTime(
            Math.max(40, endFreq),
            now + startOffset + duration
          );
        }

        gain.gain.setValueAtTime(0.001, now + startOffset);
        gain.gain.exponentialRampToValueAtTime(gainPeak, now + startOffset + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, now + startOffset + duration);

        if (lowpassHz) {
          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(lowpassHz, now + startOffset);
          osc.connect(filter);
          filter.connect(gain);
        } else {
          osc.connect(gain);
        }

        gain.connect(ctx.destination);
        osc.start(now + startOffset);
        osc.stop(now + startOffset + duration + 0.03);
      };

      if (kind === 'tap') {
        playTone(523.25, 0, 0.09, 0.09, 'triangle');
      } else if (kind === 'success') {
        playTone(523.25, 0, 0.14, 0.15, 'triangle');
        playTone(659.25, 0.08, 0.16, 0.15, 'triangle');
        playTone(783.99, 0.16, 0.24, 0.16, 'triangle');
      } else if (kind === 'quizCorrect') {
        // Bright joyful reward chime (sparkly bell arpeggio)
        playTone(587.33, 0, 0.13, 0.2, 'sine');
        playTone(783.99, 0.075, 0.15, 0.21, 'sine');
        playTone(987.77, 0.15, 0.18, 0.22, 'sine');
        playTone(1174.66, 0.225, 0.36, 0.24, 'sine');
        playTone(2349.32, 0.225, 0.28, 0.07, 'sine');
      } else if (kind === 'quizWrong') {
        // Friendly, unmistakable descending cartoon "uh-oh" boop
        playTone(311.13, 0, 0.15, 0.22, 'sawtooth', 265, 680);
        playTone(233.08, 0.16, 0.3, 0.24, 'sawtooth', 155, 620);
      } else if (kind === 'tryAgain') {
        playTone(392.0, 0, 0.14, 0.11, 'triangle');
        playTone(349.23, 0.11, 0.18, 0.11, 'triangle');
      } else if (kind === 'celebrate') {
        playTone(523.25, 0, 0.14, 0.16, 'triangle');
        playTone(659.25, 0.1, 0.14, 0.16, 'triangle');
        playTone(783.99, 0.2, 0.14, 0.16, 'triangle');
        playTone(1046.5, 0.3, 0.36, 0.19, 'sine');
        playTone(2093.0, 0.3, 0.28, 0.06, 'sine');
      }
    };

    if (audioCtx.state === 'suspended') {
      void audioCtx.resume().then(triggerSound);
    } else {
      triggerSound();
    }
  } catch {
    // Ignore audio context errors on restricted devices
  }
}
