import appleFullImage from '../assets/images/fruit_apple_full_1794780711175.jpg';
import bananaFullImage from '../assets/images/fruit_banana_full_1794780814334.jpg';
import blackberryFullImage from '../assets/images/fruit_blackberry_full_1794780820743.jpg';
import blueberryFullImage from '../assets/images/fruit_blueberry_full_1794780820170.jpg';
import cherryFullImage from '../assets/images/fruit_cherry_full_1794780816561.jpg';
import coconutFullImage from '../assets/images/fruit_coconut_full_1794780818925.jpg';
import grapesFullImage from '../assets/images/fruit_grapes_full_1794780814055.jpg';
import kiwiFullImage from '../assets/images/fruit_kiwi_full_1794780819326.jpg';
import lemonFullImage from '../assets/images/fruit_lemon_full_1794780818009.jpg';
import mangoFullImage from '../assets/images/fruit_mango_full_1794780816514.jpg';
import orangeFullImage from '../assets/images/fruit_orange_full_1794780812863.jpg';
import peachFullImage from '../assets/images/fruit_peach_full_1794780817084.jpg';
import pearFullImage from '../assets/images/fruit_pear_full_1794780816007.jpg';
import pineappleFullImage from '../assets/images/fruit_pineapple_full_1794780815899.jpg';
import strawberryFullImage from '../assets/images/fruit_strawberry_full_1794780814450.jpg';
import watermelonFullImage from '../assets/images/fruit_watermelon_full_1794780815768.jpg';

export interface FruitWord {
  english: string;
  imagePath: string;
}

export const FRUITS: FruitWord[] = [
  { english: 'Apple', imagePath: appleFullImage },
  { english: 'Banana', imagePath: bananaFullImage },
  { english: 'Orange', imagePath: orangeFullImage },
  { english: 'Grapes', imagePath: grapesFullImage },
  { english: 'Strawberry', imagePath: strawberryFullImage },
  { english: 'Watermelon', imagePath: watermelonFullImage },
  { english: 'Pineapple', imagePath: pineappleFullImage },
  { english: 'Mango', imagePath: mangoFullImage },
  { english: 'Pear', imagePath: pearFullImage },
  { english: 'Peach', imagePath: peachFullImage },
  { english: 'Cherry', imagePath: cherryFullImage },
  { english: 'Lemon', imagePath: lemonFullImage },
  { english: 'Coconut', imagePath: coconutFullImage },
  { english: 'Kiwi', imagePath: kiwiFullImage },
  { english: 'Blueberry', imagePath: blueberryFullImage },
  { english: 'Blackberry', imagePath: blackberryFullImage },
];

export function shuffleArray<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}
