export interface LetterWord {
  upper: string;
  lower: string;
  audioKey: string;
  fillTop: string;
  fillBottom: string;
  stroke: string;
}

const PALETTE = [
  { fillTop: '#FF6B6B', fillBottom: '#E02424', stroke: '#8F1111' },
  { fillTop: '#FFB347', fillBottom: '#F97316', stroke: '#9A3412' },
  { fillTop: '#FFE45E', fillBottom: '#F59E0B', stroke: '#92400E' },
  { fillTop: '#7BE44A', fillBottom: '#22A818', stroke: '#14532D' },
  { fillTop: '#56CCFF', fillBottom: '#1677E8', stroke: '#0C3E8A' },
  { fillTop: '#C57BFF', fillBottom: '#8330E6', stroke: '#4C1D95' },
  { fillTop: '#FF82C4', fillBottom: '#E12883', stroke: '#831843' },
  { fillTop: '#4BE8D8', fillBottom: '#0891B2', stroke: '#155E75' },
];

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export const LETTERS: LetterWord[] = ALPHABET.map((upper, index) => {
  const lower = upper.toLowerCase();
  const colors = PALETTE[index % PALETTE.length];
  return {
    upper,
    lower,
    audioKey: `letter_${lower}`,
    ...colors,
  };
});
