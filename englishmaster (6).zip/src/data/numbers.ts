export interface NumberWord {
  value: number;
  english: string;
  fillTop: string;
  fillBottom: string;
  stroke: string;
  starColor: string;
}

export const NUMBERS: NumberWord[] = [
  {
    value: 1,
    english: 'One',
    fillTop: '#FF6B6B',
    fillBottom: '#E02424',
    stroke: '#8F1111',
    starColor: '#FF4D4D',
  },
  {
    value: 2,
    english: 'Two',
    fillTop: '#FFB347',
    fillBottom: '#F97316',
    stroke: '#9A3412',
    starColor: '#FF8A1F',
  },
  {
    value: 3,
    english: 'Three',
    fillTop: '#FFE45E',
    fillBottom: '#F59E0B',
    stroke: '#92400E',
    starColor: '#F5B000',
  },
  {
    value: 4,
    english: 'Four',
    fillTop: '#7BE44A',
    fillBottom: '#22A818',
    stroke: '#14532D',
    starColor: '#29B81D',
  },
  {
    value: 5,
    english: 'Five',
    fillTop: '#56CCFF',
    fillBottom: '#1677E8',
    stroke: '#0C3E8A',
    starColor: '#1E88F5',
  },
  {
    value: 6,
    english: 'Six',
    fillTop: '#C57BFF',
    fillBottom: '#8330E6',
    stroke: '#4C1D95',
    starColor: '#9344F2',
  },
  {
    value: 7,
    english: 'Seven',
    fillTop: '#FF82C4',
    fillBottom: '#E12883',
    stroke: '#831843',
    starColor: '#EB3B92',
  },
  {
    value: 8,
    english: 'Eight',
    fillTop: '#4BE8D8',
    fillBottom: '#0891B2',
    stroke: '#155E75',
    starColor: '#0EA5C6',
  },
  {
    value: 9,
    english: 'Nine',
    fillTop: '#818CF8',
    fillBottom: '#4338CA',
    stroke: '#312E81',
    starColor: '#5B55F0',
  },
  {
    value: 10,
    english: 'Ten',
    fillTop: '#FF7EB3',
    fillBottom: '#EC4899',
    stroke: '#831843',
    starColor: '#F43F8E',
  },
];
