export interface ColorWord {
  english: string;
  fillTop: string;
  fillBottom: string;
  stroke: string;
  shineColor: string;
}

export const COLORS: ColorWord[] = [
  {
    english: 'Red',
    fillTop: '#FF6B6B',
    fillBottom: '#DC2626',
    stroke: '#881313',
    shineColor: '#FCA5A5',
  },
  {
    english: 'Blue',
    fillTop: '#60C3FF',
    fillBottom: '#1D74E8',
    stroke: '#0C3E8A',
    shineColor: '#BAE6FD',
  },
  {
    english: 'Yellow',
    fillTop: '#FFF066',
    fillBottom: '#F5B800',
    stroke: '#92400E',
    shineColor: '#FEF9C3',
  },
  {
    english: 'Green',
    fillTop: '#7BE84A',
    fillBottom: '#1FA316',
    stroke: '#14532D',
    shineColor: '#BBF7D0',
  },
  {
    english: 'Orange',
    fillTop: '#FFB74D',
    fillBottom: '#F97316',
    stroke: '#9A3412',
    shineColor: '#FED7AA',
  },
  {
    english: 'Purple',
    fillTop: '#C57BFF',
    fillBottom: '#7E22CE',
    stroke: '#4C1D95',
    shineColor: '#E9D5FF',
  },
  {
    english: 'Pink',
    fillTop: '#FF8AC6',
    fillBottom: '#EC4899',
    stroke: '#831843',
    shineColor: '#FBCFE8',
  },
  {
    english: 'Brown',
    fillTop: '#B87449',
    fillBottom: '#7C3F1D',
    stroke: '#451A03',
    shineColor: '#E6B89C',
  },
  {
    english: 'Black',
    fillTop: '#4B5563',
    fillBottom: '#111827',
    stroke: '#030712',
    shineColor: '#9CA3AF',
  },
  {
    english: 'White',
    fillTop: '#FFFFFF',
    fillBottom: '#EBF3FA',
    stroke: '#64748B',
    shineColor: '#FFFFFF',
  },
  {
    english: 'Gray',
    fillTop: '#CBD5E1',
    fillBottom: '#64748B',
    stroke: '#334155',
    shineColor: '#F1F5F9',
  },
  {
    english: 'Gold',
    fillTop: '#FFE96B',
    fillBottom: '#D99B00',
    stroke: '#78350F',
    shineColor: '#FEF08A',
  },
];
