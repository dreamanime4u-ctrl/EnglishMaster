import bearFullImage from '../assets/images/animal_bear_full_1794784467009.jpg';
import catFullImage from '../assets/images/animal_cat_full_1794784467249.jpg';
import cowFullImage from '../assets/images/animal_cow_full_1794784466793.jpg';
import dogFullImage from '../assets/images/animal_dog_full_1794784466203.jpg';
import duckFullImage from '../assets/images/animal_duck_full_1794784468061.jpg';
import elephantFullImage from '../assets/images/animal_elephant_full_1794784464259.jpg';
import foxFullImage from '../assets/images/animal_fox_full_1794784469965.jpg';
import frogFullImage from '../assets/images/animal_frog_full_1794784469080.jpg';
import giraffeFullImage from '../assets/images/animal_giraffe_full_1794784464994.jpg';
import horseFullImage from '../assets/images/animal_horse_full_1794784467559.jpg';
import koalaFullImage from '../assets/images/animal_koala_full_1794784469928.jpg';
import lionFullImage from '../assets/images/animal_lion_full_1794784463667.jpg';
import monkeyFullImage from '../assets/images/animal_monkey_full_1794784465206.jpg';
import pandaFullImage from '../assets/images/animal_panda_full_1794784469794.jpg';
import penguinFullImage from '../assets/images/animal_penguin_full_1794784470108.jpg';
import rabbitFullImage from '../assets/images/animal_rabbit_full_1794784466651.jpg';
import sheepFullImage from '../assets/images/animal_sheep_full_1794784469112.jpg';
import tigerFullImage from '../assets/images/animal_tiger_full_1794784464769.jpg';
import turtleFullImage from '../assets/images/animal_turtle_full_1794784470832.jpg';
import zebraFullImage from '../assets/images/animal_zebra_full_1794784465817.jpg';

export interface AnimalWord {
  english: string;
  imagePath: string;
}

export const ANIMALS: AnimalWord[] = [
  { english: 'Lion', imagePath: lionFullImage },
  { english: 'Elephant', imagePath: elephantFullImage },
  { english: 'Giraffe', imagePath: giraffeFullImage },
  { english: 'Monkey', imagePath: monkeyFullImage },
  { english: 'Tiger', imagePath: tigerFullImage },
  { english: 'Zebra', imagePath: zebraFullImage },
  { english: 'Bear', imagePath: bearFullImage },
  { english: 'Rabbit', imagePath: rabbitFullImage },
  { english: 'Cat', imagePath: catFullImage },
  { english: 'Dog', imagePath: dogFullImage },
  { english: 'Cow', imagePath: cowFullImage },
  { english: 'Sheep', imagePath: sheepFullImage },
  { english: 'Horse', imagePath: horseFullImage },
  { english: 'Duck', imagePath: duckFullImage },
  { english: 'Frog', imagePath: frogFullImage },
  { english: 'Panda', imagePath: pandaFullImage },
  { english: 'Fox', imagePath: foxFullImage },
  { english: 'Koala', imagePath: koalaFullImage },
  { english: 'Penguin', imagePath: penguinFullImage },
  { english: 'Turtle', imagePath: turtleFullImage },
];
