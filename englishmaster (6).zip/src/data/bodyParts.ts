import armFullImage from '../assets/images/body_arm_full_1795024957412.jpg';
import earsFullImage from '../assets/images/body_ears_full_1795024955337.jpg';
import eyesFullImage from '../assets/images/body_eyes_full_1795024933626.jpg';
import fingersFullImage from '../assets/images/body_fingers_full_1795024934665.jpg';
import footFullImage from '../assets/images/body_foot_full_1795024936814.jpg';
import hairFullImage from '../assets/images/body_hair_clear.svg';
import handFullImage from '../assets/images/body_hand_full_1795024956260.jpg';
import headFullImage from '../assets/images/body_head_full_1795024931439.jpg';
import legFullImage from '../assets/images/body_leg_full_1795024956239.jpg';
import mouthFullImage from '../assets/images/body_mouth_full_1795024934270.jpg';
import noseFullImage from '../assets/images/body_nose_clear.svg';
import teethFullImage from '../assets/images/body_teeth_full_1795024937395.jpg';

export interface BodyPartWord {
  english: string;
  imagePath: string;
}

export const BODY_PARTS: BodyPartWord[] = [
  { english: 'Head', imagePath: headFullImage },
  { english: 'Hair', imagePath: hairFullImage },
  { english: 'Eyes', imagePath: eyesFullImage },
  { english: 'Nose', imagePath: noseFullImage },
  { english: 'Mouth', imagePath: mouthFullImage },
  { english: 'Ears', imagePath: earsFullImage },
  { english: 'Hand', imagePath: handFullImage },
  { english: 'Fingers', imagePath: fingersFullImage },
  { english: 'Arm', imagePath: armFullImage },
  { english: 'Leg', imagePath: legFullImage },
  { english: 'Foot', imagePath: footFullImage },
  { english: 'Teeth', imagePath: teethFullImage },
];
