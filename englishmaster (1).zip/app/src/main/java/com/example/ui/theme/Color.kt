package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cheerful 3D Storybook / Toybox Color Palette
val SkyBluePrimary = Color(0xFF3B82F6)
val SkyBlueDeep = Color(0xFF1D4ED8)
val SkyBlueLight = Color(0xFFDBEAFE)
val SkyBlueGlow = Color(0xFF60A5FA)

val SunnyAmber = Color(0xFFFFB703)
val SunnyAmberDeep = Color(0xFFD97706)
val SunnyAmberLight = Color(0xFFFEF3C7)

val CoralBerry = Color(0xFFFF5A5F)
val CoralBerryDeep = Color(0xFFDC2626)
val CoralBerryLight = Color(0xFFFFE4E6)

val MintEmerald = Color(0xFF10B981)
val MintEmeraldDeep = Color(0xFF047857)
val MintEmeraldLight = Color(0xFFD1FAE5)

val GrapeViolet = Color(0xFF8B5CF6)
val GrapeVioletDeep = Color(0xFF6D28D9)
val GrapeVioletLight = Color(0xFFEDE9FE)

val CreamCanvas = Color(0xFFF6F9FF)
val SoftWhiteCard = Color(0xFFFFFFFF)
val SoftSurfaceTint = Color(0xFFEEF4FF)

val InkDark = Color(0xFF1E293B)
val InkMuted = Color(0xFF64748B)
val CardBorderSoft = Color(0xFFE2E8F0)

// Dark Theme Tokens (Playful Night Sky)
val NightCanvas = Color(0xFF0F172A)
val NightCard = Color(0xFF1E293B)
val NightSurfaceVariant = Color(0xFF283548)
val NightTextPrimary = Color(0xFFF8FAFC)
val NightTextMuted = Color(0xFF94A3B8)
