package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.QuizMode
import com.example.model.StringsCatalog
import com.example.ui.components.Toy3DButton
import com.example.ui.components.Toy3DCard
import com.example.ui.theme.GrapeViolet
import com.example.ui.theme.GrapeVioletDeep
import com.example.ui.theme.GrapeVioletLight
import com.example.ui.theme.MintEmerald
import com.example.ui.theme.MintEmeraldDeep
import com.example.ui.theme.MintEmeraldLight
import com.example.ui.theme.SkyBlueDeep
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.SunnyAmber
import com.example.ui.theme.SunnyAmberDeep
import com.example.ui.theme.SunnyAmberLight
import com.example.viewmodel.EnglishMasterUiState

@Composable
fun QuizResultScreen(
    uiState: EnglishMasterUiState,
    onPlayAgain: (QuizMode) -> Unit,
    onReviewLessons: (QuizMode) -> Unit,
    onBackHome: () -> Unit
) {
    val strings = StringsCatalog.get(uiState.selectedLanguage)
    val result = uiState.latestQuizResult
    val score = result?.score ?: uiState.quizSession.score
    val total = result?.totalQuestions ?: uiState.quizSession.questions.size.coerceAtLeast(1)
    val starsEarned = result?.starsEarned ?: 0
    val isNewBest = result?.isNewBest == true
    val mode = result?.mode ?: uiState.quizSession.mode
    val pct = ((score.toFloat() / total.coerceAtLeast(1)) * 100).toInt()

    val (headline, subtitle) = when {
        pct >= 80 -> strings.resultTitleGreat to strings.resultSubtitleGreat
        pct >= 50 -> strings.resultTitleGood to strings.resultSubtitleGood
        else -> strings.resultTitleKeepGoing to strings.resultSubtitleKeepGoing
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GrapeVioletLight.copy(alpha = 0.7f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Toy3DCard(
                    containerColor = MaterialTheme.colorScheme.surface,
                    lipColor = Color(0xFFC4B5FD),
                    borderColor = GrapeViolet.copy(alpha = 0.35f),
                    cornerRadius = 30.dp,
                    lipDepth = 8.dp,
                    contentPadding = PaddingValues(20.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (isNewBest) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = SunnyAmberLight,
                                border = BorderStroke(1.5.dp, SunnyAmber)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = SunnyAmberDeep,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = strings.newBestBadge,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = SunnyAmberDeep
                                    )
                                }
                            }
                        }

                        Image(
                            painter = painterResource(id = R.drawable.img_quiz_trophy),
                            contentDescription = stringResource(R.string.cd_quiz_trophy),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(190.dp)
                                .clip(RoundedCornerShape(28.dp))
                        )

                        // Earned Stars Row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(3) { idx ->
                                Icon(
                                    imageVector = Icons.Rounded.Star,
                                    contentDescription = null,
                                    tint = if (idx < starsEarned) SunnyAmber else Color(0xFFCBD5E1),
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }

                        Text(
                            text = headline,
                            style = MaterialTheme.typography.displayMedium,
                            color = GrapeVioletDeep,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        // Score & Accuracy Badges
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = SkyBlueLight,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "$score / $total",
                                        style = MaterialTheme.typography.displayMedium,
                                        color = SkyBlueDeep,
                                        modifier = Modifier.testTag("result_score_text")
                                    )
                                    Text(
                                        text = strings.accuracyFormat(pct),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = SkyBlueDeep
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MintEmeraldLight,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "+$starsEarned ★",
                                        style = MaterialTheme.typography.displayMedium,
                                        color = MintEmeraldDeep
                                    )
                                    Text(
                                        text = strings.starsEarnedFormat(starsEarned),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MintEmeraldDeep,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                // Action Buttons
                Toy3DButton(
                    text = strings.playAgain,
                    icon = Icons.Rounded.Replay,
                    containerColor = SkyBluePrimary,
                    lipColor = SkyBlueDeep,
                    onClick = { onPlayAgain(mode) },
                    testTag = "btn_result_play_again",
                    height = 56.dp,
                    modifier = Modifier.fillMaxWidth()
                )

                Toy3DButton(
                    text = strings.reviewLessons,
                    icon = Icons.Rounded.MenuBook,
                    containerColor = SunnyAmber,
                    lipColor = SunnyAmberDeep,
                    contentColor = Color(0xFF1E293B),
                    onClick = { onReviewLessons(mode) },
                    testTag = "btn_result_review",
                    height = 56.dp,
                    modifier = Modifier.fillMaxWidth()
                )

                Toy3DButton(
                    text = strings.backHome,
                    icon = Icons.Rounded.Home,
                    containerColor = MintEmerald,
                    lipColor = MintEmeraldDeep,
                    onClick = onBackHome,
                    testTag = "btn_result_home",
                    height = 56.dp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}
