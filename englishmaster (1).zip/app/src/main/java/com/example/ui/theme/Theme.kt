package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage

private val LightColorScheme = lightColorScheme(
    primary = SkyBluePrimary,
    onPrimary = Color.White,
    primaryContainer = SkyBlueLight,
    onPrimaryContainer = SkyBlueDeep,
    secondary = SunnyAmber,
    onSecondary = InkDark,
    secondaryContainer = SunnyAmberLight,
    onSecondaryContainer = SunnyAmberDeep,
    tertiary = MintEmerald,
    onTertiary = Color.White,
    tertiaryContainer = MintEmeraldLight,
    onTertiaryContainer = MintEmeraldDeep,
    background = CreamCanvas,
    onBackground = InkDark,
    surface = SoftWhiteCard,
    onSurface = InkDark,
    surfaceVariant = SoftSurfaceTint,
    onSurfaceVariant = InkMuted,
    error = CoralBerry,
    onError = Color.White,
    errorContainer = CoralBerryLight,
    onErrorContainer = CoralBerryDeep,
    outline = CardBorderSoft
)

private val DarkColorScheme = darkColorScheme(
    primary = SkyBlueGlow,
    onPrimary = InkDark,
    primaryContainer = SkyBlueDeep,
    onPrimaryContainer = SkyBlueLight,
    secondary = SunnyAmber,
    onSecondary = InkDark,
    secondaryContainer = SunnyAmberDeep,
    onSecondaryContainer = SunnyAmberLight,
    tertiary = MintEmerald,
    onTertiary = InkDark,
    tertiaryContainer = MintEmeraldDeep,
    onTertiaryContainer = MintEmeraldLight,
    background = NightCanvas,
    onBackground = NightTextPrimary,
    surface = NightCard,
    onSurface = NightTextPrimary,
    surfaceVariant = NightSurfaceVariant,
    onSurfaceVariant = NightTextMuted,
    error = CoralBerry,
    onError = Color.White,
    errorContainer = CoralBerryDeep,
    onErrorContainer = CoralBerryLight,
    outline = Color(0xFF334155)
)

val AppShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(34.dp)
)

@Composable
fun EnglishMasterTheme(
    language: AppLanguage = AppLanguage.ENGLISH,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val typography = createAppTypography(isArabic = language == AppLanguage.ARABIC)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = AppShapes,
        content = content
    )
}
