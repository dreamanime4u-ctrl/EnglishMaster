package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.model.LessonItem

@Composable
fun LessonIllustration3D(
    item: LessonItem,
    modifier: Modifier = Modifier,
    isSpeaking: Boolean = false,
    animateFloat: Boolean = true,
    onTap: (() -> Unit)? = null
) {
    val infiniteTransition = rememberInfiniteTransition(label = "float_3d")
    val floatOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float_y"
    )
    val pulseScale by animateFloatAsState(
        targetValue = if (isSpeaking) 1.07f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 350f),
        label = "speak_scale"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring_alpha"
    )

    val interactionSource = remember { MutableInteractionSource() }
    val clickMod = if (onTap != null) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onTap
        )
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .semantics { contentDescription = item.englishWord }
            .then(clickMod),
        contentAlignment = Alignment.Center
    ) {
        // Soft 3D halo backdrop
        Box(
            modifier = Modifier
                .fillMaxSize(0.88f)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White,
                            item.containerTint,
                            item.primaryColor.copy(alpha = 0.16f)
                        )
                    ),
                    shape = CircleShape
                )
                .then(
                    if (isSpeaking) {
                        Modifier.border(
                            width = 4.dp,
                            color = item.primaryColor.copy(alpha = ringAlpha),
                            shape = CircleShape
                        )
                    } else {
                        Modifier
                    }
                )
        )

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .scale(pulseScale)
                .graphicsLayer {
                    if (animateFloat) {
                        translationY = floatOffset
                    }
                }
        ) {
            when (item.id) {
                "fruit_apple" -> draw3DApple()
                "fruit_banana" -> draw3DBanana()
                "fruit_strawberry" -> draw3DStrawberry()
                "fruit_orange" -> draw3DOrange()
                "fruit_watermelon" -> draw3DWatermelon()
                "fruit_grapes" -> draw3DGrapes()
                "fruit_pineapple" -> draw3DPineapple()
                "fruit_mango" -> draw3DMango()
                "animal_lion" -> draw3DLion()
                "animal_elephant" -> draw3DElephant()
                "animal_cat" -> draw3DCat()
                "animal_dog" -> draw3DDog()
                "animal_monkey" -> draw3DMonkey()
                "animal_giraffe" -> draw3DGiraffe()
                "animal_penguin" -> draw3DPenguin()
                "animal_rabbit" -> draw3DRabbit()
            }
        }
    }
}
