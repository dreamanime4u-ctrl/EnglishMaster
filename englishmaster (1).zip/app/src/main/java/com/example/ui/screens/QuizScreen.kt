package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LessonItem
import com.example.model.QuizMode
import com.example.model.QuizQuestionType
import com.example.model.StringsCatalog
import com.example.ui.components.LessonIllustration3D
import com.example.ui.components.Toy3DButton
import com.example.ui.components.Toy3DCard
import com.example.ui.theme.CoralBerry
import com.example.ui.theme.CoralBerryDeep
import com.example.ui.theme.CoralBerryLight
import com.example.ui.theme.MintEmerald
import com.example.ui.theme.MintEmeraldDeep
import com.example.ui.theme.MintEmeraldLight
import com.example.ui.theme.SkyBlueDeep
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.SunnyAmber
import com.example.ui.theme.SunnyAmberDeep
import com.example.ui.theme.SunnyAmberLight
import com.example.viewmodel.EnglishMasterUiState

@Composable
fun QuizScreen(
    uiState: EnglishMasterUiState,
    onBack: () -> Unit,
    onSpeakWord: (Boolean) -> Unit,
    onSelectOption: (LessonItem) -> Unit,
    onNextQuestion: () -> Unit
) {
    val strings = StringsCatalog.get(uiState.selectedLanguage)
    val session = uiState.quizSession
    val question = session.currentQuestion

    val quizTitle = when (session.mode) {
        QuizMode.FRUITS -> strings.quizTitleFruits
        QuizMode.ANIMALS -> strings.quizTitleAnimals
        QuizMode.MIXED -> strings.quizTitleMixed
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            SkyBlueLight.copy(alpha = 0.55f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            if (question == null) return@Box

            val totalQ = session.questions.size
            val progressFraction = (session.currentIndex + 1).toFloat() / totalQ.coerceAtLeast(1)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 760.dp)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 4.dp
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .testTag("quiz_back_button")
                                .minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = stringResource(R.string.cd_back_button),
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Text(
                        text = quizTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = SunnyAmberLight,
                        border = BorderStroke(1.5.dp, SunnyAmber)
                    ) {
                        Text(
                            text = strings.scoreBadgeFormat(session.score),
                            style = MaterialTheme.typography.titleMedium,
                            color = SunnyAmberDeep,
                            modifier = Modifier
                                .testTag("quiz_live_score")
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                // Progress bar + counter
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = strings.questionProgressFormat(session.currentIndex + 1, totalQ),
                        style = MaterialTheme.typography.labelLarge,
                        color = SkyBlueDeep
                    )
                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(CircleShape),
                        color = SkyBluePrimary,
                        trackColor = SkyBlueLight,
                        strokeCap = StrokeCap.Round
                    )
                }

                // Main Question & Options
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (question.type == QuizQuestionType.ILLUSTRATION_TO_WORD) {
                        Toy3DCard(
                            containerColor = MaterialTheme.colorScheme.surface,
                            lipColor = question.targetItem.primaryColor.copy(alpha = 0.25f),
                            borderColor = question.targetItem.primaryColor.copy(alpha = 0.35f),
                            contentPadding = PaddingValues(18.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = strings.promptWhatIsThis,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                                LessonIllustration3D(
                                    item = question.targetItem,
                                    isSpeaking = uiState.isSpeaking,
                                    onTap = { onSpeakWord(false) },
                                    modifier = Modifier.size(180.dp)
                                )
                            }
                        }

                        // 4 Word Choices
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            question.options.forEachIndexed { optIdx, option ->
                                WordOptionCard(
                                    option = option,
                                    isSelected = session.selectedOptionId == option.id,
                                    isCorrectTarget = option.id == question.targetItem.id,
                                    isSubmitted = session.isSubmitted,
                                    onClick = { onSelectOption(option) },
                                    modifier = Modifier.testTag("quiz_option_$optIdx")
                                )
                            }
                        }
                    } else {
                        // WORD_TO_ILLUSTRATION
                        Toy3DCard(
                            containerColor = MaterialTheme.colorScheme.surface,
                            lipColor = Color(0xFFC3D7FA),
                            borderColor = SkyBlueLight,
                            contentPadding = PaddingValues(18.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = strings.promptFindPicture,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text(
                                        text = question.targetItem.englishWord,
                                        style = MaterialTheme.typography.displayMedium.copy(
                                            fontSize = 36.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = SkyBlueDeep,
                                        textAlign = TextAlign.Center
                                    )
                                }
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Toy3DButton(
                                        text = strings.listen,
                                        icon = Icons.AutoMirrored.Rounded.VolumeUp,
                                        containerColor = SkyBluePrimary,
                                        lipColor = SkyBlueDeep,
                                        onClick = { onSpeakWord(false) },
                                        height = 48.dp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Toy3DButton(
                                        text = strings.listenAgain,
                                        icon = Icons.Rounded.Replay,
                                        containerColor = SunnyAmber,
                                        lipColor = SunnyAmberDeep,
                                        contentColor = Color(0xFF1E293B),
                                        onClick = { onSpeakWord(true) },
                                        height = 48.dp,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        // 2x2 Grid of 3D Illustrations
                        val rows = question.options.chunked(2)
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            rows.forEachIndexed { rIdx, pair ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    pair.forEachIndexed { cIdx, option ->
                                        val globalIdx = rIdx * 2 + cIdx
                                        IllustrationOptionCard(
                                            option = option,
                                            isSelected = session.selectedOptionId == option.id,
                                            isCorrectTarget = option.id == question.targetItem.id,
                                            isSubmitted = session.isSubmitted,
                                            onClick = { onSelectOption(option) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("quiz_option_$globalIdx")
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Instant Answer Feedback Banner
                    AnimatedVisibility(
                        visible = session.isSubmitted,
                        enter = fadeIn() + scaleIn(initialScale = 0.92f)
                    ) {
                        val isCorrect = session.selectedOptionId == question.targetItem.id
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isCorrect) MintEmeraldLight else CoralBerryLight,
                            border = BorderStroke(
                                1.5.dp,
                                if (isCorrect) MintEmerald else CoralBerry
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("quiz_feedback_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = if (isCorrect) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel,
                                    contentDescription = null,
                                    tint = if (isCorrect) MintEmeraldDeep else CoralBerryDeep,
                                    modifier = Modifier.size(28.dp)
                                )
                                Text(
                                    text = if (isCorrect) {
                                        strings.feedbackCorrect
                                    } else {
                                        strings.feedbackWrongFormat(question.targetItem.englishWord)
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isCorrect) MintEmeraldDeep else CoralBerryDeep
                                )
                            }
                        }
                    }
                }

                // Bottom Next / Finish Button
                if (session.isSubmitted) {
                    Toy3DButton(
                        text = if (session.isLastQuestion) strings.seeResults else strings.nextQuestion,
                        icon = if (session.isLastQuestion) Icons.Rounded.EmojiEvents else Icons.AutoMirrored.Rounded.ArrowForward,
                        containerColor = MintEmerald,
                        lipColor = MintEmeraldDeep,
                        onClick = onNextQuestion,
                        testTag = "btn_quiz_next",
                        height = 56.dp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun WordOptionCard(
    option: LessonItem,
    isSelected: Boolean,
    isCorrectTarget: Boolean,
    isSubmitted: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = when {
            isSubmitted && isCorrectTarget -> MintEmeraldLight
            isSubmitted && isSelected && !isCorrectTarget -> CoralBerryLight
            else -> MaterialTheme.colorScheme.surface
        },
        label = "word_opt_bg"
    )
    val lipColor by animateColorAsState(
        targetValue = when {
            isSubmitted && isCorrectTarget -> MintEmerald
            isSubmitted && isSelected && !isCorrectTarget -> CoralBerry
            else -> Color(0xFFD5E1F5)
        },
        label = "word_opt_lip"
    )
    val borderColor = when {
        isSubmitted && isCorrectTarget -> MintEmerald
        isSubmitted && isSelected && !isCorrectTarget -> CoralBerry
        else -> MaterialTheme.colorScheme.outline
    }

    Toy3DCard(
        modifier = modifier,
        containerColor = bgColor,
        lipColor = lipColor,
        borderColor = borderColor,
        cornerRadius = 20.dp,
        lipDepth = 5.dp,
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
        onClick = if (!isSubmitted) onClick else null
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = option.englishWord,
                    style = MaterialTheme.typography.headlineMedium,
                    color = when {
                        isSubmitted && isCorrectTarget -> MintEmeraldDeep
                        isSubmitted && isSelected && !isCorrectTarget -> CoralBerryDeep
                        else -> MaterialTheme.colorScheme.onSurface
                    }
                )
                if (isSubmitted && (isCorrectTarget || isSelected)) {
                    Icon(
                        imageVector = if (isCorrectTarget) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel,
                        contentDescription = null,
                        tint = if (isCorrectTarget) MintEmeraldDeep else CoralBerryDeep,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun IllustrationOptionCard(
    option: LessonItem,
    isSelected: Boolean,
    isCorrectTarget: Boolean,
    isSubmitted: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = when {
            isSubmitted && isCorrectTarget -> MintEmeraldLight
            isSubmitted && isSelected && !isCorrectTarget -> CoralBerryLight
            else -> MaterialTheme.colorScheme.surface
        },
        label = "img_opt_bg"
    )
    val lipColor by animateColorAsState(
        targetValue = when {
            isSubmitted && isCorrectTarget -> MintEmerald
            isSubmitted && isSelected && !isCorrectTarget -> CoralBerry
            else -> Color(0xFFD5E1F5)
        },
        label = "img_opt_lip"
    )

    Toy3DCard(
        modifier = modifier,
        containerColor = bgColor,
        lipColor = lipColor,
        borderColor = when {
            isSubmitted && isCorrectTarget -> MintEmerald
            isSubmitted && isSelected && !isCorrectTarget -> CoralBerry
            else -> MaterialTheme.colorScheme.outline
        },
        cornerRadius = 22.dp,
        lipDepth = 5.dp,
        contentPadding = PaddingValues(12.dp),
        onClick = if (!isSubmitted) onClick else null
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LessonIllustration3D(
                item = option,
                animateFloat = false,
                modifier = Modifier.size(112.dp)
            )
            if (isSubmitted) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                        text = option.englishWord,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (isCorrectTarget) MintEmeraldDeep else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
