package com.example.ui.components

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun DrawScope.draw3DLion() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.52f
    val r = minOf(w, h) * 0.35f

    drawGroundShadow(cx, cy + r * 1.02f, r * 0.92f, r * 0.2f)

    // Scalloped 3D fluffy mane
    val petalCount = 12
    for (i in 0 until petalCount) {
        val angle = (2.0 * PI * i / petalCount).toFloat()
        val px = cx + cos(angle) * r * 0.72f
        val py = cy + sin(angle) * r * 0.72f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFB923C), Color(0xFFEA580C), Color(0xFF9A3412)),
                center = Offset(px - r * 0.08f, py - r * 0.08f),
                radius = r * 0.45f
            ),
            radius = r * 0.36f,
            center = Offset(px, py)
        )
    }

    // Round ears
    listOf(-0.56f, 0.56f).forEach { dx ->
        drawCircle(
            color = Color(0xFFFBBF24),
            radius = r * 0.24f,
            center = Offset(cx + r * dx, cy - r * 0.62f)
        )
        drawCircle(
            color = Color(0xFFFDE68A),
            radius = r * 0.13f,
            center = Offset(cx + r * dx, cy - r * 0.62f)
        )
    }

    // 3D golden face sphere
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFDE68A), Color(0xFFFBBF24), Color(0xFFD97706)),
            center = Offset(cx - r * 0.24f, cy - r * 0.28f),
            radius = r * 1.15f
        ),
        radius = r * 0.70f,
        center = Offset(cx, cy)
    )

    // Cream snout
    drawOval(
        color = Color(0xFFFFFBEB),
        topLeft = Offset(cx - r * 0.30f, cy + r * 0.04f),
        size = Size(r * 0.60f, r * 0.40f)
    )
    // Triangle nose
    val nose = Path().apply {
        moveTo(cx - r * 0.12f, cy + r * 0.08f)
        lineTo(cx + r * 0.12f, cy + r * 0.08f)
        lineTo(cx, cy + r * 0.22f)
        close()
    }
    drawPath(nose, color = Color(0xFF78350F))

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.06f,
        eyeSpacing = r * 0.26f,
        eyeRadius = r * 0.085f,
        smileWidth = r * 0.14f
    )
}

fun DrawScope.draw3DElephant() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.52f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 1.0f, r * 0.95f, r * 0.2f)

    // Big floppy 3D ears
    listOf(-1f, 1f).forEach { dir ->
        val earCenter = Offset(cx + dir * r * 0.82f, cy - r * 0.08f)
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFBFDBFE), Color(0xFF60A5FA), Color(0xFF3B82F6)),
                center = Offset(earCenter.x - r * 0.1f, earCenter.y - r * 0.15f),
                radius = r * 0.85f
            ),
            topLeft = Offset(earCenter.x - r * 0.52f, earCenter.y - r * 0.64f),
            size = Size(r * 1.04f, r * 1.24f)
        )
        drawOval(
            color = Color(0xFFFBCFE8),
            topLeft = Offset(earCenter.x - r * 0.34f, earCenter.y - r * 0.42f),
            size = Size(r * 0.68f, r * 0.82f)
        )
    }

    // 3D Head
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFDBEAFE), Color(0xFF93C5FD), Color(0xFF3B82F6)),
            center = Offset(cx - r * 0.25f, cy - r * 0.3f),
            radius = r * 1.25f
        ),
        radius = r * 0.76f,
        center = Offset(cx, cy)
    )

    // Specular head highlight
    drawOval(
        color = Color.White.copy(alpha = 0.38f),
        topLeft = Offset(cx - r * 0.42f, cy - r * 0.58f),
        size = Size(r * 0.32f, r * 0.20f)
    )

    // Cute curved trunk
    val trunkPath = Path().apply {
        moveTo(cx, cy + r * 0.10f)
        cubicTo(
            cx - r * 0.06f, cy + r * 0.68f,
            cx + r * 0.42f, cy + r * 0.84f,
            cx + r * 0.52f, cy + r * 0.52f
        )
    }
    drawPath(
        path = trunkPath,
        color = Color(0xFF60A5FA),
        style = Stroke(width = r * 0.26f, cap = StrokeCap.Round)
    )
    drawCircle(
        color = Color(0xFFFBCFE8),
        radius = r * 0.11f,
        center = Offset(cx + r * 0.52f, cy + r * 0.50f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.10f,
        eyeSpacing = r * 0.30f,
        eyeRadius = r * 0.088f,
        smileWidth = r * 0.10f
    )
}

fun DrawScope.draw3DCat() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.55f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 0.94f, r * 0.88f, r * 0.2f)

    // Pointy 3D ears
    listOf(-1f, 1f).forEach { dir ->
        val ear = Path().apply {
            moveTo(cx + dir * r * 0.22f, cy - r * 0.55f)
            lineTo(cx + dir * r * 0.72f, cy - r * 1.12f)
            lineTo(cx + dir * r * 0.76f, cy - r * 0.25f)
            close()
        }
        drawPath(
            ear,
            brush = Brush.linearGradient(listOf(Color(0xFFFDBA74), Color(0xFFEA580C)))
        )
        val inner = Path().apply {
            moveTo(cx + dir * r * 0.34f, cy - r * 0.52f)
            lineTo(cx + dir * r * 0.64f, cy - r * 0.92f)
            lineTo(cx + dir * r * 0.66f, cy - r * 0.36f)
            close()
        }
        drawPath(inner, color = Color(0xFFFBCFE8))
    }

    // Chubby 3D head
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFED7AA), Color(0xFFFB923C), Color(0xFFEA580C)),
            center = Offset(cx - r * 0.25f, cy - r * 0.28f),
            radius = r * 1.3f
        ),
        topLeft = Offset(cx - r * 0.86f, cy - r * 0.72f),
        size = Size(r * 1.72f, r * 1.48f)
    )

    // Forehead tabby stripes
    for (i in -1..1) {
        drawRoundRect(
            color = Color(0xFFC2410C).copy(alpha = 0.5f),
            topLeft = Offset(cx + i * r * 0.16f - r * 0.04f, cy - r * 0.68f),
            size = Size(r * 0.08f, r * 0.22f),
            cornerRadius = CornerRadius(r * 0.04f)
        )
    }

    // Whiskers
    listOf(-1f, 1f).forEach { dir ->
        drawLine(
            color = Color(0xFF7C2D12).copy(alpha = 0.65f),
            start = Offset(cx + dir * r * 0.45f, cy + r * 0.08f),
            end = Offset(cx + dir * r * 1.02f, cy + r * 0.02f),
            strokeWidth = r * 0.04f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF7C2D12).copy(alpha = 0.65f),
            start = Offset(cx + dir * r * 0.45f, cy + r * 0.20f),
            end = Offset(cx + dir * r * 1.02f, cy + r * 0.26f),
            strokeWidth = r * 0.04f,
            cap = StrokeCap.Round
        )
    }

    // Pink nose
    drawOval(
        color = Color(0xFFF43F5E),
        topLeft = Offset(cx - r * 0.09f, cy + r * 0.05f),
        size = Size(r * 0.18f, r * 0.12f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.06f,
        eyeSpacing = r * 0.30f,
        eyeRadius = r * 0.09f,
        smileWidth = r * 0.14f
    )
}

fun DrawScope.draw3DDog() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.54f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 0.96f, r * 0.88f, r * 0.2f)

    // Floppy 3D brown ears
    listOf(-1f, 1f).forEach { dir ->
        rotate(dir * 18f, pivot = Offset(cx + dir * r * 0.66f, cy - r * 0.38f)) {
            drawOval(
                brush = Brush.linearGradient(listOf(Color(0xFF92400E), Color(0xFF78350F))),
                topLeft = Offset(cx + dir * r * 0.68f - r * 0.26f, cy - r * 0.45f),
                size = Size(r * 0.52f, r * 1.02f)
            )
        }
    }

    // Head
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFDE68A), Color(0xFFD99B52), Color(0xFFA16207)),
            center = Offset(cx - r * 0.26f, cy - r * 0.28f),
            radius = r * 1.25f
        ),
        radius = r * 0.78f,
        center = Offset(cx, cy)
    )

    // Cute eye patch
    drawCircle(
        color = Color(0xFF92400E).copy(alpha = 0.55f),
        radius = r * 0.24f,
        center = Offset(cx - r * 0.30f, cy - r * 0.06f)
    )

    // Cream muzzle
    drawOval(
        color = Color(0xFFFFFBEB),
        topLeft = Offset(cx - r * 0.36f, cy + r * 0.06f),
        size = Size(r * 0.72f, r * 0.46f)
    )
    // Shiny nose
    drawOval(
        color = Color(0xFF1E293B),
        topLeft = Offset(cx - r * 0.14f, cy + r * 0.04f),
        size = Size(r * 0.28f, r * 0.18f)
    )
    // Happy pink tongue
    drawOval(
        color = Color(0xFFFB7185),
        topLeft = Offset(cx - r * 0.09f, cy + r * 0.36f),
        size = Size(r * 0.18f, r * 0.22f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.08f,
        eyeSpacing = r * 0.30f,
        eyeRadius = r * 0.09f,
        smileWidth = r * 0.15f
    )
}

fun DrawScope.draw3DMonkey() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.54f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 0.96f, r * 0.85f, r * 0.2f)

    // Big round ears
    listOf(-0.82f, 0.82f).forEach { dx ->
        drawCircle(
            color = Color(0xFF92400E),
            radius = r * 0.28f,
            center = Offset(cx + r * dx, cy - r * 0.04f)
        )
        drawCircle(
            color = Color(0xFFFDE68A),
            radius = r * 0.17f,
            center = Offset(cx + r * dx, cy - r * 0.04f)
        )
    }

    // Brown head
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFD97706), Color(0xFF92400E), Color(0xFF78350F)),
            center = Offset(cx - r * 0.22f, cy - r * 0.3f),
            radius = r * 1.25f
        ),
        radius = r * 0.78f,
        center = Offset(cx, cy)
    )

    // Hair tuft
    drawOval(
        color = Color(0xFF78350F),
        topLeft = Offset(cx - r * 0.10f, cy - r * 0.96f),
        size = Size(r * 0.20f, r * 0.28f)
    )

    // Cream heart-mask face
    drawCircle(color = Color(0xFFFEF3C7), radius = r * 0.34f, center = Offset(cx - r * 0.22f, cy - r * 0.14f))
    drawCircle(color = Color(0xFFFEF3C7), radius = r * 0.34f, center = Offset(cx + r * 0.22f, cy - r * 0.14f))
    drawOval(
        color = Color(0xFFFEF3C7),
        topLeft = Offset(cx - r * 0.52f, cy - r * 0.02f),
        size = Size(r * 1.04f, r * 0.66f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.10f,
        eyeSpacing = r * 0.24f,
        eyeRadius = r * 0.088f,
        smileWidth = r * 0.18f
    )
}

fun DrawScope.draw3DGiraffe() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.56f
    val r = minOf(w, h) * 0.33f

    drawGroundShadow(cx, cy + r * 1.05f, r * 0.72f, r * 0.18f)

    // Long neck
    drawRoundRect(
        brush = Brush.linearGradient(listOf(Color(0xFFFDE047), Color(0xFFEAB308))),
        topLeft = Offset(cx - r * 0.28f, cy + r * 0.18f),
        size = Size(r * 0.56f, r * 0.88f),
        cornerRadius = CornerRadius(r * 0.24f)
    )
    // Neck spots
    drawCircle(color = Color(0xFFB45309), radius = r * 0.10f, center = Offset(cx - r * 0.08f, cy + r * 0.62f))
    drawCircle(color = Color(0xFFB45309), radius = r * 0.08f, center = Offset(cx + r * 0.10f, cy + r * 0.82f))

    // Ossicones (horns)
    listOf(-0.26f, 0.26f).forEach { dx ->
        drawLine(
            color = Color(0xFFB45309),
            start = Offset(cx + r * dx, cy - r * 0.66f),
            end = Offset(cx + r * dx * 1.25f, cy - r * 1.05f),
            strokeWidth = r * 0.10f,
            cap = StrokeCap.Round
        )
        drawCircle(
            color = Color(0xFF78350F),
            radius = r * 0.11f,
            center = Offset(cx + r * dx * 1.25f, cy - r * 1.05f)
        )
    }

    // Ears
    listOf(-1f, 1f).forEach { dir ->
        rotate(dir * 25f, pivot = Offset(cx + dir * r * 0.55f, cy - r * 0.45f)) {
            drawOval(
                color = Color(0xFFFACC15),
                topLeft = Offset(cx + dir * r * 0.65f - r * 0.24f, cy - r * 0.58f),
                size = Size(r * 0.48f, r * 0.24f)
            )
        }
    }

    // Head
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFEF08A), Color(0xFFFACC15), Color(0xFFCA8A04)),
            center = Offset(cx - r * 0.2f, cy - r * 0.4f),
            radius = r * 1.15f
        ),
        topLeft = Offset(cx - r * 0.62f, cy - r * 0.72f),
        size = Size(r * 1.24f, r * 1.10f)
    )

    // Snout
    drawOval(
        color = Color(0xFFFFFBEB),
        topLeft = Offset(cx - r * 0.44f, cy - r * 0.06f),
        size = Size(r * 0.88f, r * 0.46f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.24f,
        eyeSpacing = r * 0.28f,
        eyeRadius = r * 0.085f,
        smileWidth = r * 0.14f
    )
}

fun DrawScope.draw3DPenguin() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.52f
    val r = minOf(w, h) * 0.35f

    drawGroundShadow(cx, cy + r * 1.02f, r * 0.85f, r * 0.2f)

    // Orange webbed feet
    listOf(-0.34f, 0.34f).forEach { dx ->
        drawOval(
            color = Color(0xFFFF8800),
            topLeft = Offset(cx + r * dx - r * 0.22f, cy + r * 0.78f),
            size = Size(r * 0.44f, r * 0.24f)
        )
    }

    // Flippers
    listOf(-1f, 1f).forEach { dir ->
        rotate(dir * 26f, pivot = Offset(cx + dir * r * 0.72f, cy + r * 0.05f)) {
            drawOval(
                color = Color(0xFF1E293B),
                topLeft = Offset(cx + dir * r * 0.76f - r * 0.16f, cy - r * 0.18f),
                size = Size(r * 0.32f, r * 0.78f)
            )
        }
    }

    // Glossy 3D dark navy body
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFF475569), Color(0xFF1E293B), Color(0xFF0F172A)),
            center = Offset(cx - r * 0.25f, cy - r * 0.35f),
            radius = r * 1.45f
        ),
        topLeft = Offset(cx - r * 0.80f, cy - r * 0.88f),
        size = Size(r * 1.60f, r * 1.80f)
    )

    // White belly & face heart
    drawOval(
        color = Color(0xFFF8FAFC),
        topLeft = Offset(cx - r * 0.56f, cy - r * 0.16f),
        size = Size(r * 1.12f, r * 0.96f)
    )
    drawCircle(color = Color(0xFFF8FAFC), radius = r * 0.34f, center = Offset(cx - r * 0.22f, cy - r * 0.30f))
    drawCircle(color = Color(0xFFF8FAFC), radius = r * 0.34f, center = Offset(cx + r * 0.22f, cy - r * 0.30f))

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.30f,
        eyeSpacing = r * 0.24f,
        eyeRadius = r * 0.08f,
        smileWidth = r * 0.08f
    )

    // 3D orange beak
    val beak = Path().apply {
        moveTo(cx - r * 0.16f, cy - r * 0.18f)
        lineTo(cx + r * 0.16f, cy - r * 0.18f)
        lineTo(cx, cy - r * 0.01f)
        close()
    }
    drawPath(
        path = beak,
        brush = Brush.linearGradient(listOf(Color(0xFFFACC15), Color(0xFFF97316)))
    )
}

fun DrawScope.draw3DRabbit() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.62f
    val r = minOf(w, h) * 0.33f

    drawGroundShadow(cx, cy + r * 0.90f, r * 0.85f, r * 0.2f)

    // Tall 3D ears
    listOf(-1f, 1f).forEach { dir ->
        rotate(dir * 10f, pivot = Offset(cx + dir * r * 0.32f, cy - r * 0.62f)) {
            drawOval(
                brush = Brush.linearGradient(listOf(Color.White, Color(0xFFE2E8F0))),
                topLeft = Offset(cx + dir * r * 0.32f - r * 0.20f, cy - r * 1.56f),
                size = Size(r * 0.40f, r * 1.05f)
            )
            drawOval(
                color = Color(0xFFFBCFE8),
                topLeft = Offset(cx + dir * r * 0.32f - r * 0.11f, cy - r * 1.38f),
                size = Size(r * 0.22f, r * 0.72f)
            )
        }
    }

    // Plump soft white bunny head
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color.White, Color(0xFFF1F5F9), Color(0xFFCBD5E1)),
            center = Offset(cx - r * 0.24f, cy - r * 0.28f),
            radius = r * 1.25f
        ),
        topLeft = Offset(cx - r * 0.84f, cy - r * 0.70f),
        size = Size(r * 1.68f, r * 1.44f)
    )

    // Whiskers
    listOf(-1f, 1f).forEach { dir ->
        drawLine(
            color = Color(0xFF94A3B8),
            start = Offset(cx + dir * r * 0.44f, cy + r * 0.10f),
            end = Offset(cx + dir * r * 0.96f, cy + r * 0.04f),
            strokeWidth = r * 0.04f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF94A3B8),
            start = Offset(cx + dir * r * 0.44f, cy + r * 0.22f),
            end = Offset(cx + dir * r * 0.96f, cy + r * 0.28f),
            strokeWidth = r * 0.04f,
            cap = StrokeCap.Round
        )
    }

    // Pink nose
    drawOval(
        color = Color(0xFFEC4899),
        topLeft = Offset(cx - r * 0.09f, cy + r * 0.04f),
        size = Size(r * 0.18f, r * 0.12f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.08f,
        eyeSpacing = r * 0.28f,
        eyeRadius = r * 0.09f,
        smileWidth = r * 0.14f
    )
}
