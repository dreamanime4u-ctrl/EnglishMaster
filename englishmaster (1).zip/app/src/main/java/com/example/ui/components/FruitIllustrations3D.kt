package com.example.ui.components

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.cos
import kotlin.math.sin

internal fun DrawScope.drawGroundShadow(cx: Float, bottomY: Float, radiusX: Float, radiusY: Float) {
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x361E293B), Color(0x141E293B), Color.Transparent),
            center = Offset(cx, bottomY),
            radius = radiusX
        ),
        topLeft = Offset(cx - radiusX, bottomY - radiusY),
        size = Size(radiusX * 2f, radiusY * 2f)
    )
}

internal fun DrawScope.drawCuteFace(
    cx: Float,
    cy: Float,
    eyeSpacing: Float,
    eyeRadius: Float,
    smileWidth: Float,
    eyeColor: Color = Color(0xFF1E293B),
    cheekColor: Color = Color(0xFFFF8FA3)
) {
    val leftEye = Offset(cx - eyeSpacing, cy)
    val rightEye = Offset(cx + eyeSpacing, cy)

    // Rosy cheeks
    drawOval(
        color = cheekColor.copy(alpha = 0.65f),
        topLeft = Offset(leftEye.x - eyeRadius * 1.9f, cy + eyeRadius * 0.7f),
        size = Size(eyeRadius * 2.1f, eyeRadius * 1.25f)
    )
    drawOval(
        color = cheekColor.copy(alpha = 0.65f),
        topLeft = Offset(rightEye.x - eyeRadius * 0.2f, cy + eyeRadius * 0.7f),
        size = Size(eyeRadius * 2.1f, eyeRadius * 1.25f)
    )

    // Glossy eyes with catchlights
    listOf(leftEye, rightEye).forEach { eye ->
        drawCircle(color = eyeColor, radius = eyeRadius, center = eye)
        drawCircle(
            color = Color.White,
            radius = eyeRadius * 0.36f,
            center = Offset(eye.x - eyeRadius * 0.28f, eye.y - eyeRadius * 0.28f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.7f),
            radius = eyeRadius * 0.16f,
            center = Offset(eye.x + eyeRadius * 0.25f, eye.y + eyeRadius * 0.25f)
        )
    }

    // Cheerful smile
    val smilePath = Path().apply {
        moveTo(cx - smileWidth, cy + eyeRadius * 0.9f)
        quadraticTo(
            cx,
            cy + eyeRadius * 0.9f + smileWidth * 1.15f,
            cx + smileWidth,
            cy + eyeRadius * 0.9f
        )
    }
    drawPath(
        path = smilePath,
        color = eyeColor,
        style = Stroke(width = eyeRadius * 0.55f, cap = StrokeCap.Round)
    )
}

fun DrawScope.draw3DApple() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.55f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 1.05f, r * 0.95f, r * 0.22f)

    // Stem
    val stemPath = Path().apply {
        moveTo(cx - r * 0.05f, cy - r * 0.85f)
        quadraticTo(cx + r * 0.02f, cy - r * 1.25f, cx + r * 0.16f, cy - r * 1.32f)
    }
    drawPath(
        path = stemPath,
        color = Color(0xFF78350F),
        style = Stroke(width = r * 0.14f, cap = StrokeCap.Round)
    )

    // 3D glossy green leaf
    val leafPath = Path().apply {
        moveTo(cx + r * 0.03f, cy - r * 1.02f)
        cubicTo(
            cx + r * 0.35f, cy - r * 1.48f,
            cx + r * 0.75f, cy - r * 1.25f,
            cx + r * 0.58f, cy - r * 0.88f
        )
        cubicTo(
            cx + r * 0.36f, cy - r * 0.80f,
            cx + r * 0.12f, cy - r * 0.90f,
            cx + r * 0.03f, cy - r * 1.02f
        )
    }
    drawPath(
        path = leafPath,
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFF4ADE80), Color(0xFF16A34A)),
            start = Offset(cx, cy - r * 1.4f),
            end = Offset(cx + r * 0.6f, cy - r * 0.85f)
        )
    )

    // Apple body with classic plump top dimple
    val applePath = Path().apply {
        moveTo(cx, cy - r * 0.82f)
        cubicTo(
            cx - r * 0.45f, cy - r * 1.10f,
            cx - r * 1.12f, cy - r * 0.62f,
            cx - r * 0.96f, cy + r * 0.18f
        )
        cubicTo(
            cx - r * 0.82f, cy + r * 0.88f,
            cx - r * 0.25f, cy + r * 1.02f,
            cx, cy + r * 0.86f
        )
        cubicTo(
            cx + r * 0.25f, cy + r * 1.02f,
            cx + r * 0.82f, cy + r * 0.88f,
            cx + r * 0.96f, cy + r * 0.18f
        )
        cubicTo(
            cx + r * 1.12f, cy - r * 0.62f,
            cx + r * 0.45f, cy - r * 1.10f,
            cx, cy - r * 0.82f
        )
    }
    drawPath(
        path = applePath,
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFF8A8A), Color(0xFFEF4444), Color(0xFFB91C1C)),
            center = Offset(cx - r * 0.32f, cy - r * 0.35f),
            radius = r * 1.55f
        )
    )

    // Specular 3D gloss highlight
    rotate(-28f, pivot = Offset(cx - r * 0.48f, cy - r * 0.38f)) {
        drawOval(
            color = Color.White.copy(alpha = 0.45f),
            topLeft = Offset(cx - r * 0.65f, cy - r * 0.56f),
            size = Size(r * 0.34f, r * 0.56f)
        )
    }
    drawCircle(
        color = Color.White.copy(alpha = 0.55f),
        radius = r * 0.08f,
        center = Offset(cx - r * 0.32f, cy - r * 0.66f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy + r * 0.06f,
        eyeSpacing = r * 0.28f,
        eyeRadius = r * 0.09f,
        smileWidth = r * 0.16f
    )
}

fun DrawScope.draw3DBanana() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.52f
    val s = minOf(w, h) * 0.38f

    drawGroundShadow(cx, cy + s * 0.88f, s * 0.92f, s * 0.2f)

    // Plump curved 3D banana
    val bananaPath = Path().apply {
        moveTo(cx + s * 0.62f, cy - s * 0.82f)
        cubicTo(
            cx + s * 0.96f, cy - s * 0.12f,
            cx + s * 0.48f, cy + s * 0.78f,
            cx - s * 0.68f, cy + s * 0.72f
        )
        cubicTo(
            cx - s * 0.92f, cy + s * 0.66f,
            cx - s * 0.84f, cy + s * 0.34f,
            cx - s * 0.55f, cy + s * 0.26f
        )
        cubicTo(
            cx + s * 0.08f, cy + s * 0.12f,
            cx + s * 0.28f, cy - s * 0.38f,
            cx + s * 0.34f, cy - s * 0.84f
        )
        close()
    }
    drawPath(
        path = bananaPath,
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFFF59D), Color(0xFFFACC15), Color(0xFFCA8A04)),
            center = Offset(cx + s * 0.15f, cy - s * 0.1f),
            radius = s * 1.45f
        )
    )

    // Tips
    drawCircle(color = Color(0xFF78350F), radius = s * 0.09f, center = Offset(cx + s * 0.48f, cy - s * 0.88f))
    drawCircle(color = Color(0xFF78350F), radius = s * 0.08f, center = Offset(cx - s * 0.72f, cy + s * 0.54f))

    // Highlight stripe
    val highlight = Path().apply {
        moveTo(cx + s * 0.54f, cy - s * 0.45f)
        quadraticTo(cx + s * 0.48f, cy + s * 0.24f, cx - s * 0.28f, cy + s * 0.48f)
    }
    drawPath(
        path = highlight,
        color = Color.White.copy(alpha = 0.42f),
        style = Stroke(width = s * 0.12f, cap = StrokeCap.Round)
    )

    drawCuteFace(
        cx = cx + s * 0.15f,
        cy = cy + s * 0.20f,
        eyeSpacing = s * 0.22f,
        eyeRadius = s * 0.085f,
        smileWidth = s * 0.14f
    )
}

fun DrawScope.draw3DStrawberry() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.54f
    val r = minOf(w, h) * 0.35f

    drawGroundShadow(cx, cy + r * 1.0f, r * 0.75f, r * 0.18f)

    // Berry heart-cone shape
    val berryPath = Path().apply {
        moveTo(cx, cy - r * 0.76f)
        cubicTo(
            cx - r * 0.95f, cy - r * 0.80f,
            cx - r * 0.95f, cy + r * 0.18f,
            cx, cy + r * 0.95f
        )
        cubicTo(
            cx + r * 0.95f, cy + r * 0.18f,
            cx + r * 0.95f, cy - r * 0.80f,
            cx, cy - r * 0.76f
        )
    }
    drawPath(
        path = berryPath,
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFF758F), Color(0xFFE11D48), Color(0xFF9F1239)),
            center = Offset(cx - r * 0.28f, cy - r * 0.30f),
            radius = r * 1.45f
        )
    )

    // Golden seeds
    val seeds = listOf(
        Offset(-0.48f, -0.35f), Offset(0.48f, -0.35f),
        Offset(-0.52f, 0.05f), Offset(0.52f, 0.05f),
        Offset(-0.34f, 0.42f), Offset(0.34f, 0.42f),
        Offset(0f, 0.68f), Offset(-0.18f, -0.45f), Offset(0.18f, -0.45f)
    )
    seeds.forEach { (dx, dy) ->
        drawOval(
            color = Color(0xFFFDE68A),
            topLeft = Offset(cx + r * dx - r * 0.035f, cy + r * dy - r * 0.055f),
            size = Size(r * 0.07f, r * 0.11f)
        )
    }

    // Leaf crown
    for (angle in listOf(-45f, -15f, 15f, 45f)) {
        rotate(angle, pivot = Offset(cx, cy - r * 0.74f)) {
            drawOval(
                brush = Brush.linearGradient(listOf(Color(0xFF4ADE80), Color(0xFF15803D))),
                topLeft = Offset(cx - r * 0.16f, cy - r * 1.18f),
                size = Size(r * 0.32f, r * 0.52f)
            )
        }
    }

    // Highlight
    drawOval(
        color = Color.White.copy(alpha = 0.35f),
        topLeft = Offset(cx - r * 0.52f, cy - r * 0.48f),
        size = Size(r * 0.26f, r * 0.42f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy + r * 0.02f,
        eyeSpacing = r * 0.25f,
        eyeRadius = r * 0.085f,
        smileWidth = r * 0.15f
    )
}

fun DrawScope.draw3DOrange() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.55f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 1.02f, r * 0.9f, r * 0.22f)

    // Stem + 2 leaves
    drawLine(
        color = Color(0xFF15803D),
        start = Offset(cx, cy - r * 0.85f),
        end = Offset(cx, cy - r * 1.22f),
        strokeWidth = r * 0.12f,
        cap = StrokeCap.Round
    )
    rotate(-35f, pivot = Offset(cx, cy - r * 1.05f)) {
        drawOval(
            brush = Brush.linearGradient(listOf(Color(0xFF4ADE80), Color(0xFF16A34A))),
            topLeft = Offset(cx - r * 0.18f, cy - r * 1.48f),
            size = Size(r * 0.36f, r * 0.52f)
        )
    }
    rotate(35f, pivot = Offset(cx, cy - r * 1.05f)) {
        drawOval(
            brush = Brush.linearGradient(listOf(Color(0xFF4ADE80), Color(0xFF16A34A))),
            topLeft = Offset(cx - r * 0.18f, cy - r * 1.45f),
            size = Size(r * 0.34f, r * 0.48f)
        )
    }

    // 3D orange sphere
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFDE047), Color(0xFFFF8800), Color(0xFFC2410C)),
            center = Offset(cx - r * 0.32f, cy - r * 0.35f),
            radius = r * 1.45f
        ),
        radius = r * 0.96f,
        center = Offset(cx, cy)
    )

    // Citrus dimples
    listOf(
        Offset(0.45f, -0.35f), Offset(0.56f, -0.18f), Offset(0.36f, -0.5f),
        Offset(-0.55f, 0.35f), Offset(-0.42f, 0.5f)
    ).forEach { (dx, dy) ->
        drawCircle(
            color = Color(0xFFC2410C).copy(alpha = 0.45f),
            radius = r * 0.03f,
            center = Offset(cx + r * dx, cy + r * dy)
        )
    }

    // Glossy specular
    rotate(-25f, pivot = Offset(cx - r * 0.45f, cy - r * 0.42f)) {
        drawOval(
            color = Color.White.copy(alpha = 0.45f),
            topLeft = Offset(cx - r * 0.62f, cy - r * 0.58f),
            size = Size(r * 0.34f, r * 0.52f)
        )
    }

    drawCuteFace(
        cx = cx,
        cy = cy + r * 0.08f,
        eyeSpacing = r * 0.28f,
        eyeRadius = r * 0.09f,
        smileWidth = r * 0.16f
    )
}

fun DrawScope.draw3DWatermelon() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.52f
    val r = minOf(w, h) * 0.38f

    drawGroundShadow(cx, cy + r * 0.78f, r * 0.95f, r * 0.2f)

    // Thick 3D slice (green rind + pale green + juicy pink)
    drawArc(
        brush = Brush.linearGradient(listOf(Color(0xFF16A34A), Color(0xFF065F46))),
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(cx - r, cy - r * 0.32f),
        size = Size(r * 2f, r * 1.95f)
    )
    drawArc(
        color = Color(0xFFECFCCB),
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(cx - r * 0.90f, cy - r * 0.26f),
        size = Size(r * 1.80f, r * 1.74f)
    )
    drawArc(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFF7597), Color(0xFFFB3768), Color(0xFFBE123C)),
            center = Offset(cx - r * 0.2f, cy + r * 0.1f),
            radius = r * 1.2f
        ),
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(cx - r * 0.82f, cy - r * 0.22f),
        size = Size(r * 1.64f, r * 1.56f)
    )

    // Shiny black seeds
    listOf(
        Offset(-0.46f, 0.12f), Offset(-0.22f, 0.38f),
        Offset(0.22f, 0.38f), Offset(0.46f, 0.12f), Offset(0f, 0.44f)
    ).forEach { (dx, dy) ->
        drawOval(
            color = Color(0xFF1E293B),
            topLeft = Offset(cx + r * dx - r * 0.04f, cy + r * dy - r * 0.06f),
            size = Size(r * 0.08f, r * 0.12f)
        )
    }

    drawCuteFace(
        cx = cx,
        cy = cy + r * 0.04f,
        eyeSpacing = r * 0.25f,
        eyeRadius = r * 0.075f,
        smileWidth = r * 0.13f,
        cheekColor = Color(0xFFFFD1DC)
    )
}

fun DrawScope.draw3DGrapes() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.56f
    val r = minOf(w, h) * 0.34f

    drawGroundShadow(cx, cy + r * 1.05f, r * 0.72f, r * 0.18f)

    // Curly vine & leaf
    drawLine(
        color = Color(0xFF78350F),
        start = Offset(cx, cy - r * 0.7f),
        end = Offset(cx + r * 0.08f, cy - r * 1.18f),
        strokeWidth = r * 0.12f,
        cap = StrokeCap.Round
    )
    rotate(-30f, pivot = Offset(cx, cy - r * 0.9f)) {
        drawOval(
            brush = Brush.linearGradient(listOf(Color(0xFF4ADE80), Color(0xFF16A34A))),
            topLeft = Offset(cx - r * 0.55f, cy - r * 1.25f),
            size = Size(r * 0.58f, r * 0.40f)
        )
    }

    val grapeR = r * 0.28f
    val positions = listOf(
        Offset(-0.46f, -0.45f), Offset(0f, -0.48f), Offset(0.46f, -0.45f),
        Offset(-0.34f, -0.04f), Offset(0.34f, -0.04f), Offset(0f, -0.04f),
        Offset(-0.22f, 0.36f), Offset(0.22f, 0.36f),
        Offset(0f, 0.70f)
    )

    positions.forEach { (dx, dy) ->
        val center = Offset(cx + r * dx, cy + r * dy)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFC4B5FD), Color(0xFF8B5CF6), Color(0xFF5B21B6)),
                center = Offset(center.x - grapeR * 0.3f, center.y - grapeR * 0.3f),
                radius = grapeR * 1.4f
            ),
            radius = grapeR,
            center = center
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.5f),
            radius = grapeR * 0.24f,
            center = Offset(center.x - grapeR * 0.35f, center.y - grapeR * 0.35f)
        )
    }

    drawCuteFace(
        cx = cx,
        cy = cy - r * 0.06f,
        eyeSpacing = r * 0.20f,
        eyeRadius = r * 0.068f,
        smileWidth = r * 0.11f
    )
}

fun DrawScope.draw3DPineapple() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.59f
    val r = minOf(w, h) * 0.33f

    drawGroundShadow(cx, cy + r * 0.96f, r * 0.78f, r * 0.18f)

    // Crown leaves
    for (angle in listOf(-38f, -18f, 0f, 18f, 38f)) {
        val len = if (angle == 0f) r * 1.05f else r * 0.85f
        rotate(angle, pivot = Offset(cx, cy - r * 0.68f)) {
            val leaf = Path().apply {
                moveTo(cx - r * 0.16f, cy - r * 0.65f)
                quadraticTo(cx, cy - r * 0.65f - len, cx + r * 0.16f, cy - r * 0.65f)
                close()
            }
            drawPath(
                path = leaf,
                brush = Brush.linearGradient(listOf(Color(0xFF4ADE80), Color(0xFF15803D)))
            )
        }
    }

    // Golden oval body
    drawRoundRect(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFDE047), Color(0xFFF59E0B), Color(0xFFB45309)),
            center = Offset(cx - r * 0.28f, cy - r * 0.25f),
            radius = r * 1.4f
        ),
        topLeft = Offset(cx - r * 0.72f, cy - r * 0.75f),
        size = Size(r * 1.44f, r * 1.66f),
        cornerRadius = CornerRadius(r * 0.68f, r * 0.68f)
    )

    // Subtle diamond texture lines
    for (i in -1..1) {
        drawLine(
            color = Color(0xFF92400E).copy(alpha = 0.22f),
            start = Offset(cx - r * 0.52f, cy - r * 0.35f + i * r * 0.35f),
            end = Offset(cx + r * 0.52f, cy + r * 0.25f + i * r * 0.35f),
            strokeWidth = r * 0.045f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF92400E).copy(alpha = 0.22f),
            start = Offset(cx + r * 0.52f, cy - r * 0.35f + i * r * 0.35f),
            end = Offset(cx - r * 0.52f, cy + r * 0.25f + i * r * 0.35f),
            strokeWidth = r * 0.045f,
            cap = StrokeCap.Round
        )
    }

    drawOval(
        color = Color.White.copy(alpha = 0.38f),
        topLeft = Offset(cx - r * 0.48f, cy - r * 0.52f),
        size = Size(r * 0.24f, r * 0.42f)
    )

    drawCuteFace(
        cx = cx,
        cy = cy + r * 0.06f,
        eyeSpacing = r * 0.24f,
        eyeRadius = r * 0.085f,
        smileWidth = r * 0.14f
    )
}

fun DrawScope.draw3DMango() {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f
    val cy = h * 0.54f
    val r = minOf(w, h) * 0.35f

    drawGroundShadow(cx, cy + r * 0.96f, r * 0.85f, r * 0.2f)

    // Leaf
    rotate(25f, pivot = Offset(cx + r * 0.1f, cy - r * 0.82f)) {
        drawOval(
            brush = Brush.linearGradient(listOf(Color(0xFF4ADE80), Color(0xFF16A34A))),
            topLeft = Offset(cx + r * 0.04f, cy - r * 1.28f),
            size = Size(r * 0.55f, r * 0.32f)
        )
    }

    // Teardrop curved 3D mango body
    val mangoPath = Path().apply {
        moveTo(cx + r * 0.05f, cy - r * 0.88f)
        cubicTo(
            cx + r * 0.92f, cy - r * 0.82f,
            cx + r * 1.02f, cy + r * 0.36f,
            cx + r * 0.15f, cy + r * 0.90f
        )
        cubicTo(
            cx - r * 0.42f, cy + r * 1.12f,
            cx - r * 0.88f, cy + r * 0.58f,
            cx - r * 0.72f, cy + r * 0.04f
        )
        cubicTo(
            cx - r * 0.58f, cy - r * 0.48f,
            cx - r * 0.48f, cy - r * 0.88f,
            cx + r * 0.05f, cy - r * 0.88f
        )
    }
    drawPath(
        path = mangoPath,
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFDE047), Color(0xFFFF7B3D), Color(0xFFEA580C)),
            center = Offset(cx - r * 0.24f, cy - r * 0.32f),
            radius = r * 1.5f
        )
    )

    rotate(-20f, pivot = Offset(cx - r * 0.38f, cy - r * 0.34f)) {
        drawOval(
            color = Color.White.copy(alpha = 0.42f),
            topLeft = Offset(cx - r * 0.52f, cy - r * 0.52f),
            size = Size(r * 0.26f, r * 0.46f)
        )
    }

    drawCuteFace(
        cx = cx + r * 0.05f,
        cy = cy + r * 0.08f,
        eyeSpacing = r * 0.24f,
        eyeRadius = r * 0.085f,
        smileWidth = r * 0.14f
    )
}
