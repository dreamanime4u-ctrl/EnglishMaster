package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LessonCatalog
import com.example.data.local.QuizAttemptEntity
import com.example.model.AppLanguage
import com.example.model.LessonCategory
import com.example.model.LocalizedStrings
import com.example.model.QuizMode
import com.example.model.StringsCatalog
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.components.StarProgressBadge
import com.example.ui.components.Toy3DButton
import com.example.ui.components.Toy3DCard
import com.example.ui.theme.CoralBerry
import com.example.ui.theme.CoralBerryDeep
import com.example.ui.theme.CoralBerryLight
import com.example.ui.theme.GrapeViolet
import com.example.ui.theme.GrapeVioletDeep
import com.example.ui.theme.GrapeVioletLight
import com.example.ui.theme.MintEmerald
import com.example.ui.theme.MintEmeraldDeep
import com.example.ui.theme.MintEmeraldLight
import com.example.ui.theme.SkyBlueDeep
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.SunnyAmber
import com.example.ui.theme.SunnyAmberDeep
import com.example.ui.theme.SunnyAmberLight
import com.example.viewmodel.EnglishMasterUiState

@Composable
fun HomeScreen(
    uiState: EnglishMasterUiState,
    onSelectLanguage: (AppLanguage) -> Unit,
    onStartLesson: (LessonCategory) -> Unit,
    onStartQuiz: (QuizMode) -> Unit,
    onResetProgress: () -> Unit
) {
    val strings = StringsCatalog.get(uiState.selectedLanguage)
    var showResetDialog by remember { mutableStateOf(false) }

    val overallProgress by animateFloatAsState(
        targetValue = if (uiState.totalWordsCount > 0) {
            uiState.totalMasteredCount.toFloat() / uiState.totalWordsCount
        } else {
            0f
        },
        label = "overall_progress"
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(innerPadding)
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding(),
                contentAlignment = Alignment.TopCenter
            ) {
                val isWideScreen = maxWidth >= 660.dp

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 900.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    // Header: Brand + Star Counter + Language Switcher
                    HomeTopHeader(
                        strings = strings,
                        totalStars = uiState.totalStars,
                        selectedLanguage = uiState.selectedLanguage,
                        onSelectLanguage = onSelectLanguage
                    )

                    // 3D Hero Welcome Card
                    HeroWelcomeCard(
                        strings = strings,
                        masteredCount = uiState.totalMasteredCount,
                        totalWords = uiState.totalWordsCount,
                        progress = overallProgress
                    )

                    Text(
                        text = strings.chooseAdventure,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    // Category Cards: Fruits & Animals (side-by-side on wide screens)
                    if (isWideScreen) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CategoryLessonCard(
                                title = strings.fruitsTitle,
                                subtitle = strings.fruitsSubtitle,
                                bannerRes = R.drawable.img_fruits_banner,
                                bannerCd = stringResource(R.string.cd_fruits_banner),
                                learnedCount = uiState.fruitsLearnedCount,
                                totalCount = LessonCatalog.fruits.size,
                                accentColor = CoralBerry,
                                lipColor = Color(0xFFFFD0D5),
                                tintColor = CoralBerryLight,
                                buttonLipColor = CoralBerryDeep,
                                strings = strings,
                                lessonTag = "btn_lesson_fruits",
                                quizTag = "btn_quiz_fruits",
                                onStartLesson = { onStartLesson(LessonCategory.FRUITS) },
                                onStartQuiz = { onStartQuiz(QuizMode.FRUITS) },
                                modifier = Modifier.weight(1f)
                            )
                            CategoryLessonCard(
                                title = strings.animalsTitle,
                                subtitle = strings.animalsSubtitle,
                                bannerRes = R.drawable.img_animals_banner,
                                bannerCd = stringResource(R.string.cd_animals_banner),
                                learnedCount = uiState.animalsLearnedCount,
                                totalCount = LessonCatalog.animals.size,
                                accentColor = MintEmerald,
                                lipColor = Color(0xFFA7F3D0),
                                tintColor = MintEmeraldLight,
                                buttonLipColor = MintEmeraldDeep,
                                strings = strings,
                                lessonTag = "btn_lesson_animals",
                                quizTag = "btn_quiz_animals",
                                onStartLesson = { onStartLesson(LessonCategory.ANIMALS) },
                                onStartQuiz = { onStartQuiz(QuizMode.ANIMALS) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        CategoryLessonCard(
                            title = strings.fruitsTitle,
                            subtitle = strings.fruitsSubtitle,
                            bannerRes = R.drawable.img_fruits_banner,
                            bannerCd = stringResource(R.string.cd_fruits_banner),
                            learnedCount = uiState.fruitsLearnedCount,
                            totalCount = LessonCatalog.fruits.size,
                            accentColor = CoralBerry,
                            lipColor = Color(0xFFFFD0D5),
                            tintColor = CoralBerryLight,
                            buttonLipColor = CoralBerryDeep,
                            strings = strings,
                            lessonTag = "btn_lesson_fruits",
                            quizTag = "btn_quiz_fruits",
                            onStartLesson = { onStartLesson(LessonCategory.FRUITS) },
                            onStartQuiz = { onStartQuiz(QuizMode.FRUITS) }
                        )
                        CategoryLessonCard(
                            title = strings.animalsTitle,
                            subtitle = strings.animalsSubtitle,
                            bannerRes = R.drawable.img_animals_banner,
                            bannerCd = stringResource(R.string.cd_animals_banner),
                            learnedCount = uiState.animalsLearnedCount,
                            totalCount = LessonCatalog.animals.size,
                            accentColor = MintEmerald,
                            lipColor = Color(0xFFA7F3D0),
                            tintColor = MintEmeraldLight,
                            buttonLipColor = MintEmeraldDeep,
                            strings = strings,
                            lessonTag = "btn_lesson_animals",
                            quizTag = "btn_quiz_animals",
                            onStartLesson = { onStartLesson(LessonCategory.ANIMALS) },
                            onStartQuiz = { onStartQuiz(QuizMode.ANIMALS) }
                        )
                    }

                    // Super Master Mixed Quiz Card
                    MixedQuizBannerCard(
                        strings = strings,
                        onStartMixedQuiz = { onStartQuiz(QuizMode.MIXED) }
                    )

                    // Learning Progress & Local Scores Card
                    LearningProgressCard(
                        strings = strings,
                        uiState = uiState,
                        onRequestReset = { showResetDialog = true }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = {
                Text(
                    text = strings.resetDialogTitle,
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = strings.resetDialogBody,
                    style = MaterialTheme.typography.bodyLarge
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showResetDialog = false
                        onResetProgress()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = CoralBerryDeep)
                ) {
                    Text(strings.confirmReset, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(strings.cancel, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun HomeTopHeader(
    strings: LocalizedStrings,
    totalStars: Int,
    selectedLanguage: AppLanguage,
    onSelectLanguage: (AppLanguage) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 6.dp,
                    border = BorderStroke(2.dp, Color.White)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_app_logo),
                        contentDescription = stringResource(R.string.cd_app_logo),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(46.dp)
                    )
                }
                Text(
                    text = strings.appTitle,
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            StarProgressBadge(
                starsCount = totalStars,
                label = strings.starsLabel,
                modifier = Modifier.testTag("home_star_badge")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            LanguageSelectorBar(
                selectedLanguage = selectedLanguage,
                onSelectLanguage = onSelectLanguage
            )
        }
    }
}

@Composable
private fun HeroWelcomeCard(
    strings: LocalizedStrings,
    masteredCount: Int,
    totalWords: Int,
    progress: Float
) {
    Toy3DCard(
        containerColor = MaterialTheme.colorScheme.surface,
        lipColor = Color(0xFFC3D7FA),
        borderColor = SkyBlueLight,
        contentPadding = PaddingValues(0.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_banner),
                    contentDescription = stringResource(R.string.cd_hero_banner),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xBB0F172A)
                                ),
                                startY = 120f
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = strings.welcomeGreeting,
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White
                    )
                    Text(
                        text = strings.welcomeSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.92f)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.overallProgressTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = SkyBlueLight
                    ) {
                        Text(
                            text = strings.wordsMasteredFormat(masteredCount, totalWords),
                            style = MaterialTheme.typography.labelMedium,
                            color = SkyBlueDeep,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .clip(CircleShape),
                    color = SkyBluePrimary,
                    trackColor = SkyBlueLight,
                    strokeCap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun CategoryLessonCard(
    title: String,
    subtitle: String,
    bannerRes: Int,
    bannerCd: String,
    learnedCount: Int,
    totalCount: Int,
    accentColor: Color,
    lipColor: Color,
    tintColor: Color,
    buttonLipColor: Color,
    strings: LocalizedStrings,
    lessonTag: String,
    quizTag: String,
    onStartLesson: () -> Unit,
    onStartQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progressFraction = if (totalCount > 0) learnedCount.toFloat() / totalCount else 0f

    Toy3DCard(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface,
        lipColor = lipColor,
        borderColor = accentColor.copy(alpha = 0.25f),
        contentPadding = PaddingValues(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(155.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = bannerRes),
                    contentDescription = bannerCd,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp),
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.94f),
                    shadowElevation = 4.dp
                ) {
                    Text(
                        text = strings.learnedCountFormat(learnedCount, totalCount),
                        style = MaterialTheme.typography.labelMedium,
                        color = buttonLipColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            LinearProgressIndicator(
                progress = { progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(9.dp)
                    .clip(CircleShape),
                color = accentColor,
                trackColor = tintColor,
                strokeCap = StrokeCap.Round
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Toy3DButton(
                    text = strings.startLesson,
                    icon = Icons.Rounded.PlayArrow,
                    containerColor = accentColor,
                    lipColor = buttonLipColor,
                    onClick = onStartLesson,
                    testTag = lessonTag,
                    modifier = Modifier.weight(1.45f)
                )
                Toy3DButton(
                    text = strings.takeQuiz,
                    icon = Icons.Rounded.Quiz,
                    containerColor = SunnyAmber,
                    lipColor = SunnyAmberDeep,
                    contentColor = Color(0xFF1E293B),
                    onClick = onStartQuiz,
                    testTag = quizTag,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MixedQuizBannerCard(
    strings: LocalizedStrings,
    onStartMixedQuiz: () -> Unit
) {
    Toy3DCard(
        containerColor = GrapeVioletLight,
        lipColor = Color(0xFFC4B5FD),
        borderColor = GrapeViolet.copy(alpha = 0.35f),
        contentPadding = PaddingValues(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = GrapeViolet,
                shadowElevation = 4.dp,
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = strings.mixedQuizTitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = GrapeVioletDeep
                )
                Text(
                    text = strings.mixedQuizSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF4C1D95)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Toy3DButton(
                    text = strings.startMixedQuiz,
                    icon = Icons.Rounded.EmojiEvents,
                    containerColor = GrapeViolet,
                    lipColor = GrapeVioletDeep,
                    onClick = onStartMixedQuiz,
                    testTag = "btn_quiz_mixed",
                    height = 48.dp
                )
            }
        }
    }
}

@Composable
private fun LearningProgressCard(
    strings: LocalizedStrings,
    uiState: EnglishMasterUiState,
    onRequestReset: () -> Unit
) {
    Toy3DCard(
        containerColor = MaterialTheme.colorScheme.surface,
        lipColor = Color(0xFFDCE6F7),
        contentPadding = PaddingValues(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.School,
                        contentDescription = null,
                        tint = SkyBluePrimary
                    )
                    Text(
                        text = strings.progressCardTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (uiState.totalMasteredCount > 0 || uiState.quizAttempts.isNotEmpty()) {
                    TextButton(
                        onClick = onRequestReset,
                        modifier = Modifier.testTag("btn_reset_progress")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = null,
                            tint = CoralBerry,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = strings.resetProgress,
                            style = MaterialTheme.typography.labelMedium,
                            color = CoralBerry
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatMiniPill(
                    label = strings.totalStarsLabel,
                    value = "${uiState.totalStars}",
                    bgColor = SunnyAmberLight,
                    fgColor = SunnyAmberDeep,
                    modifier = Modifier.weight(1f)
                )
                StatMiniPill(
                    label = strings.quizzesDoneLabel,
                    value = "${uiState.quizAttempts.size}",
                    bgColor = SkyBlueLight,
                    fgColor = SkyBlueDeep,
                    modifier = Modifier.weight(1f)
                )
                StatMiniPill(
                    label = strings.bestFruitsLabel,
                    value = uiState.bestFruitsScore?.let { "$it/${LessonCatalog.fruits.size}" } ?: "—",
                    bgColor = CoralBerryLight,
                    fgColor = CoralBerryDeep,
                    modifier = Modifier.weight(1f)
                )
                StatMiniPill(
                    label = strings.bestAnimalsLabel,
                    value = uiState.bestAnimalsScore?.let { "$it/${LessonCatalog.animals.size}" } ?: "—",
                    bgColor = MintEmeraldLight,
                    fgColor = MintEmeraldDeep,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = strings.recentQuizzesTitle,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (uiState.quizAttempts.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.noQuizzesYet,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.quizAttempts.take(3).forEach { attempt ->
                        RecentQuizRow(attempt = attempt, strings = strings)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMiniPill(
    label: String,
    value: String,
    bgColor: Color,
    fgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = bgColor
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = fgColor,
                maxLines = 1
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = fgColor.copy(alpha = 0.85f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RecentQuizRow(
    attempt: QuizAttemptEntity,
    strings: LocalizedStrings
) {
    val modeLabel = when (QuizMode.fromId(attempt.modeId)) {
        QuizMode.FRUITS -> strings.quizTitleFruits
        QuizMode.ANIMALS -> strings.quizTitleAnimals
        QuizMode.MIXED -> strings.quizTitleMixed
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = modeLabel,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "${attempt.score}/${attempt.totalQuestions}",
                    style = MaterialTheme.typography.titleMedium,
                    color = SkyBlueDeep
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    repeat(3) { idx ->
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = null,
                            tint = if (idx < attempt.starsEarned) SunnyAmber else Color(0xFFCBD5E1),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
