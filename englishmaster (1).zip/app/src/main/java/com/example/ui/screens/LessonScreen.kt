package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.LessonCategory
import com.example.model.LessonItem
import com.example.model.StringsCatalog
import com.example.ui.components.LessonIllustration3D
import com.example.ui.components.SpeakingWaveIndicator
import com.example.ui.components.Toy3DButton
import com.example.ui.components.Toy3DCard
import com.example.ui.theme.MintEmerald
import com.example.ui.theme.MintEmeraldDeep
import com.example.ui.theme.MintEmeraldLight
import com.example.ui.theme.SkyBlueDeep
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.SunnyAmber
import com.example.ui.theme.SunnyAmberDeep
import com.example.ui.theme.SunnyAmberLight
import com.example.viewmodel.EnglishMasterUiState

@Composable
fun LessonScreen(
    uiState: EnglishMasterUiState,
    onBack: () -> Unit,
    onSelectIndex: (Int) -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onStartCategoryQuiz: () -> Unit,
    onListen: () -> Unit,
    onListenAgain: () -> Unit,
    onListenSentence: () -> Unit,
    onToggleMastered: () -> Unit
) {
    val strings = StringsCatalog.get(uiState.selectedLanguage)
    val session = uiState.lessonSession
    val currentItem = session.currentItem
    val isMastered = uiState.wordProgressById[currentItem.id]?.isMastered == true
    val categoryTitle = when (session.category) {
        LessonCategory.FRUITS -> strings.fruitsTitle
        LessonCategory.ANIMALS -> strings.animalsTitle
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            currentItem.containerTint.copy(alpha = 0.75f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 760.dp)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 4.dp
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .testTag("lesson_back_button")
                                .minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = stringResource(R.string.cd_back_button),
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Text(
                        text = categoryTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.surface,
                        shadowElevation = 3.dp,
                        border = BorderStroke(1.5.dp, currentItem.primaryColor.copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = "${session.currentIndex + 1} / ${session.items.size}",
                            style = MaterialTheme.typography.titleMedium,
                            color = currentItem.secondaryColor,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }

                // Quick Progress Pill Selector
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                ) {
                    itemsIndexed(session.items) { idx, item ->
                        val active = idx == session.currentIndex
                        val itemMastered = uiState.wordProgressById[item.id]?.isMastered == true
                        Surface(
                            modifier = Modifier
                                .testTag("lesson_dot_$idx")
                                .clip(RoundedCornerShape(50))
                                .clickable { onSelectIndex(idx) },
                            shape = RoundedCornerShape(50),
                            color = when {
                                active -> item.primaryColor
                                itemMastered -> MintEmeraldLight
                                else -> MaterialTheme.colorScheme.surface
                            },
                            border = BorderStroke(
                                width = 1.5.dp,
                                color = when {
                                    active -> item.secondaryColor
                                    itemMastered -> MintEmerald
                                    else -> MaterialTheme.colorScheme.outline
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (itemMastered && !active) {
                                    Icon(
                                        imageVector = Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = MintEmeraldDeep,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                                Text(
                                    text = item.englishWord,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = when {
                                        active -> Color.White
                                        itemMastered -> MintEmeraldDeep
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                    }
                }

                // Main Scrollable Flashcard Area
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AnimatedContent(
                        targetState = currentItem,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "flashcard_transition"
                    ) { item ->
                        LessonFlashcard(
                            item = item,
                            language = uiState.selectedLanguage,
                            isMastered = isMastered,
                            isSpeaking = uiState.isSpeaking,
                            strings = strings,
                            onTapIllustration = onListen,
                            onListenSentence = onListenSentence,
                            onToggleMastered = onToggleMastered
                        )
                    }

                    // Listen & Listen Again Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Toy3DButton(
                            text = if (uiState.isSpeaking) strings.speakingNow else strings.listen,
                            icon = Icons.AutoMirrored.Rounded.VolumeUp,
                            containerColor = SkyBluePrimary,
                            lipColor = SkyBlueDeep,
                            onClick = onListen,
                            testTag = "btn_listen",
                            height = 58.dp,
                            modifier = Modifier.weight(1f)
                        )

                        Toy3DButton(
                            text = strings.listenAgain,
                            icon = Icons.Rounded.Replay,
                            containerColor = SunnyAmber,
                            lipColor = SunnyAmberDeep,
                            contentColor = Color(0xFF1E293B),
                            onClick = onListenAgain,
                            testTag = "btn_listen_again",
                            height = 58.dp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Bottom Previous / Next Navigation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Toy3DButton(
                        text = strings.previous,
                        icon = Icons.AutoMirrored.Rounded.ArrowBack,
                        containerColor = MaterialTheme.colorScheme.surface,
                        lipColor = Color(0xFFCBD5E1),
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        enabled = session.hasPrevious,
                        onClick = onPrevious,
                        testTag = "btn_previous_lesson",
                        height = 54.dp,
                        modifier = Modifier.weight(1f)
                    )

                    if (session.hasNext) {
                        Toy3DButton(
                            text = strings.next,
                            icon = Icons.AutoMirrored.Rounded.ArrowForward,
                            containerColor = currentItem.primaryColor,
                            lipColor = currentItem.secondaryColor,
                            onClick = onNext,
                            testTag = "btn_next_lesson",
                            height = 54.dp,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Toy3DButton(
                            text = strings.finishToQuiz,
                            icon = Icons.Rounded.Quiz,
                            containerColor = MintEmerald,
                            lipColor = MintEmeraldDeep,
                            onClick = onStartCategoryQuiz,
                            testTag = "btn_finish_to_quiz",
                            height = 54.dp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonFlashcard(
    item: LessonItem,
    language: AppLanguage,
    isMastered: Boolean,
    isSpeaking: Boolean,
    strings: com.example.model.LocalizedStrings,
    onTapIllustration: () -> Unit,
    onListenSentence: () -> Unit,
    onToggleMastered: () -> Unit
) {
    Toy3DCard(
        containerColor = MaterialTheme.colorScheme.surface,
        lipColor = item.primaryColor.copy(alpha = 0.28f),
        borderColor = item.primaryColor.copy(alpha = 0.35f),
        cornerRadius = 30.dp,
        lipDepth = 8.dp,
        contentPadding = PaddingValues(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top badge row: Learned toggle + speaking wave
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .testTag("btn_toggle_mastered")
                        .clip(RoundedCornerShape(50))
                        .clickable(onClick = onToggleMastered),
                    shape = RoundedCornerShape(50),
                    color = if (isMastered) MintEmeraldLight else SunnyAmberLight,
                    border = BorderStroke(
                        1.5.dp,
                        if (isMastered) MintEmerald else SunnyAmber
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (isMastered) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                            contentDescription = null,
                            tint = if (isMastered) MintEmeraldDeep else SunnyAmberDeep,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (isMastered) strings.learnedBadge else strings.markLearned,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isMastered) MintEmeraldDeep else SunnyAmberDeep
                        )
                    }
                }

                SpeakingWaveIndicator(
                    isSpeaking = isSpeaking,
                    color = item.primaryColor
                )
            }

            // Large 3D Illustration
            LessonIllustration3D(
                item = item,
                isSpeaking = isSpeaking,
                onTap = onTapIllustration,
                modifier = Modifier
                    .testTag("lesson_illustration_${item.id}")
                    .size(210.dp)
            )

            Text(
                text = strings.tapPictureToHear,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // English Word + Phonetic always rendered LTR so English spelling stays natural
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = item.englishWord,
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = item.secondaryColor,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("lesson_english_word")
                    )

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = item.containerTint
                    ) {
                        Text(
                            text = item.phonetic,
                            style = MaterialTheme.typography.titleMedium,
                            color = item.secondaryColor,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Native Translation & Fun Fact Box (Arabic / French / English)
            if (language != AppLanguage.ENGLISH) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = SkyBlueLight.copy(alpha = 0.65f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = strings.meaningLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = SkyBlueDeep
                        )
                        Text(
                            text = item.localizedTranslation(language),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Fun Fact
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = item.localizedFact(language),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }

            // English Example Sentence with Speak Button
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_hear_sentence")
                        .clip(RoundedCornerShape(18.dp))
                        .clickable(onClick = onListenSentence),
                    shape = RoundedCornerShape(18.dp),
                    color = item.containerTint,
                    border = BorderStroke(1.dp, item.primaryColor.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.RecordVoiceOver,
                            contentDescription = strings.hearSentence,
                            tint = item.secondaryColor,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "\"${item.sampleSentence}\"",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
