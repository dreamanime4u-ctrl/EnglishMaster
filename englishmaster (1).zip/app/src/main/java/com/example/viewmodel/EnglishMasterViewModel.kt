package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.SpeechController
import com.example.data.LessonCatalog
import com.example.data.local.LearningRepository
import com.example.data.local.QuizAttemptEntity
import com.example.data.local.WordProgressEntity
import com.example.model.AppLanguage
import com.example.model.LessonCategory
import com.example.model.LessonItem
import com.example.model.QuizMode
import com.example.model.QuizQuestion
import com.example.model.QuizQuestionType
import com.example.model.QuizResultSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LessonSessionState(
    val category: LessonCategory = LessonCategory.FRUITS,
    val items: List<LessonItem> = LessonCatalog.fruits,
    val currentIndex: Int = 0
) {
    val currentItem: LessonItem get() = items[currentIndex.coerceIn(0, items.lastIndex)]
    val hasPrevious: Boolean get() = currentIndex > 0
    val hasNext: Boolean get() = currentIndex < items.lastIndex
}

data class QuizSessionState(
    val mode: QuizMode = QuizMode.FRUITS,
    val questions: List<QuizQuestion> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOptionId: String? = null,
    val isSubmitted: Boolean = false,
    val score: Int = 0
) {
    val currentQuestion: QuizQuestion?
        get() = questions.getOrNull(currentIndex)
    val isLastQuestion: Boolean
        get() = questions.isNotEmpty() && currentIndex >= questions.lastIndex
}

data class EnglishMasterUiState(
    val selectedLanguage: AppLanguage = AppLanguage.ENGLISH,
    val wordProgressById: Map<String, WordProgressEntity> = emptyMap(),
    val quizAttempts: List<QuizAttemptEntity> = emptyList(),
    val fruitsLearnedCount: Int = 0,
    val animalsLearnedCount: Int = 0,
    val totalMasteredCount: Int = 0,
    val totalWordsCount: Int = LessonCatalog.allItems.size,
    val totalStars: Int = 0,
    val bestFruitsScore: Int? = null,
    val bestAnimalsScore: Int? = null,
    val bestMixedScore: Int? = null,
    val isSpeaking: Boolean = false,
    val isTtsReady: Boolean = false,
    val lessonSession: LessonSessionState = LessonSessionState(),
    val quizSession: QuizSessionState = QuizSessionState(),
    val latestQuizResult: QuizResultSummary? = null
)

private data class SessionSnapshot(
    val lesson: LessonSessionState,
    val quiz: QuizSessionState,
    val latestResult: QuizResultSummary?,
    val speaking: Boolean,
    val ttsReady: Boolean
)

class EnglishMasterViewModel(
    private val repository: LearningRepository,
    private val speechController: SpeechController
) : ViewModel() {

    private val lessonSession = MutableStateFlow(LessonSessionState())
    private val quizSession = MutableStateFlow(QuizSessionState())
    private val latestQuizResult = MutableStateFlow<QuizResultSummary?>(null)

    private val sessionSnapshot = combine(
        lessonSession,
        quizSession,
        latestQuizResult,
        speechController.isSpeaking,
        speechController.isReady
    ) { lesson, quiz, result, speaking, ready ->
        SessionSnapshot(
            lesson = lesson,
            quiz = quiz,
            latestResult = result,
            speaking = speaking,
            ttsReady = ready
        )
    }

    val uiState: StateFlow<EnglishMasterUiState> = combine(
        repository.selectedLanguage,
        repository.wordProgressById,
        repository.quizAttempts,
        sessionSnapshot
    ) { language, progressMap, attempts, snapshot ->
        val fruitsLearned = LessonCatalog.fruits.count { progressMap[it.id]?.isMastered == true }
        val animalsLearned = LessonCatalog.animals.count { progressMap[it.id]?.isMastered == true }
        val masteredWords = fruitsLearned + animalsLearned
        val quizStars = attempts.sumOf { it.starsEarned }
        val totalStars = masteredWords + quizStars

        EnglishMasterUiState(
            selectedLanguage = language,
            wordProgressById = progressMap,
            quizAttempts = attempts,
            fruitsLearnedCount = fruitsLearned,
            animalsLearnedCount = animalsLearned,
            totalMasteredCount = masteredWords,
            totalWordsCount = LessonCatalog.allItems.size,
            totalStars = totalStars,
            bestFruitsScore = attempts.filter { it.modeId == QuizMode.FRUITS.id }.maxOfOrNull { it.score },
            bestAnimalsScore = attempts.filter { it.modeId == QuizMode.ANIMALS.id }.maxOfOrNull { it.score },
            bestMixedScore = attempts.filter { it.modeId == QuizMode.MIXED.id }.maxOfOrNull { it.score },
            isSpeaking = snapshot.speaking,
            isTtsReady = snapshot.ttsReady,
            lessonSession = snapshot.lesson,
            quizSession = snapshot.quiz,
            latestQuizResult = snapshot.latestResult
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = EnglishMasterUiState()
    )

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.setLanguage(language)
        }
    }

    fun startLesson(category: LessonCategory, initialIndex: Int = 0) {
        val items = LessonCatalog.itemsForCategory(category)
        val safeIndex = initialIndex.coerceIn(0, items.lastIndex)
        lessonSession.value = LessonSessionState(
            category = category,
            items = items,
            currentIndex = safeIndex
        )
    }

    fun selectLessonIndex(index: Int) {
        speechController.stop()
        lessonSession.update { state ->
            state.copy(currentIndex = index.coerceIn(0, state.items.lastIndex))
        }
    }

    fun nextLessonItem() {
        speechController.stop()
        lessonSession.update { state ->
            if (state.hasNext) state.copy(currentIndex = state.currentIndex + 1) else state
        }
    }

    fun previousLessonItem() {
        speechController.stop()
        lessonSession.update { state ->
            if (state.hasPrevious) state.copy(currentIndex = state.currentIndex - 1) else state
        }
    }

    fun listenCurrentWord(slow: Boolean = false) {
        val item = lessonSession.value.currentItem
        listenWord(item, slow)
    }

    fun listenWord(item: LessonItem, slow: Boolean = false) {
        speechController.speak(item.englishWord, slow = slow)
        viewModelScope.launch {
            repository.recordWordListen(item.id, item.category)
        }
    }

    fun listenSampleSentence() {
        val item = lessonSession.value.currentItem
        speechController.speak(item.sampleSentence, slow = false)
        viewModelScope.launch {
            repository.recordWordListen(item.id, item.category)
        }
    }

    fun toggleCurrentWordMastered() {
        val item = lessonSession.value.currentItem
        viewModelScope.launch {
            repository.toggleWordMastered(item.id, item.category)
        }
    }

    fun startQuiz(mode: QuizMode) {
        speechController.stop()
        val pool = when (mode) {
            QuizMode.FRUITS -> LessonCatalog.fruits
            QuizMode.ANIMALS -> LessonCatalog.animals
            QuizMode.MIXED -> LessonCatalog.allItems
        }
        val questionCount = if (mode == QuizMode.MIXED) 8 else pool.size
        val selectedTargets = pool.shuffled().take(questionCount)

        val questions = selectedTargets.mapIndexed { idx, target ->
            val distractors = pool.filter { it.id != target.id }.shuffled().take(3)
            val options = (distractors + target).shuffled()
            val questionType = if (idx % 2 == 0) {
                QuizQuestionType.ILLUSTRATION_TO_WORD
            } else {
                QuizQuestionType.WORD_TO_ILLUSTRATION
            }
            QuizQuestion(
                index = idx,
                targetItem = target,
                options = options,
                type = questionType
            )
        }

        latestQuizResult.value = null
        quizSession.value = QuizSessionState(
            mode = mode,
            questions = questions,
            currentIndex = 0,
            selectedOptionId = null,
            isSubmitted = false,
            score = 0
        )

        questions.firstOrNull()?.let { first ->
            if (first.type == QuizQuestionType.WORD_TO_ILLUSTRATION) {
                speechController.speak(first.targetItem.englishWord, slow = false)
            }
        }
    }

    fun speakQuizWord(slow: Boolean = false) {
        val target = quizSession.value.currentQuestion?.targetItem ?: return
        speechController.speak(target.englishWord, slow = slow)
    }

    fun submitQuizAnswer(selectedOption: LessonItem) {
        val current = quizSession.value
        val question = current.currentQuestion ?: return
        if (current.isSubmitted) return

        val isCorrect = selectedOption.id == question.targetItem.id
        val newScore = if (isCorrect) current.score + 1 else current.score

        quizSession.value = current.copy(
            selectedOptionId = selectedOption.id,
            isSubmitted = true,
            score = newScore
        )

        if (isCorrect) {
            speechController.speak("Great job! ${question.targetItem.englishWord}!", slow = false)
        } else {
            speechController.speak(question.targetItem.englishWord, slow = true)
        }
    }

    fun advanceQuiz(onQuizCompleted: () -> Unit) {
        speechController.stop()
        val current = quizSession.value
        if (!current.isLastQuestion) {
            val nextIdx = current.currentIndex + 1
            quizSession.value = current.copy(
                currentIndex = nextIdx,
                selectedOptionId = null,
                isSubmitted = false
            )
            current.questions.getOrNull(nextIdx)?.let { nextQ ->
                if (nextQ.type == QuizQuestionType.WORD_TO_ILLUSTRATION) {
                    speechController.speak(nextQ.targetItem.englishWord, slow = false)
                }
            }
        } else {
            val total = current.questions.size
            val finalScore = current.score
            val mode = current.mode
            viewModelScope.launch {
                val (starsEarned, isNewBest) = repository.saveQuizResult(mode, finalScore, total)
                latestQuizResult.value = QuizResultSummary(
                    mode = mode,
                    score = finalScore,
                    totalQuestions = total,
                    starsEarned = starsEarned,
                    isNewBest = isNewBest
                )
                onQuizCompleted()
            }
        }
    }

    fun stopSpeech() {
        speechController.stop()
    }

    fun resetAllProgress() {
        viewModelScope.launch {
            repository.resetAllProgress()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechController.shutdown()
    }

    class Factory(
        private val repository: LearningRepository,
        private val speechController: SpeechController
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return EnglishMasterViewModel(repository, speechController) as T
        }
    }
}
