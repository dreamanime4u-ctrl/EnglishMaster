package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.audio.TtsManager
import com.example.data.local.AppDatabase
import com.example.data.local.LearningRepository
import com.example.model.LessonCategory
import com.example.model.QuizMode
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LessonScreen
import com.example.ui.screens.QuizResultScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.theme.EnglishMasterTheme
import com.example.viewmodel.EnglishMasterViewModel

object AppRoutes {
    const val HOME = "home"
    const val LESSON = "lesson"
    const val QUIZ = "quiz"
    const val QUIZ_RESULT = "quiz_result"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = LearningRepository(database.learningDao())
        val ttsManager = TtsManager(applicationContext)

        setContent {
            val viewModel: EnglishMasterViewModel = viewModel(
                factory = EnglishMasterViewModel.Factory(repository, ttsManager)
            )
            EnglishMasterApp(viewModel = viewModel)
        }
    }
}

@Composable
fun EnglishMasterApp(viewModel: EnglishMasterViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val layoutDirection = if (uiState.selectedLanguage.isRtl) {
        LayoutDirection.Rtl
    } else {
        LayoutDirection.Ltr
    }

    EnglishMasterTheme(language = uiState.selectedLanguage) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            NavHost(
                navController = navController,
                startDestination = AppRoutes.HOME
            ) {
                composable(AppRoutes.HOME) {
                    HomeScreen(
                        uiState = uiState,
                        onSelectLanguage = viewModel::setLanguage,
                        onStartLesson = { category ->
                            viewModel.startLesson(category)
                            navController.navigate(AppRoutes.LESSON)
                        },
                        onStartQuiz = { mode ->
                            viewModel.startQuiz(mode)
                            navController.navigate(AppRoutes.QUIZ)
                        },
                        onResetProgress = viewModel::resetAllProgress
                    )
                }

                composable(AppRoutes.LESSON) {
                    LessonScreen(
                        uiState = uiState,
                        onBack = {
                            viewModel.stopSpeech()
                            navController.popBackStack()
                        },
                        onSelectIndex = viewModel::selectLessonIndex,
                        onPrevious = viewModel::previousLessonItem,
                        onNext = viewModel::nextLessonItem,
                        onStartCategoryQuiz = {
                            val quizMode = when (uiState.lessonSession.category) {
                                LessonCategory.FRUITS -> QuizMode.FRUITS
                                LessonCategory.ANIMALS -> QuizMode.ANIMALS
                            }
                            viewModel.startQuiz(quizMode)
                            navController.navigate(AppRoutes.QUIZ) {
                                popUpTo(AppRoutes.HOME)
                            }
                        },
                        onListen = { viewModel.listenCurrentWord(slow = false) },
                        onListenAgain = { viewModel.listenCurrentWord(slow = true) },
                        onListenSentence = viewModel::listenSampleSentence,
                        onToggleMastered = viewModel::toggleCurrentWordMastered
                    )
                }

                composable(AppRoutes.QUIZ) {
                    QuizScreen(
                        uiState = uiState,
                        onBack = {
                            viewModel.stopSpeech()
                            navController.popBackStack()
                        },
                        onSpeakWord = viewModel::speakQuizWord,
                        onSelectOption = viewModel::submitQuizAnswer,
                        onNextQuestion = {
                            viewModel.advanceQuiz {
                                navController.navigate(AppRoutes.QUIZ_RESULT) {
                                    popUpTo(AppRoutes.HOME)
                                }
                            }
                        }
                    )
                }

                composable(AppRoutes.QUIZ_RESULT) {
                    QuizResultScreen(
                        uiState = uiState,
                        onPlayAgain = { mode ->
                            viewModel.startQuiz(mode)
                            navController.navigate(AppRoutes.QUIZ) {
                                popUpTo(AppRoutes.HOME)
                            }
                        },
                        onReviewLessons = { mode ->
                            val category = when (mode) {
                                QuizMode.ANIMALS -> LessonCategory.ANIMALS
                                QuizMode.FRUITS, QuizMode.MIXED -> LessonCategory.FRUITS
                            }
                            viewModel.startLesson(category)
                            navController.navigate(AppRoutes.LESSON) {
                                popUpTo(AppRoutes.HOME)
                            }
                        },
                        onBackHome = {
                            viewModel.stopSpeech()
                            navController.popBackStack(AppRoutes.HOME, inclusive = false)
                        }
                    )
                }
            }
        }
    }
}
