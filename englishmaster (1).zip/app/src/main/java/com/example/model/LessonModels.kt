package com.example.model

import androidx.compose.ui.graphics.Color

enum class LessonCategory(val id: String) {
    FRUITS("fruits"),
    ANIMALS("animals");

    companion object {
        fun fromId(id: String?): LessonCategory =
            entries.firstOrNull { it.id == id } ?: FRUITS
    }
}

enum class QuizMode(val id: String) {
    FRUITS("fruits"),
    ANIMALS("animals"),
    MIXED("mixed");

    companion object {
        fun fromId(id: String?): QuizMode =
            entries.firstOrNull { it.id == id } ?: MIXED
    }
}

data class LessonItem(
    val id: String,
    val category: LessonCategory,
    val englishWord: String,
    val phonetic: String,
    val sampleSentence: String,
    val arabicWord: String,
    val frenchWord: String,
    val englishFact: String,
    val arabicFact: String,
    val frenchFact: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val containerTint: Color
) {
    fun localizedTranslation(language: AppLanguage): String = when (language) {
        AppLanguage.ENGLISH -> englishFact
        AppLanguage.ARABIC -> arabicWord
        AppLanguage.FRENCH -> frenchWord
    }

    fun localizedFact(language: AppLanguage): String = when (language) {
        AppLanguage.ENGLISH -> englishFact
        AppLanguage.ARABIC -> arabicFact
        AppLanguage.FRENCH -> frenchFact
    }
}

enum class QuizQuestionType {
    ILLUSTRATION_TO_WORD,
    WORD_TO_ILLUSTRATION
}

data class QuizQuestion(
    val index: Int,
    val targetItem: LessonItem,
    val options: List<LessonItem>,
    val type: QuizQuestionType
)

data class QuizResultSummary(
    val mode: QuizMode,
    val score: Int,
    val totalQuestions: Int,
    val starsEarned: Int,
    val isNewBest: Boolean
)
