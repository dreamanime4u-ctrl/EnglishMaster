package com.example.model

enum class AppLanguage(
    val code: String,
    val shortLabel: String,
    val displayName: String,
    val isRtl: Boolean
) {
    ENGLISH(
        code = "en",
        shortLabel = "EN",
        displayName = "English",
        isRtl = false
    ),
    ARABIC(
        code = "ar",
        shortLabel = "عربي",
        displayName = "العربية",
        isRtl = true
    ),
    FRENCH(
        code = "fr",
        shortLabel = "FR",
        displayName = "Français",
        isRtl = false
    );

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}
