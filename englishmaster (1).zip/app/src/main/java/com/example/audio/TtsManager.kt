package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

interface SpeechController {
    val isReady: StateFlow<Boolean>
    val isSpeaking: StateFlow<Boolean>
    fun speak(text: String, slow: Boolean = false)
    fun stop()
    fun shutdown()
}

class TtsManager(context: Context) : SpeechController {
    private val appContext = context.applicationContext
    private val _isReady = MutableStateFlow(false)
    override val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    override val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var tts: TextToSpeech? = null
    private var pendingText: Pair<String, Boolean>? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts ?: return@TextToSpeech
                val usResult = engine.setLanguage(Locale.US)
                if (usResult == TextToSpeech.LANG_MISSING_DATA ||
                    usResult == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    engine.setLanguage(Locale.ENGLISH)
                }
                engine.setPitch(1.06f)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _isSpeaking.value = false
                    }
                })
                _isReady.value = true
                pendingText?.let { (text, slow) ->
                    pendingText = null
                    speak(text, slow)
                }
            } else {
                _isReady.value = false
            }
        }
    }

    override fun speak(text: String, slow: Boolean) {
        val engine = tts
        if (engine == null || !_isReady.value) {
            pendingText = text to slow
            return
        }
        val speechRate = if (slow) 0.72f else 0.90f
        engine.setSpeechRate(speechRate)
        val utteranceId = UUID.randomUUID().toString()
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    override fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    override fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        _isReady.value = false
        _isSpeaking.value = false
    }
}
