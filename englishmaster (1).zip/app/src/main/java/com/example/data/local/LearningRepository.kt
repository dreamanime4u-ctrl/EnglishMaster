package com.example.data.local

import com.example.model.AppLanguage
import com.example.model.LessonCategory
import com.example.model.QuizMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LearningRepository(private val dao: LearningDao) {

    val wordProgressById: Flow<Map<String, WordProgressEntity>> =
        dao.observeAllWordProgress().map { list -> list.associateBy { it.wordId } }

    val quizAttempts: Flow<List<QuizAttemptEntity>> = dao.observeQuizAttempts()

    val selectedLanguage: Flow<AppLanguage> =
        dao.observeUserSettings().map { settings ->
            AppLanguage.fromCode(settings?.languageCode)
        }

    suspend fun recordWordListen(wordId: String, category: LessonCategory) {
        val existing = dao.getWordProgress(wordId)
        val updated = if (existing == null) {
            WordProgressEntity(
                wordId = wordId,
                categoryId = category.id,
                listenCount = 1,
                isMastered = true,
                lastPracticedAt = System.currentTimeMillis()
            )
        } else {
            existing.copy(
                listenCount = existing.listenCount + 1,
                isMastered = true,
                lastPracticedAt = System.currentTimeMillis()
            )
        }
        dao.upsertWordProgress(updated)
    }

    suspend fun toggleWordMastered(wordId: String, category: LessonCategory) {
        val existing = dao.getWordProgress(wordId)
        val updated = if (existing == null) {
            WordProgressEntity(
                wordId = wordId,
                categoryId = category.id,
                listenCount = 0,
                isMastered = true,
                lastPracticedAt = System.currentTimeMillis()
            )
        } else {
            existing.copy(
                isMastered = !existing.isMastered,
                lastPracticedAt = System.currentTimeMillis()
            )
        }
        dao.upsertWordProgress(updated)
    }

    suspend fun saveQuizResult(mode: QuizMode, score: Int, totalQuestions: Int): Pair<Int, Boolean> {
        val ratio = if (totalQuestions > 0) score.toFloat() / totalQuestions else 0f
        val starsEarned = when {
            ratio >= 0.85f -> 3
            ratio >= 0.55f -> 2
            score > 0 -> 1
            else -> 0
        }
        val previousBest = dao.getBestScoreForMode(mode.id)
        val isNewBest = score > 0 && (previousBest == null || score > previousBest)

        dao.insertQuizAttempt(
            QuizAttemptEntity(
                modeId = mode.id,
                score = score,
                totalQuestions = totalQuestions,
                starsEarned = starsEarned,
                completedAt = System.currentTimeMillis()
            )
        )
        return starsEarned to isNewBest
    }

    suspend fun setLanguage(language: AppLanguage) {
        dao.upsertUserSettings(UserSettingsEntity(id = 1, languageCode = language.code))
    }

    suspend fun resetAllProgress() {
        dao.clearAllWordProgress()
        dao.clearAllQuizAttempts()
    }
}
