package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.model.LessonCategory
import com.example.model.LessonItem

object LessonCatalog {
    val fruits: List<LessonItem> = listOf(
        LessonItem(
            id = "fruit_apple",
            category = LessonCategory.FRUITS,
            englishWord = "Apple",
            phonetic = "/ˈæp.əl/",
            sampleSentence = "I eat a crunchy red apple.",
            arabicWord = "تفاحة",
            frenchWord = "Pomme",
            englishFact = "Apples are sweet, crunchy, and grow on trees!",
            arabicFact = "التفاح حلو ومقرمش وينمو على الأشجار!",
            frenchFact = "Les pommes sont sucrées, croquantes et poussent dans les arbres !",
            primaryColor = Color(0xFFFF4D5A),
            secondaryColor = Color(0xFFD92638),
            containerTint = Color(0xFFFFECEE)
        ),
        LessonItem(
            id = "fruit_banana",
            category = LessonCategory.FRUITS,
            englishWord = "Banana",
            phonetic = "/bəˈnæn.ə/",
            sampleSentence = "Monkeys love eating yellow bananas.",
            arabicWord = "موزة",
            frenchWord = "Banane",
            englishFact = "Bananas are soft, sweet, and full of energy!",
            arabicFact = "الموز ناعم ولذيذ ومليء بالطاقة!",
            frenchFact = "Les bananes sont douces, sucrées et pleines d'énergie !",
            primaryColor = Color(0xFFFFC300),
            secondaryColor = Color(0xFFE09F00),
            containerTint = Color(0xFFFFF8DC)
        ),
        LessonItem(
            id = "fruit_strawberry",
            category = LessonCategory.FRUITS,
            englishWord = "Strawberry",
            phonetic = "/ˈstrɔː.bər.i/",
            sampleSentence = "This strawberry is bright red and juicy.",
            arabicWord = "فراولة",
            frenchWord = "Fraise",
            englishFact = "Strawberries wear their tiny golden seeds on the outside!",
            arabicFact = "توجد البذور الذهبية الصغيرة للفراولة على قشرتها الخارجية!",
            frenchFact = "Les fraises portent leurs petites graines dorées à l'extérieur !",
            primaryColor = Color(0xFFFF3864),
            secondaryColor = Color(0xFFC81D4E),
            containerTint = Color(0xFFFFE8EE)
        ),
        LessonItem(
            id = "fruit_orange",
            category = LessonCategory.FRUITS,
            englishWord = "Orange",
            phonetic = "/ˈɒr.ɪndʒ/",
            sampleSentence = "Fresh orange juice tastes delicious.",
            arabicWord = "برتقالة",
            frenchWord = "Orange",
            englishFact = "Oranges are round, sunny, and packed with vitamin C!",
            arabicFact = "البرتقال مستدير ومنعش وغني بفيتامين سي!",
            frenchFact = "Les oranges sont rondes, juteuses et riches en vitamine C !",
            primaryColor = Color(0xFFFF8800),
            secondaryColor = Color(0xFFE06300),
            containerTint = Color(0xFFFFF1E0)
        ),
        LessonItem(
            id = "fruit_watermelon",
            category = LessonCategory.FRUITS,
            englishWord = "Watermelon",
            phonetic = "/ˈwɔː.tə.mel.ən/",
            sampleSentence = "Cold watermelon is great in summer.",
            arabicWord = "بطيخ",
            frenchWord = "Pastèque",
            englishFact = "Watermelon is green outside, pink inside, and very refreshing!",
            arabicFact = "البطيخ أخضر من الخارج ووردي من الداخل ومنعش جداً!",
            frenchFact = "La pastèque est verte dehors, rose dedans et très rafraîchissante !",
            primaryColor = Color(0xFF10B981),
            secondaryColor = Color(0xFF059669),
            containerTint = Color(0xFFE6FAF3)
        ),
        LessonItem(
            id = "fruit_grapes",
            category = LessonCategory.FRUITS,
            englishWord = "Grapes",
            phonetic = "/ɡreɪps/",
            sampleSentence = "Purple grapes grow together in bunches.",
            arabicWord = "عنب",
            frenchWord = "Raisin",
            englishFact = "Grapes are tiny juicy spheres that grow in happy bunches!",
            arabicFact = "العنب حبات صغيرة لذيذة تنمو معاً في عناقيد!",
            frenchFact = "Les raisins sont de petites billes juteuses qui poussent en grappes !",
            primaryColor = Color(0xFF8B5CF6),
            secondaryColor = Color(0xFF6D28D9),
            containerTint = Color(0xFFF3EEFF)
        ),
        LessonItem(
            id = "fruit_pineapple",
            category = LessonCategory.FRUITS,
            englishWord = "Pineapple",
            phonetic = "/ˈpaɪn.æp.əl/",
            sampleSentence = "The pineapple wears a spiky green crown.",
            arabicWord = "أناناس",
            frenchWord = "Ananas",
            englishFact = "Pineapples look like a golden fruit wearing a leafy green crown!",
            arabicFact = "الأناناس فاكهة ذهبية تضع تاجاً أخضر جميلاً!",
            frenchFact = "L'ananas ressemble à un fruit doré portant une couronne verte !",
            primaryColor = Color(0xFFF59E0B),
            secondaryColor = Color(0xFFD97706),
            containerTint = Color(0xFFFFF5DC)
        ),
        LessonItem(
            id = "fruit_mango",
            category = LessonCategory.FRUITS,
            englishWord = "Mango",
            phonetic = "/ˈmæŋ.ɡəʊ/",
            sampleSentence = "A ripe mango is golden and sweet.",
            arabicWord = "مانجو",
            frenchWord = "Mangue",
            englishFact = "Mangoes are tropical fruits known as the king of fruits!",
            arabicFact = "المانجو فاكهة استوائية لذيذة وتُلقب بملكة الفواكه!",
            frenchFact = "La mangue est un fruit tropical sucré et très parfumé !",
            primaryColor = Color(0xFFFF7B3D),
            secondaryColor = Color(0xFFE55312),
            containerTint = Color(0xFFFFEFE6)
        )
    )

    val animals: List<LessonItem> = listOf(
        LessonItem(
            id = "animal_lion",
            category = LessonCategory.ANIMALS,
            englishWord = "Lion",
            phonetic = "/ˈlaɪ.ən/",
            sampleSentence = "The brave lion has a big golden mane.",
            arabicWord = "أسد",
            frenchWord = "Lion",
            englishFact = "Lions are big cats known as the kings of the savanna!",
            arabicFact = "الأسد قط كبير شجاع ويُعرف بملك الغابة!",
            frenchFact = "Le lion est un grand félin courageux avec une belle crinière !",
            primaryColor = Color(0xFFF59E0B),
            secondaryColor = Color(0xFFD97706),
            containerTint = Color(0xFFFFF4DC)
        ),
        LessonItem(
            id = "animal_elephant",
            category = LessonCategory.ANIMALS,
            englishWord = "Elephant",
            phonetic = "/ˈel.ɪ.fənt/",
            sampleSentence = "The friendly elephant sprays water with its trunk.",
            arabicWord = "فيل",
            frenchWord = "Éléphant",
            englishFact = "Elephants have big floppy ears and a super helpful long trunk!",
            arabicFact = "يمتلك الفيل أذنين كبيرتين وخرطوماً طويلاً ذكياً!",
            frenchFact = "L'éléphant a de grandes oreilles et une longue trompe très utile !",
            primaryColor = Color(0xFF3B82F6),
            secondaryColor = Color(0xFF1D4ED8),
            containerTint = Color(0xFFEBF3FF)
        ),
        LessonItem(
            id = "animal_cat",
            category = LessonCategory.ANIMALS,
            englishWord = "Cat",
            phonetic = "/kæt/",
            sampleSentence = "The little orange cat says meow.",
            arabicWord = "قطة",
            frenchWord = "Chat",
            englishFact = "Cats are playful pets that love to nap and purr softly!",
            arabicFact = "القطط حيوانات أليفة لطيفة تحب اللعب والنوم!",
            frenchFact = "Les chats sont des animaux câlins qui aiment jouer et ronronner !",
            primaryColor = Color(0xFFFF7A45),
            secondaryColor = Color(0xFFE0521B),
            containerTint = Color(0xFFFFEFE8)
        ),
        LessonItem(
            id = "animal_dog",
            category = LessonCategory.ANIMALS,
            englishWord = "Dog",
            phonetic = "/dɒɡ/",
            sampleSentence = "The happy dog wags its fluffy tail.",
            arabicWord = "كلب",
            frenchWord = "Chien",
            englishFact = "Dogs are loyal friends who love playing fetch in the park!",
            arabicFact = "الكلاب أصدقاء أوفياء يحبون اللعب والركض في الحديقة!",
            frenchFact = "Les chiens sont des amis fidèles qui adorent courir et jouer !",
            primaryColor = Color(0xFFA86B3E),
            secondaryColor = Color(0xFF844F28),
            containerTint = Color(0xFFFDF1E8)
        ),
        LessonItem(
            id = "animal_monkey",
            category = LessonCategory.ANIMALS,
            englishWord = "Monkey",
            phonetic = "/ˈmʌŋ.ki/",
            sampleSentence = "The cheeky monkey swings in the trees.",
            arabicWord = "قرد",
            frenchWord = "Singe",
            englishFact = "Monkeys are clever climbers that love swinging from branches!",
            arabicFact = "القرد متسلق ذكي يحب التأرجح بين أغصان الأشجار!",
            frenchFact = "Le singe est très agile et adore grimper dans les arbres !",
            primaryColor = Color(0xFFB45309),
            secondaryColor = Color(0xFF92400E),
            containerTint = Color(0xFFFEF3E2)
        ),
        LessonItem(
            id = "animal_giraffe",
            category = LessonCategory.ANIMALS,
            englishWord = "Giraffe",
            phonetic = "/dʒɪˈrɑːf/",
            sampleSentence = "The tall giraffe eats leaves from high trees.",
            arabicWord = "زرافة",
            frenchWord = "Girafe",
            englishFact = "Giraffes are the tallest land animals with beautiful spots!",
            arabicFact = "الزرافة أطول حيوان على اليابسة ولها بقع بنية جميلة!",
            frenchFact = "La girafe est l'animal le plus grand sur terre avec de jolies taches !",
            primaryColor = Color(0xFFEAB308),
            secondaryColor = Color(0xFFCA8A04),
            containerTint = Color(0xFFFEFBE4)
        ),
        LessonItem(
            id = "animal_penguin",
            category = LessonCategory.ANIMALS,
            englishWord = "Penguin",
            phonetic = "/ˈpeŋ.ɡwɪn/",
            sampleSentence = "The cute penguin slides on the snowy ice.",
            arabicWord = "بطريق",
            frenchWord = "Pingouin",
            englishFact = "Penguins cannot fly in the sky, but they swim like rockets!",
            arabicFact = "البطريق لا يطير في السماء لكنه يسبح بمهارة فائقة!",
            frenchFact = "Le pingouin ne vole pas, mais il nage comme un champion !",
            primaryColor = Color(0xFF0EA5E9),
            secondaryColor = Color(0xFF0284C7),
            containerTint = Color(0xFFE6F7FF)
        ),
        LessonItem(
            id = "animal_rabbit",
            category = LessonCategory.ANIMALS,
            englishWord = "Rabbit",
            phonetic = "/ˈræb.ɪt/",
            sampleSentence = "The fluffy rabbit hops across the grass.",
            arabicWord = "أرنب",
            frenchWord = "Lapin",
            englishFact = "Rabbits have soft long ears and love munching crunchy carrots!",
            arabicFact = "للأرنب أذنان طويلتان ناعمتان ويحب أكل الجزر المقرمش!",
            frenchFact = "Le lapin a de longues oreilles douces et adore croquer des carottes !",
            primaryColor = Color(0xFFEC4899),
            secondaryColor = Color(0xFFDB2777),
            containerTint = Color(0xFFFEEAF4)
        )
    )

    val allItems: List<LessonItem> = fruits + animals

    fun itemsForCategory(category: LessonCategory): List<LessonItem> = when (category) {
        LessonCategory.FRUITS -> fruits
        LessonCategory.ANIMALS -> animals
    }

    fun findById(id: String): LessonItem? = allItems.firstOrNull { it.id == id }
}
