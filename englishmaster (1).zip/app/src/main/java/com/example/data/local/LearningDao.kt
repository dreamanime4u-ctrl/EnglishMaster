package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LearningDao {
    @Query("SELECT * FROM word_progress")
    fun observeAllWordProgress(): Flow<List<WordProgressEntity>>

    @Query("SELECT * FROM word_progress WHERE wordId = :wordId LIMIT 1")
    suspend fun getWordProgress(wordId: String): WordProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWordProgress(entity: WordProgressEntity)

    @Query("SELECT * FROM quiz_attempts ORDER BY completedAt DESC")
    fun observeQuizAttempts(): Flow<List<QuizAttemptEntity>>

    @Query("SELECT MAX(score) FROM quiz_attempts WHERE modeId = :modeId")
    suspend fun getBestScoreForMode(modeId: String): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizAttempt(attempt: QuizAttemptEntity)

    @Query("SELECT * FROM user_settings WHERE id = 1 LIMIT 1")
    fun observeUserSettings(): Flow<UserSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUserSettings(settings: UserSettingsEntity)

    @Query("DELETE FROM word_progress")
    suspend fun clearAllWordProgress()

    @Query("DELETE FROM quiz_attempts")
    suspend fun clearAllQuizAttempts()
}
