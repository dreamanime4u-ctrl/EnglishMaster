package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.audio.SpeechController
import com.example.data.LessonCatalog
import com.example.data.local.AppDatabase
import com.example.data.local.LearningRepository
import com.example.model.AppLanguage
import com.example.model.LessonCategory
import com.example.model.QuizMode
import com.example.viewmodel.EnglishMasterViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class FakeSpeechController : SpeechController {
    override val isReady: StateFlow<Boolean> = MutableStateFlow(true)
    override val isSpeaking: StateFlow<Boolean> = MutableStateFlow(false)
    val spokenCalls = mutableListOf<Pair<String, Boolean>>()

    override fun speak(text: String, slow: Boolean) {
        spokenCalls.add(text to slow)
    }

    override fun stop() = Unit
    override fun shutdown() = Unit
}

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private val testDispatcher = UnconfinedTestDispatcher()
    private lateinit var database: AppDatabase
    private lateinit var repository: LearningRepository
    private lateinit var fakeSpeech: FakeSpeechController

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = LearningRepository(database.learningDao())
        fakeSpeech = FakeSpeechController()
    }

    @After
    fun tearDown() {
        database.close()
        Dispatchers.resetMain()
    }

    @Test
    fun `app name matches EnglishMaster`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("EnglishMaster", appName)
    }

    @Test
    fun `lesson navigation listen and listen again save progress locally`() = runTest {
        val viewModel = EnglishMasterViewModel(repository, fakeSpeech)
        val collector = backgroundScope.launch(testDispatcher) { viewModel.uiState.collect {} }

        viewModel.startLesson(LessonCategory.FRUITS)
        val initialState = viewModel.uiState.first {
            it.lessonSession.currentItem.englishWord == "Apple"
        }
        assertFalse(initialState.lessonSession.hasPrevious)

        viewModel.listenCurrentWord(slow = false)
        viewModel.listenCurrentWord(slow = true)

        assertEquals("Apple" to false, fakeSpeech.spokenCalls[0])
        assertEquals("Apple" to true, fakeSpeech.spokenCalls[1])

        val learnedState = viewModel.uiState.first { it.fruitsLearnedCount == 1 }
        assertEquals(1, learnedState.fruitsLearnedCount)

        viewModel.nextLessonItem()
        val bananaState = viewModel.uiState.first {
            it.lessonSession.currentItem.englishWord == "Banana"
        }
        assertTrue(bananaState.lessonSession.hasPrevious)

        viewModel.previousLessonItem()
        val backToApple = viewModel.uiState.first {
            it.lessonSession.currentItem.englishWord == "Apple"
        }
        assertEquals("Apple", backToApple.lessonSession.currentItem.englishWord)

        collector.cancel()
    }

    @Test
    fun `language switching persists Arabic RTL and French LTR`() = runTest {
        val viewModel = EnglishMasterViewModel(repository, fakeSpeech)
        val collector = backgroundScope.launch(testDispatcher) { viewModel.uiState.collect {} }

        viewModel.setLanguage(AppLanguage.ARABIC)
        val arabicState = viewModel.uiState.first { it.selectedLanguage == AppLanguage.ARABIC }
        assertTrue(arabicState.selectedLanguage.isRtl)

        viewModel.setLanguage(AppLanguage.FRENCH)
        val frenchState = viewModel.uiState.first { it.selectedLanguage == AppLanguage.FRENCH }
        assertFalse(frenchState.selectedLanguage.isRtl)

        collector.cancel()
    }

    @Test
    fun `quiz scores and stars are saved in local Room database`() = runTest {
        val viewModel = EnglishMasterViewModel(repository, fakeSpeech)
        val collector = backgroundScope.launch(testDispatcher) { viewModel.uiState.collect {} }

        viewModel.startQuiz(QuizMode.ANIMALS)
        val started = viewModel.uiState.first {
            it.quizSession.questions.size == LessonCatalog.animals.size
        }
        assertEquals(LessonCatalog.animals.size, started.quizSession.questions.size)

        var completed = false
        for (i in 0 until LessonCatalog.animals.size) {
            val questionState = viewModel.uiState.first { it.quizSession.currentIndex == i && !it.quizSession.isSubmitted }
            val target = questionState.quizSession.currentQuestion!!.targetItem
            viewModel.submitQuizAnswer(target)
            viewModel.advanceQuiz { completed = true }
        }

        val resultState = viewModel.uiState.first { it.latestQuizResult != null }
        assertTrue(completed)
        val result = resultState.latestQuizResult!!
        assertEquals(LessonCatalog.animals.size, result.score)
        assertEquals(3, result.starsEarned)
        assertTrue(result.isNewBest)

        val savedAttempts = repository.quizAttempts.first { it.isNotEmpty() }
        assertEquals(1, savedAttempts.size)

        collector.cancel()
    }
}
